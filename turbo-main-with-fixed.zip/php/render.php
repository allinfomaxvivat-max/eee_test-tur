<?php
function render($template, $props = []) {
    extract($props);
    ob_start();
    include $template; 
    $children = ob_get_clean();
    include __DIR__ . '/layout.php';
}