<div class="breadcrumb">
    <a href="index.html" class="breadcrumb-item breadcrumb-link" data-testid="link-home-breadcrumb">Главная страница</a>
    <svg class="breadcrumb-separator" viewBox="0 0 24 24" fill="currentColor">
        <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z" />
    </svg>
    <span class="breadcrumb-item active">Покупки</span>
</div>

<div class="stats-bar">
    <div class="stat-item">
        <span class="stat-value animated-stat" data-target="15000" data-prefix="" data-suffix=".00 ₽">15 000.00 ₽</span>
        <span class="stat-label">Выполнено, сумма</span>
    </div>
    <div class="stat-item">
        <span class="stat-value animated-stat-text" data-count="1" data-amount="3000">1 шт. на сумму 3 000.00 ₽</span>
        <span class="stat-label">Возвраты</span>
    </div>
    <div class="stat-item">
        <span class="stat-value animated-stat-text" data-count="1" data-amount="3000">1 шт. на сумму 3 000.00 ₽</span>
        <span class="stat-label">Споров отклонено</span>
    </div>
    <div class="stat-item">
        <span class="stat-value animated-stat" data-target="5" data-prefix="" data-suffix=".00 г./шт.">5.00
            г./шт.</span>
        <span class="stat-label">Общий вес/штук:</span>
    </div>
    <div class="stat-box">
        <span class="stat-value animated-stat-label" data-label="Выполненные" data-target="10">Выполненные: 10</span>
        <span class="stat-label animated-stat-label" data-label="Всего" data-target="200">Всего: 200</span>
    </div>
</div>

<div class="filters-bar">
    <div class="search-input">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M14.0002 14L11.0095 11.004L14.0002 14ZM12.6668 6.99999C12.6668 8.50289 12.0698 9.94423 11.0071 11.0069C9.9444 12.0696 8.50306 12.6667 7.00016 12.6667C5.49727 12.6667 4.05593 12.0696 2.99322 11.0069C1.93052 9.94423 1.3335 8.50289 1.3335 6.99999C1.3335 5.4971 1.93052 4.05576 2.99322 2.99306C4.05593 1.93035 5.49727 1.33333 7.00016 1.33333C8.50306 1.33333 9.9444 1.93035 11.0071 2.99306C12.0698 4.05576 12.6668 5.4971 12.6668 6.99999V6.99999Z"
                stroke="#969696" stroke-width="1.20137" stroke-linecap="round" />
        </svg>
        <input type="text" placeholder="Поиск по номеру покупки" data-testid="input-search" id="purchasesSearch">
    </div>

    <div class="filter-buttons">
        <div class="filter-dropdown-wrapper">
            <button class="filter-btn" id="cityFilterBtn" data-testid="button-city-filter">
                <span id="cityFilterText">Город</span>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 6L8 10L12 6" stroke="#969696" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </button>
            <div class="filter-dropdown-menu" id="cityFilterMenu">
                <div class="filter-dropdown-item active" data-value="all">Все города</div>
                <div class="filter-dropdown-item" data-value="moscow">Москва</div>
                <div class="filter-dropdown-item" data-value="saratov">Саратов</div>
            </div>
        </div>
        <div class="filter-dropdown-wrapper">
            <button class="filter-btn" id="productFilterBtn" data-testid="button-product-filter">
                <span id="productFilterText">Товар</span>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 6L8 10L12 6" stroke="#969696" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </button>
            <div class="filter-dropdown-menu" id="productFilterMenu">
                <div class="filter-dropdown-item active" data-value="all">Все товары</div>
                <div class="filter-dropdown-item" data-value="alpha">Альфа 1 грамм</div>
                <div class="filter-dropdown-item" data-value="hash">Hash Amezia</div>
            </div>
        </div>
        <div class="filter-dropdown-wrapper">
            <button class="filter-btn" id="courierFilterBtn" data-testid="button-courier-filter">
                <span id="courierFilterText">Курьер</span>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 6L8 10L12 6" stroke="#969696" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </button>
            <div class="filter-dropdown-menu" id="courierFilterMenu">
                <div class="filter-dropdown-item active" data-value="all">Все курьеры</div>
                <div class="filter-dropdown-item" data-value="courier1">Курьер #1</div>
                <div class="filter-dropdown-item" data-value="courier2">Курьер #2</div>
            </div>
        </div>
        <div class="filter-dropdown-wrapper">
            <button class="filter-btn" id="statusFilterBtn" data-testid="button-status-filter">
                <span id="statusFilterText">Статус</span>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4 6L8 10L12 6" stroke="#969696" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </button>
            <div class="filter-dropdown-menu" id="statusFilterMenu">
                <div class="filter-dropdown-item active" data-value="all">Все статусы</div>
                <div class="filter-dropdown-item" data-value="completed">Выполнен</div>
                <div class="filter-dropdown-item" data-value="pending">В ожидании</div>
                <div class="filter-dropdown-item" data-value="cancelled">Отменён</div>
            </div>
        </div>
        <div class="filter-dropdown-wrapper">
            <button class="filter-btn" id="dateFilterBtn" data-testid="button-date-filter">
                <span id="dateFilterText">2025-12-14 - 2025-12-21</span>
                <svg viewBox="0 0 24 24" fill="currentColor">
                    <path
                        d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM9 10H7v2h2v-2zm4 0h-2v2h2v-2zm4 0h-2v2h2v-2zm-8 4H7v2h2v-2zm4 0h-2v2h2v-2zm4 0h-2v2h2v-2z" />
                </svg>
            </button>
            <div class="filter-dropdown-menu" id="dateFilterMenu">
                <div class="filter-dropdown-item active" data-value="week" data-label="2025-12-14 - 2025-12-21">
                    Последние 7 дней</div>
                <div class="filter-dropdown-item" data-value="today" data-label="2025-12-21">Сегодня</div>
                <div class="filter-dropdown-item" data-value="yesterday" data-label="2025-12-20">Вчера</div>
                <div class="filter-dropdown-item" data-value="month" data-label="2025-11-21 - 2025-12-21">Последний
                    месяц</div>
                <div class="filter-dropdown-item" data-value="all" data-label="Все время">Все время</div>
            </div>
        </div>
    </div>
</div>

<div class="data-table">
    <div class="table-header">
        <span>Покупка #</span>
        <span>Клиент</span>
        <span>Информация</span>
        <span>Статус</span>
        <span>Дата</span>
        <span>Действие</span>
    </div>

    <div class="table-body" id="purchases-table">
    </div>
</div>

<script src="scripts/purchases.js"></script>