document.addEventListener('DOMContentLoaded', function() {
  console.log('TURBO Dashboard loaded');
  
  // Initialize mobile menu
  initMobileMenu();
  
  // Update all dates to be dynamic
  updateDynamicDates();
  
  // Initialize notifications
  initNotifications();
  
  // Initialize dispute modal
  initDisputeModal();
  
  // Initialize disputes filter & pagination
  initDisputesFilter();
  
  // Initialize universal search
  initUniversalSearch();
  
  // Initialize group modal
  initGroupModal();
  
  // Initialize courier modal
  initCourierModal();
  
  // Initialize addresses page search
  initAddressesSearch();
  
  // Initialize filter dropdowns
  initFilterDropdowns();
  
  // Initialize address modals
  initAddressModals();
  
  // Update page stats on load
  updatePageStats();
  
  // Initialize copy buttons
  initCopyButtons();
  
  // Initialize bot modal
  initBotModal();
  
  // Initialize bots filter dropdowns
  initBotsFilterDropdowns();
  
  // Initialize edit bot modal
  initEditBotModal();
  
  const menuItems = document.querySelectorAll('.menu-item.has-submenu');
  
  menuItems.forEach(item => {
    item.addEventListener('click', function(e) {
      e.preventDefault();
      
      const isOpen = this.classList.contains('open');
      
      menuItems.forEach(otherItem => {
        otherItem.classList.remove('open');
        const otherSubmenu = otherItem.nextElementSibling;
        if (otherSubmenu && otherSubmenu.classList.contains('submenu')) {
          otherSubmenu.style.maxHeight = '0';
        }
      });
      
      if (!isOpen) {
        this.classList.add('open');
        const submenu = this.nextElementSibling;
        if (submenu && submenu.classList.contains('submenu')) {
          submenu.style.maxHeight = submenu.scrollHeight + 'px';
        }
      }
    });
  });
  
  // Wallet Counter Animation
  animateWalletCounters();
  
  // Animate elements with data-animate attribute (on all pages)
  animateOnLoad();
  
  // Initialize Dashboard Animations
  initDashboardAnimations();
  
  // Initialize Mini Line Charts
  initMiniLineCharts();
  
  // Initialize Deposits Page
  initDepositsPage();
  
  // Initialize Purchases Stock Page
  initPurchasesStockPage();
  
  // Initialize Deposits Dynamics Page
  initDepositsDynamicsPage();
});

// Mobile Menu Functionality
function initMobileMenu() {
  // Create mobile menu toggle if it doesn't exist
  if (!document.querySelector('.mobile-menu-toggle')) {
    const toggle = document.createElement('button');
    toggle.className = 'mobile-menu-toggle';
    toggle.setAttribute('data-testid', 'button-mobile-menu');
    toggle.innerHTML = '<span></span><span></span><span></span>';
    document.body.insertBefore(toggle, document.body.firstChild);
  }
  
  // Create overlay if it doesn't exist
  if (!document.querySelector('.mobile-overlay')) {
    const overlay = document.createElement('div');
    overlay.className = 'mobile-overlay';
    document.body.insertBefore(overlay, document.body.firstChild);
  }
  
  const toggle = document.querySelector('.mobile-menu-toggle');
  const overlay = document.querySelector('.mobile-overlay');
  const sidebar = document.querySelector('.sidebar');
  
  if (toggle && sidebar) {
    toggle.addEventListener('click', function() {
      toggle.classList.toggle('active');
      sidebar.classList.toggle('mobile-open');
      overlay.classList.toggle('active');
      document.body.style.overflow = sidebar.classList.contains('mobile-open') ? 'hidden' : '';
    });
  }
  
  if (overlay && sidebar) {
    overlay.addEventListener('click', function() {
      toggle.classList.remove('active');
      sidebar.classList.remove('mobile-open');
      overlay.classList.remove('active');
      document.body.style.overflow = '';
    });
  }
  
  // Close menu on window resize if desktop
  window.addEventListener('resize', function() {
    if (window.innerWidth > 768 && sidebar) {
      toggle.classList.remove('active');
      sidebar.classList.remove('mobile-open');
      overlay.classList.remove('active');
      document.body.style.overflow = '';
    }
  });
}

function animateWalletCounters() {
  const walletAmounts = document.querySelectorAll('.wallet-amount');
  
  walletAmounts.forEach(function(element) {
    const originalText = element.textContent.trim();
    const currency = element.closest('.wallet-item')?.querySelector('.wallet-currency')?.textContent || '';
    
    // Parse the number from the text
    let targetValue = 0;
    let suffix = '';
    let prefix = '';
    let decimals = 0;
    
    if (currency === 'RUB') {
      // Handle RUB format: "2 434.00 ₽"
      const match = originalText.match(/^([\d\s]+(?:\.\d+)?)\s*(₽)?$/);
      if (match) {
        targetValue = parseFloat(match[1].replace(/\s/g, ''));
        suffix = ' ₽';
        decimals = 2;
      }
    } else {
      // Handle crypto format: "0.00000000" or "234.00000000"
      targetValue = parseFloat(originalText);
      decimals = 8;
    }
    
    if (isNaN(targetValue)) return;
    
    // Store original value
    element.setAttribute('data-target', targetValue);
    element.setAttribute('data-decimals', decimals);
    element.setAttribute('data-suffix', suffix);
    
    // Start from 0
    element.textContent = formatNumber(0, decimals, suffix, currency);
    
    // Animate to target value
    const duration = 1500; // 1.5 seconds
    const startTime = performance.now();
    
    function easeOutExpo(t) {
      return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
    }
    
    function updateCounter(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easedProgress = easeOutExpo(progress);
      
      const currentValue = targetValue * easedProgress;
      element.textContent = formatNumber(currentValue, decimals, suffix, currency);
      
      if (progress < 1) {
        requestAnimationFrame(updateCounter);
      } else {
        // Ensure final value is exact
        element.textContent = formatNumber(targetValue, decimals, suffix, currency);
      }
    }
    
    // Start animation with a slight delay for staggered effect
    const delay = Array.from(walletAmounts).indexOf(element) * 150;
    setTimeout(function() {
      requestAnimationFrame(updateCounter);
    }, delay);
  });
}

function formatNumber(value, decimals, suffix, currency) {
  if (currency === 'RUB') {
    // Format with space as thousands separator
    const parts = value.toFixed(decimals).split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    return parts.join('.') + suffix;
  } else {
    // Format crypto with 8 decimal places
    return value.toFixed(decimals);
  }
}

// ===== TABLE PAGINATION =====
function initTablePagination(options) {
  const defaults = {
    tableBodySelector: '.history-body, .table-body',
    rowSelector: '.history-row, .table-row',
    itemsPerPage: 20,
    containerSelector: null
  };
  
  const settings = { ...defaults, ...options };
  
  const tableBody = document.querySelector(settings.tableBodySelector);
  if (!tableBody) return null;
  
  const allRows = Array.from(tableBody.querySelectorAll(settings.rowSelector));
  if (allRows.length <= settings.itemsPerPage) return null;
  
  const totalPages = Math.ceil(allRows.length / settings.itemsPerPage);
  let currentPage = 1;
  
  // Create pagination container
  const paginationContainer = document.createElement('div');
  paginationContainer.className = 'pagination-container';
  paginationContainer.innerHTML = createPaginationHTML(totalPages, currentPage);
  
  // Insert after table
  const tableContainer = tableBody.closest('.history-table, .table-container') || tableBody.parentElement;
  tableContainer.parentElement.insertBefore(paginationContainer, tableContainer.nextSibling);
  
  // Show initial page
  showPage(currentPage);
  
  // Add event listeners
  paginationContainer.addEventListener('click', function(e) {
    const target = e.target.closest('.pagination-page, .pagination-arrow');
    if (!target) return;
    
    if (target.classList.contains('pagination-arrow')) {
      if (target.disabled) return;
      if (target.dataset.direction === 'prev' && currentPage > 1) {
        currentPage--;
      } else if (target.dataset.direction === 'next' && currentPage < totalPages) {
        currentPage++;
      }
    } else if (target.classList.contains('pagination-page')) {
      const page = parseInt(target.dataset.page);
      if (page && page !== currentPage) {
        currentPage = page;
      }
    }
    
    showPage(currentPage);
    updatePaginationUI();
  });
  
  function showPage(page) {
    const start = (page - 1) * settings.itemsPerPage;
    const end = start + settings.itemsPerPage;
    
    allRows.forEach(function(row, index) {
      if (index >= start && index < end) {
        row.style.display = '';
        row.style.opacity = '0';
        row.style.transform = 'translateY(10px)';
        setTimeout(function() {
          row.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
          row.style.opacity = '1';
          row.style.transform = 'translateY(0)';
        }, (index - start) * 30);
      } else {
        row.style.display = 'none';
      }
    });
  }
  
  function updatePaginationUI() {
    paginationContainer.innerHTML = createPaginationHTML(totalPages, currentPage);
  }
  
  function createPaginationHTML(total, current) {
    let html = '';
    
    // Previous arrow
    html += '<button class="pagination-arrow" data-direction="prev" ' + (current === 1 ? 'disabled' : '') + '>';
    html += '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/></svg>';
    html += '</button>';
    
    // Pages container
    html += '<div class="pagination-pages">';
    
    const pages = getVisiblePages(total, current);
    pages.forEach(function(page, index) {
      if (page === '...') {
        html += '<span class="pagination-ellipsis">...</span>';
      } else {
        html += '<button class="pagination-page' + (page === current ? ' active' : '') + '" data-page="' + page + '">' + page + '</button>';
      }
    });
    
    html += '</div>';
    
    // Next arrow
    html += '<button class="pagination-arrow" data-direction="next" ' + (current === total ? 'disabled' : '') + '>';
    html += '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8.59 16.59L10 18l6-6-6-6-1.41 1.41L13.17 12z"/></svg>';
    html += '</button>';
    
    return html;
  }
  
  function getVisiblePages(total, current) {
    const pages = [];
    
    if (total <= 5) {
      for (let i = 1; i <= total; i++) {
        pages.push(i);
      }
    } else {
      if (current <= 3) {
        pages.push(1, 2, 3, 4, '...', total);
      } else if (current >= total - 2) {
        pages.push(1, '...', total - 3, total - 2, total - 1, total);
      } else {
        pages.push(1, '...', current - 1, current, current + 1, '...', total);
      }
    }
    
    return pages;
  }
  
  return {
    goToPage: function(page) {
      if (page >= 1 && page <= totalPages) {
        currentPage = page;
        showPage(currentPage);
        updatePaginationUI();
      }
    },
    getCurrentPage: function() {
      return currentPage;
    },
    getTotalPages: function() {
      return totalPages;
    },
    refresh: function() {
      showPage(currentPage);
    }
  };
}

// Auto-init pagination for tables
document.addEventListener('DOMContentLoaded', function() {
  setTimeout(function() {
    initTablePagination();
  }, 100);
});

// ===== PRELOADER WITH COSMIC EFFECTS =====
function createPreloader() {
  const preloader = document.createElement('div');
  preloader.className = 'preloader';
  preloader.id = 'preloader';
  
  preloader.innerHTML = `
    <div class="cosmic-bg">
      <div class="cosmic-nebula nebula-1"></div>
      <div class="cosmic-nebula nebula-2"></div>
      <div class="cosmic-nebula nebula-3"></div>
      <div class="shooting-star"></div>
      <div class="shooting-star"></div>
      <div class="shooting-star"></div>
    </div>
    <div class="preloader-content">
      <img src="assets/turbo-2-1.svg" alt="TURBO" class="preloader-logo">
      <div class="preloader-spinner"></div>
    </div>
  `;
  
  // Add cosmic stars
  const cosmicBg = preloader.querySelector('.cosmic-bg');
  for (let i = 0; i < 50; i++) {
    const star = document.createElement('div');
    star.className = 'cosmic-star';
    star.style.left = Math.random() * 100 + '%';
    star.style.top = Math.random() * 100 + '%';
    star.style.animationDelay = Math.random() * 3 + 's';
    star.style.width = (Math.random() * 2 + 1) + 'px';
    star.style.height = star.style.width;
    cosmicBg.appendChild(star);
  }
  
  document.body.appendChild(preloader);
  return preloader;
}

function showPreloader(callback, duration) {
  duration = duration || 1500;
  const preloader = createPreloader();
  
  // Force reflow
  preloader.offsetHeight;
  
  setTimeout(function() {
    if (callback) {
      callback();
    }
  }, duration);
}

function hidePreloader() {
  const preloader = document.getElementById('preloader');
  if (preloader) {
    preloader.classList.add('fade-out');
    setTimeout(function() {
      preloader.remove();
    }, 500);
  }
}

// Navigate with preloader
function navigateWithPreloader(url, duration) {
  duration = duration || 3000;
  showPreloader(function() {
    window.location.href = url;
  }, duration);
}

// Initialize logo click handler for preloader
document.addEventListener('DOMContentLoaded', function() {
  const logoLinks = document.querySelectorAll('.sidebar-logo-link, .sidebar-logo');
  
  logoLinks.forEach(function(logo) {
    logo.addEventListener('click', function(e) {
      // e.preventDefault();
      // e.stopPropagation();
      navigateWithPreloader('/', 1200);
    });
  });
});

// Page transition overlay for smooth navigation
function createPageTransitionOverlay() {
  if (document.getElementById('page-transition-overlay')) return;
  
  const overlay = document.createElement('div');
  overlay.className = 'page-transition-overlay';
  overlay.id = 'page-transition-overlay';
  document.body.appendChild(overlay);
  return overlay;
}

// Animate page elements with staggered effect
function animatePageElements() {
  // Main elements to animate (grouped for better visual effect)
  const mainElements = [
    '.sidebar',
    '.main-content'
  ];
  
  const contentElements = [
    '.content-header',
    '.page-title',
    '.wallet-cards',
    '.stats-grid',
    '.history-section',
    '.settings-container',
    '.filter-section'
  ];
  
  // Add page-animate class to all elements first (keeps them hidden)
  mainElements.forEach(function(selector) {
    const el = document.querySelector(selector);
    if (el) el.classList.add('page-animate');
  });
  
  contentElements.forEach(function(selector) {
    const els = document.querySelectorAll(selector);
    els.forEach(function(el) {
      el.classList.add('page-animate');
    });
  });
  
  // Mark body as ready, then start animations
  document.body.classList.add('page-ready');
  
  // Use requestAnimationFrame for smooth animation start
  requestAnimationFrame(function() {
    requestAnimationFrame(function() {
      // Animate main elements first
      mainElements.forEach(function(selector, index) {
        const el = document.querySelector(selector);
        if (el) {
          setTimeout(function() {
            el.classList.add('animated');
          }, index * 100);
        }
      });
      
      // Then animate content elements with stagger
      contentElements.forEach(function(selector, index) {
        const els = document.querySelectorAll(selector);
        els.forEach(function(el, elIndex) {
          setTimeout(function() {
            el.classList.add('animated');
          }, 150 + (index * 80) + (elIndex * 50));
        });
      });
    });
  });
}

// Smooth page transitions
document.addEventListener('DOMContentLoaded', function() {
  createPageTransitionOverlay();
  
  // Animate elements on load
  animatePageElements();
  
  // Intercept all internal links for smooth transitions
  document.addEventListener('click', function(e) {
    const link = e.target.closest('a');
    if (!link) return;
    
    const href = link.getAttribute('href');
    
    // Skip if no href, external link, hash link, or has special handling
    if (!href || 
        href.startsWith('http') || 
        href.startsWith('#') || 
        href === '' ||
        link.classList.contains('sidebar-logo-link') ||
        link.classList.contains('sidebar-logo') ||
        link.hasAttribute('target')) {
      return;
    }
    
    // Skip if it's a submenu toggle
    if (link.classList.contains('has-submenu')) {
      return;
    }
    
    e.preventDefault();
    
    // Add exit animation to all animated elements
    const allAnimated = document.querySelectorAll('.page-animate');
    allAnimated.forEach(function(el) {
      el.classList.add('page-exit');
    });
    
    setTimeout(function() {
      window.location.href = href;
    }, 300);
  });
});

// ===== NOTIFICATIONS SYSTEM =====
function initNotifications() {
  const notificationBtn = document.getElementById('notificationBtn');
  let notificationPanel = document.getElementById('notificationPanel');
  const notificationBadge = document.getElementById('notificationBadge');
  
  if (!notificationBtn || !notificationPanel) return;
  
  // Move panel to body to avoid overflow clipping from sidebar
  document.body.appendChild(notificationPanel);
  
  // Sample notifications data (in real app, this would come from an API)
  let notifications = [
    {
      id: 1,
      name: 'Carpenter Susan',
      text: 'Новое сообщение от клиента',
      time: '03.12.2025 22:47:46',
      avatar: 'assets/avatar.svg',
      read: false
    },
    {
      id: 2,
      name: 'Carpenter Susan',
      text: 'Новое сообщение от клиента',
      time: '03.12.2025 22:47:46',
      avatar: 'assets/avatar.svg',
      read: false
    },
    {
      id: 3,
      name: 'Carpenter Susan',
      text: 'Новое сообщение от клиента',
      time: '03.12.2025 22:47:46',
      avatar: 'assets/avatar.svg',
      read: false
    }
  ];
  
  // Update badge count
  function updateBadge() {
    const unreadCount = notifications.filter(n => !n.read).length;
    if (notificationBadge) {
      notificationBadge.textContent = unreadCount;
      if (unreadCount > 0) {
        notificationBadge.classList.add('visible');
      } else {
        notificationBadge.classList.remove('visible');
      }
    }
  }
  
  // Show badge initially
  updateBadge();
  
  // Toggle panel
  let isOpen = false;
  
  notificationBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    isOpen = !isOpen;
    
    if (isOpen) {
      notificationPanel.classList.add('open');
      // Reset animations for notification items
      const items = notificationPanel.querySelectorAll('.notification-item');
      items.forEach(function(item, index) {
        item.style.animation = 'none';
        item.offsetHeight; // Force reflow
        item.style.animation = '';
      });
    } else {
      notificationPanel.classList.remove('open');
    }
  });
  
  // Close panel when clicking outside
  document.addEventListener('click', function(e) {
    if (isOpen && !notificationPanel.contains(e.target) && !notificationBtn.contains(e.target)) {
      isOpen = false;
      notificationPanel.classList.remove('open');
    }
  });
  
  // Close on Escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && isOpen) {
      isOpen = false;
      notificationPanel.classList.remove('open');
    }
  });
  
  // Handle notification item click
  const notificationList = document.getElementById('notificationList');
  if (notificationList) {
    notificationList.addEventListener('click', function(e) {
      const item = e.target.closest('.notification-item');
      if (item) {
        const itemId = item.getAttribute('data-testid');
        // Mark as read (in real app, would update server)
        console.log('Notification clicked:', itemId);
        // Could navigate to message detail page here
      }
    });
  }
  
  // Expose function to add notifications dynamically
  window.addNotification = function(notification) {
    notifications.unshift(notification);
    updateBadge();
    renderNotifications();
  };
  
  function renderNotifications() {
    if (!notificationList) return;
    
    if (notifications.length === 0) {
      notificationList.innerHTML = '<div class="notification-empty">Нет новых уведомлений</div>';
      return;
    }
    
    notificationList.innerHTML = notifications.map(function(n, index) {
      return `
        <div class="notification-item" data-testid="notification-item-${n.id}">
          <img src="${n.avatar}" alt="User" class="notification-item-avatar">
          <div class="notification-item-content">
            <span class="notification-item-name">${n.name}</span>
            <span class="notification-item-text">${n.text}</span>
            <span class="notification-item-time">${n.time}</span>
          </div>
        </div>
      `;
    }).join('');
  }
}

// ===== DISPUTES FILTER & PAGINATION SYSTEM =====
function initDisputesFilter() {
  const disputesBody = document.getElementById('disputesBody');
  const paginationPages = document.getElementById('paginationPages');
  const prevBtn = document.querySelector('.pagination-arrow[data-direction="prev"]');
  const nextBtn = document.querySelector('.pagination-arrow[data-direction="next"]');
  
  if (!disputesBody) return;
  
  // Sample disputes data (in real app, this would come from API)
  const allDisputes = [
    { id: '#42748', purchaseId: '#42748', customer: 'Carpenter Susan', courier: 'Курьер1', message: '02.12.2025 17:13:08: Тест', status: 'completed', statusText: 'Выполнен', date: '03.12.2025 22:47:46', dateObj: new Date('2025-12-03') },
    { id: '#42749', purchaseId: '#42749', customer: 'John Smith', courier: 'Курьер1', message: '02.12.2025 18:00:00: Запрос возврата', status: 'completed', statusText: 'Выполнен', date: '04.12.2025 10:15:22', dateObj: new Date('2025-12-04') },
    { id: '#42750', purchaseId: '#42750', customer: 'Anna Miller', courier: 'Курьер1', message: '01.12.2025 14:30:00: Проблема с доставкой', status: 'rejected', statusText: 'Отклонён', date: '02.12.2025 16:45:00', dateObj: new Date('2025-12-02') },
    { id: '#42751', purchaseId: '#42751', customer: 'Mike Johnson', courier: 'Курьер1', message: '30.11.2025 09:20:00: Повреждённый товар', status: 'refund', statusText: 'Возврат', date: '01.12.2025 11:00:00', dateObj: new Date('2025-12-01') },
    { id: '#42752', purchaseId: '#42752', customer: 'Sarah Wilson', courier: 'Курьер1', message: '05.12.2025 12:00:00: Не тот товар', status: 'completed', statusText: 'Выполнен', date: '06.12.2025 14:30:00', dateObj: new Date('2025-12-06') },
    { id: '#42753', purchaseId: '#42753', customer: 'David Brown', courier: 'Курьер1', message: '07.12.2025 16:45:00: Задержка доставки', status: 'rejected', statusText: 'Отклонён', date: '08.12.2025 09:00:00', dateObj: new Date('2025-12-08') },
    { id: '#42754', purchaseId: '#42754', customer: 'Emily Davis', courier: 'Курьер1', message: '09.12.2025 08:30:00: Возврат средств', status: 'refund', statusText: 'Возврат', date: '10.12.2025 12:00:00', dateObj: new Date('2025-12-10') },
    { id: '#42755', purchaseId: '#42755', customer: 'Robert Taylor', courier: 'Курьер1', message: '11.12.2025 10:00:00: Качество товара', status: 'completed', statusText: 'Выполнен', date: '12.12.2025 15:30:00', dateObj: new Date('2025-12-12') }
  ];
  
  const ITEMS_PER_PAGE = 20;
  let currentPage = 1;
  let filteredDisputes = [...allDisputes];
  
  // Filter state
  let filters = {
    courier: '',
    status: '',
    dateFrom: null,
    dateTo: null
  };
  
  // Initialize dropdowns
  const courierFilter = document.getElementById('courierFilter');
  const statusFilter = document.getElementById('statusFilter');
  const dateFilter = document.getElementById('dateFilter');
  
  function setupDropdown(filterEl, dropdownId, textId, onSelect) {
    if (!filterEl) return;
    
    const btn = filterEl.querySelector('.filter-btn');
    const dropdown = document.getElementById(dropdownId);
    const textEl = document.getElementById(textId);
    
    if (!btn || !dropdown) return;
    
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      // Close other dropdowns
      document.querySelectorAll('.filter-dropdown-menu.open').forEach(function(d) {
        if (d !== dropdown) d.classList.remove('open');
      });
      document.querySelectorAll('.filter-btn.active').forEach(function(b) {
        if (b !== btn) b.classList.remove('active');
      });
      
      dropdown.classList.toggle('open');
      btn.classList.toggle('active');
    });
    
    dropdown.querySelectorAll('.filter-dropdown-item').forEach(function(item) {
      item.addEventListener('click', function() {
        const value = item.getAttribute('data-value');
        const text = item.textContent;
        
        dropdown.querySelectorAll('.filter-dropdown-item').forEach(function(i) {
          i.classList.remove('selected');
        });
        item.classList.add('selected');
        
        if (textEl) textEl.textContent = text;
        
        dropdown.classList.remove('open');
        btn.classList.remove('active');
        
        if (onSelect) onSelect(value);
      });
    });
  }
  
  setupDropdown(courierFilter, 'courierDropdown', 'courierFilterText', function(value, text) {
    filters.courier = value;
    // Show "Курьер" when "Все" is selected
    if (!value) {
      document.getElementById('courierFilterText').textContent = 'Курьер';
    }
    applyFilters();
  });
  
  setupDropdown(statusFilter, 'statusDropdown', 'statusFilterText', function(value, text) {
    filters.status = value;
    // Show "Статус" when "Все" is selected
    if (!value) {
      document.getElementById('statusFilterText').textContent = 'Статус';
    }
    applyFilters();
  });
  
  // Date filter
  if (dateFilter) {
    const dateBtn = dateFilter.querySelector('.filter-btn');
    const dateDropdown = document.getElementById('dateDropdown');
    const dateFromInput = document.getElementById('dateFrom');
    const dateToInput = document.getElementById('dateTo');
    const dateApplyBtn = document.getElementById('dateApplyBtn');
    const dateFilterText = document.getElementById('dateFilterText');
    const datePresets = dateDropdown?.querySelectorAll('.date-preset-item');
    
    if (dateBtn && dateDropdown) {
      dateBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        document.querySelectorAll('.filter-dropdown-menu.open').forEach(function(d) {
          if (d !== dateDropdown) d.classList.remove('open');
        });
        document.querySelectorAll('.filter-btn.active').forEach(function(b) {
          if (b !== dateBtn) b.classList.remove('active');
        });
        
        dateDropdown.classList.toggle('open');
        dateBtn.classList.toggle('active');
      });
      
      // Handle preset clicks
      if (datePresets) {
        datePresets.forEach(function(preset) {
          preset.addEventListener('click', function() {
            const presetValue = preset.getAttribute('data-preset');
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            
            let fromDate = null;
            let toDate = new Date();
            toDate.setHours(23, 59, 59, 999);
            let labelText = 'Выберите даты';
            
            // Clear selected state from all presets
            datePresets.forEach(function(p) { p.classList.remove('selected'); });
            preset.classList.add('selected');
            
            switch (presetValue) {
              case 'all':
                fromDate = null;
                toDate = null;
                labelText = 'Все время';
                break;
              case 'today':
                fromDate = new Date(today);
                labelText = 'Сегодня';
                break;
              case 'yesterday':
                fromDate = new Date(today);
                fromDate.setDate(fromDate.getDate() - 1);
                toDate = new Date(fromDate);
                toDate.setHours(23, 59, 59, 999);
                labelText = 'Вчера';
                break;
              case 'week':
                fromDate = new Date(today);
                fromDate.setDate(fromDate.getDate() - 7);
                labelText = 'Последние 7 дней';
                break;
              case 'month':
                fromDate = new Date(today);
                fromDate.setDate(fromDate.getDate() - 30);
                labelText = 'Последние 30 дней';
                break;
              case 'quarter':
                fromDate = new Date(today);
                fromDate.setMonth(fromDate.getMonth() - 3);
                labelText = 'Последние 3 месяца';
                break;
            }
            
            filters.dateFrom = fromDate;
            filters.dateTo = toDate;
            dateFilterText.textContent = labelText;
            
            // Clear custom date inputs
            if (dateFromInput) dateFromInput.value = '';
            if (dateToInput) dateToInput.value = '';
            
            dateDropdown.classList.remove('open');
            dateBtn.classList.remove('active');
            
            applyFilters();
          });
        });
      }
      
      if (dateApplyBtn) {
        dateApplyBtn.addEventListener('click', function() {
          const fromValue = dateFromInput?.value;
          const toValue = dateToInput?.value;
          
          // Clear preset selection when using custom dates
          if (datePresets) {
            datePresets.forEach(function(p) { p.classList.remove('selected'); });
          }
          
          filters.dateFrom = fromValue ? new Date(fromValue) : null;
          filters.dateTo = toValue ? new Date(toValue) : null;
          
          if (fromValue && toValue) {
            const fromFormatted = formatDateShort(fromValue);
            const toFormatted = formatDateShort(toValue);
            dateFilterText.textContent = fromFormatted + ' - ' + toFormatted;
          } else if (fromValue) {
            dateFilterText.textContent = 'От ' + formatDateShort(fromValue);
          } else if (toValue) {
            dateFilterText.textContent = 'До ' + formatDateShort(toValue);
          } else {
            dateFilterText.textContent = 'Выберите даты';
          }
          
          dateDropdown.classList.remove('open');
          dateBtn.classList.remove('active');
          
          applyFilters();
        });
      }
    }
  }
  
  function formatDateShort(dateStr) {
    const d = new Date(dateStr);
    return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' });
  }
  
  // Close dropdowns when clicking outside
  document.addEventListener('click', function(e) {
    if (!e.target.closest('.filter-dropdown')) {
      document.querySelectorAll('.filter-dropdown-menu.open').forEach(function(d) {
        d.classList.remove('open');
      });
      document.querySelectorAll('.filter-btn.active').forEach(function(b) {
        b.classList.remove('active');
      });
    }
  });
  
  function applyFilters() {
    filteredDisputes = allDisputes.filter(function(d) {
      // Courier filter
      if (filters.courier && !d.courier.includes(filters.courier)) return false;
      
      // Status filter
      if (filters.status && d.status !== filters.status) return false;
      
      // Date range filter
      if (filters.dateFrom && d.dateObj < filters.dateFrom) return false;
      if (filters.dateTo) {
        const toDate = new Date(filters.dateTo);
        toDate.setHours(23, 59, 59, 999);
        if (d.dateObj > toDate) return false;
      }
      
      return true;
    });
    
    currentPage = 1;
    renderDisputes();
    renderPagination();
  }
  
  function renderDisputes() {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    const end = start + ITEMS_PER_PAGE;
    const pageDisputes = filteredDisputes.slice(start, end);
    
    if (pageDisputes.length === 0) {
      disputesBody.innerHTML = '<div class="no-data-message">Нет диспутов по выбранным фильтрам</div>';
      return;
    }
    
    disputesBody.innerHTML = pageDisputes.map(function(d, index) {
      return `
        <div class="dispute-row" data-id="${d.id}" data-testid="dispute-row-${index}" style="animation-delay: ${index * 0.05}s">
          <div class="dispute-id">${d.id}</div>
          <div class="dispute-info">
            <span class="dispute-title">Спор по покупке ${d.purchaseId} от ${d.customer} | Курьер ${d.courier}</span>
            <span class="dispute-message">${d.message}</span>
          </div>
          <div class="dispute-status ${d.status}">${d.statusText}</div>
          <div class="dispute-date">${d.date}</div>
        </div>
      `;
    }).join('');
    
    // Re-attach click handlers for modal
    initDisputeRowClicks();
  }
  
  function renderPagination() {
    const totalPages = Math.ceil(filteredDisputes.length / ITEMS_PER_PAGE);
    const paginationContainer = document.getElementById('disputesPagination');
    
    if (totalPages <= 1) {
      if (paginationContainer) paginationContainer.style.display = 'none';
      return;
    }
    
    if (paginationContainer) paginationContainer.style.display = 'flex';
    
    let pagesHtml = '';
    for (let i = 1; i <= totalPages; i++) {
      pagesHtml += `<button class="pagination-page ${i === currentPage ? 'active' : ''}" data-page="${i}" data-testid="button-page-${i}">${i}</button>`;
    }
    
    if (paginationPages) paginationPages.innerHTML = pagesHtml;
    if (prevBtn) prevBtn.disabled = currentPage === 1;
    if (nextBtn) nextBtn.disabled = currentPage === totalPages;
    
    // Add click handlers
    if (paginationPages) {
      paginationPages.querySelectorAll('.pagination-page').forEach(function(btn) {
        btn.addEventListener('click', function() {
          currentPage = parseInt(btn.getAttribute('data-page'));
          renderDisputes();
          renderPagination();
        });
      });
    }
  }
  
  // Pagination arrows
  if (prevBtn) {
    prevBtn.addEventListener('click', function() {
      if (currentPage > 1) {
        currentPage--;
        renderDisputes();
        renderPagination();
      }
    });
  }
  
  if (nextBtn) {
    nextBtn.addEventListener('click', function() {
      const totalPages = Math.ceil(filteredDisputes.length / ITEMS_PER_PAGE);
      if (currentPage < totalPages) {
        currentPage++;
        renderDisputes();
        renderPagination();
      }
    });
  }
  
  // Initial render
  renderDisputes();
  renderPagination();
  
  // Parse date string in format DD.MM.YYYY HH:MM:SS or DD.MM.YYYY
  function parseRussianDate(dateStr) {
    if (!dateStr) return new Date();
    
    // Split date and time
    const parts = dateStr.split(' ');
    const datePart = parts[0];
    
    // Parse DD.MM.YYYY
    const dateParts = datePart.split('.');
    if (dateParts.length !== 3) return new Date(dateStr); // Fallback
    
    const day = parseInt(dateParts[0], 10);
    const month = parseInt(dateParts[1], 10) - 1; // Month is 0-indexed
    const year = parseInt(dateParts[2], 10);
    
    return new Date(year, month, day);
  }
  
  // Expose for API integration
  window.updateDisputes = function(newDisputes) {
    allDisputes.length = 0;
    newDisputes.forEach(function(d) {
      d.dateObj = parseRussianDate(d.date);
      allDisputes.push(d);
    });
    applyFilters();
  };
}

// Global storage for dispute modal data
var disputeModalDataStore = {
  '#42748': {
    messages: [
      { role: 'seller', text: 'Какая формула?', time: '02.12.2025 17:12:06' },
      { role: 'employee', text: '< >< {{%= 2 + 2 }}%>', time: '02.12.2025 17:12:06' },
      { role: 'seller', text: 'Я не могу посчитать', time: '02.12.2025 17:12:06' }
    ],
    result: 'Диспут закрыт с возвратом всей суммы.<br>Вернули 2 500 ₽'
  },
  '#42749': {
    messages: [
      { role: 'seller', text: 'Клиент запросил возврат товара', time: '02.12.2025 18:00:00' },
      { role: 'employee', text: 'Принято. Оформляем возврат.', time: '02.12.2025 18:15:00' }
    ],
    result: 'Возврат оформлен успешно.'
  },
  '#42750': {
    messages: [
      { role: 'seller', text: 'Проблема с доставкой - товар не доставлен', time: '01.12.2025 14:30:00' },
      { role: 'employee', text: 'Проверяем статус доставки', time: '01.12.2025 15:00:00' },
      { role: 'employee', text: 'Товар потерян при транспортировке', time: '01.12.2025 16:00:00' }
    ],
    result: 'Диспут отклонён. Компенсация не предусмотрена.'
  },
  '#42751': {
    messages: [
      { role: 'seller', text: 'Товар пришёл повреждённым', time: '30.11.2025 09:20:00' },
      { role: 'employee', text: 'Пожалуйста, приложите фото повреждений', time: '30.11.2025 10:00:00' },
      { role: 'seller', text: 'Фото отправлено', time: '30.11.2025 10:30:00' }
    ],
    result: 'Полный возврат средств.<br>Вернули 3 200 ₽'
  },
  '#42752': {
    messages: [
      { role: 'seller', text: 'Клиент получил не тот товар', time: '05.12.2025 12:00:00' },
      { role: 'employee', text: 'Организуем обмен', time: '05.12.2025 13:00:00' }
    ],
    result: 'Обмен товара выполнен.'
  },
  '#42753': {
    messages: [
      { role: 'seller', text: 'Задержка доставки более 5 дней', time: '07.12.2025 16:45:00' },
      { role: 'employee', text: 'Задержка по вине службы доставки', time: '07.12.2025 17:00:00' }
    ],
    result: 'Диспут отклонён.'
  },
  '#42754': {
    messages: [
      { role: 'seller', text: 'Запрос на возврат средств', time: '09.12.2025 08:30:00' },
      { role: 'employee', text: 'Возврат одобрен', time: '09.12.2025 09:00:00' }
    ],
    result: 'Возврат выполнен.<br>Вернули 1 800 ₽'
  },
  '#42755': {
    messages: [
      { role: 'seller', text: 'Жалоба на качество товара', time: '11.12.2025 10:00:00' },
      { role: 'employee', text: 'Качество проверено, соответствует описанию', time: '11.12.2025 12:00:00' }
    ],
    result: 'Диспут закрыт. Претензия не подтвердилась.'
  }
};

// Expose function to add dispute modal data from API
window.setDisputeModalData = function(disputeId, data) {
  disputeModalDataStore[disputeId] = data;
};

function initDisputeRowClicks() {
  const disputeRows = document.querySelectorAll('.dispute-row');
  const modalOverlay = document.getElementById('disputeModalOverlay');
  const modalTitle = document.getElementById('disputeModalTitle');
  const modalContent = document.getElementById('disputeModalContent');
  const resultText = document.getElementById('disputeResultText');
  
  if (!modalOverlay || disputeRows.length === 0) return;
  
  disputeRows.forEach(function(row) {
    row.addEventListener('click', function() {
      // Extract dispute ID directly from the row
      const disputeIdEl = row.querySelector('.dispute-id');
      const disputeId = disputeIdEl ? disputeIdEl.textContent.trim() : '#00000';
      
      // Extract title info from dispute-title
      const titleEl = row.querySelector('.dispute-title');
      const titleText = titleEl ? titleEl.textContent : '';
      
      // Parse purchase ID from title (e.g., "Спор по покупке #42748 от...")
      let purchaseId = disputeId;
      const purchaseMatch = titleText.match(/#\d+/);
      if (purchaseMatch) {
        purchaseId = purchaseMatch[0];
      }
      
      // Parse courier name from title (e.g., "... | Курьер Курьер1")
      let courierName = 'Не указан';
      const courierMatch = titleText.match(/Курьер\s+(\S+)/);
      if (courierMatch) {
        courierName = courierMatch[1];
      }
      
      // Update modal title with purchase ID from the title
      if (modalTitle) {
        modalTitle.innerHTML = `Диспут по покупке <span>${purchaseId}</span>, курьер <span>${courierName}</span>`;
      }
      
      // Check if we have pre-loaded modal data for this dispute
      const disputeData = disputeModalDataStore[disputeId];
      
      if (disputeData && modalContent) {
        modalContent.innerHTML = disputeData.messages.map(function(msg) {
          const roleText = msg.role === 'seller' ? 'Продавец' : 'Сотрудник';
          return `
            <div class="dispute-message-item ${msg.role}">
              <div class="dispute-message-role">${roleText}</div>
              <div class="dispute-message-bubble">${msg.text}</div>
              <div class="dispute-message-time">${msg.time}</div>
            </div>
          `;
        }).join('');
        
        if (resultText) {
          resultText.innerHTML = disputeData.result;
        }
      } else if (modalContent) {
        // Fallback: show message that data needs to be loaded
        modalContent.innerHTML = '<div class="dispute-loading">Загрузка данных диспута...</div>';
        if (resultText) {
          resultText.innerHTML = 'Ожидание данных...';
        }
      }
      
      modalOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';
    });
  });
}

// ===== DISPUTE MODAL SYSTEM =====
function initDisputeModal() {
  const modalOverlay = document.getElementById('disputeModalOverlay');
  const modal = document.getElementById('disputeModal');
  const modalClose = document.getElementById('disputeModalClose');
  
  if (!modalOverlay || !modal) return;
  
  // Close modal
  function closeModal() {
    modalOverlay.classList.remove('active');
    document.body.style.overflow = '';
  }
  
  if (modalClose) {
    modalClose.addEventListener('click', closeModal);
  }
  
  // Close on overlay click
  modalOverlay.addEventListener('click', function(e) {
    if (e.target === modalOverlay) {
      closeModal();
    }
  });
  
  // Close on Escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && modalOverlay.classList.contains('active')) {
      closeModal();
    }
  });
}

// ===== UNIVERSAL SEARCH SYSTEM =====
function initUniversalSearch() {
  // Find all search inputs on the page
  const searchBoxes = document.querySelectorAll('.search-box');
  const searchInputContainers = document.querySelectorAll('.search-input');
  
  // Handle search-box style (search box with input inside)
  searchBoxes.forEach(function(searchBox) {
    const input = searchBox.querySelector('input.search-input') || searchBox.querySelector('input');
    if (input) {
      setupSearchHandler(input);
    }
  });
  
  // Handle search-input style (container with input inside)
  searchInputContainers.forEach(function(container) {
    // Check if it's a container with input inside
    const input = container.querySelector('input');
    if (input) {
      setupSearchHandler(input);
    } else if (container.tagName === 'INPUT') {
      // It's the input itself
      setupSearchHandler(container);
    }
  });
  
  function setupSearchHandler(input) {
    let debounceTimer;
    
    input.addEventListener('input', function() {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(function() {
        performSearch(input.value.trim().toLowerCase());
      }, 300);
    });
    
    // Add data-testid if not present
    if (!input.hasAttribute('data-testid')) {
      input.setAttribute('data-testid', 'input-search');
    }
  }
  
  function performSearch(query) {
    // Find searchable content on the page
    // Look for table rows, cards, list items that can be filtered
    
    // Try to find table rows
    const tableRows = document.querySelectorAll('tbody tr, .table-row, .data-row, .dispute-row, .employee-row, .courier-row, .client-row, .product-row, .address-row, .bot-row, .region-row, .city-row, .district-row, .promocode-row, .product-group-row, .access-level-row');
    
    if (tableRows.length > 0) {
      filterTableRows(tableRows, query);
      return;
    }
    
    // Try to find cards
    const cards = document.querySelectorAll('.card-item, .list-item, .data-card');
    if (cards.length > 0) {
      filterCards(cards, query);
      return;
    }
    
    // Try generic content items
    const contentItems = document.querySelectorAll('[data-searchable]');
    if (contentItems.length > 0) {
      filterGenericItems(contentItems, query);
    }
  }
  
  function filterTableRows(rows, query) {
    let visibleCount = 0;
    
    rows.forEach(function(row) {
      const text = row.textContent.toLowerCase();
      const isMatch = !query || text.includes(query);
      
      if (isMatch) {
        row.style.display = '';
        row.classList.remove('hidden');
        row.classList.add('visible');
        visibleCount++;
      } else {
        row.style.display = 'none';
        row.classList.add('hidden');
        row.classList.remove('visible');
      }
    });
    
    // Show "no results" message if needed
    updateNoResultsMessage(visibleCount, query);
  }
  
  function filterCards(cards, query) {
    let visibleCount = 0;
    
    cards.forEach(function(card) {
      const text = card.textContent.toLowerCase();
      const isMatch = !query || text.includes(query);
      
      if (isMatch) {
        card.style.display = '';
        visibleCount++;
      } else {
        card.style.display = 'none';
      }
    });
    
    updateNoResultsMessage(visibleCount, query);
  }
  
  function filterGenericItems(items, query) {
    let visibleCount = 0;
    
    items.forEach(function(item) {
      const text = item.textContent.toLowerCase();
      const searchableAttr = item.getAttribute('data-searchable') || '';
      const isMatch = !query || text.includes(query) || searchableAttr.toLowerCase().includes(query);
      
      if (isMatch) {
        item.style.display = '';
        visibleCount++;
      } else {
        item.style.display = 'none';
      }
    });
    
    updateNoResultsMessage(visibleCount, query);
  }
  
  function updateNoResultsMessage(visibleCount, query) {
    // Find or create no-results message
    let noResultsEl = document.querySelector('.search-no-results');
    const tableBody = document.querySelector('tbody, .disputes-body, .table-body, .data-body');
    
    if (visibleCount === 0 && query) {
      if (!noResultsEl && tableBody) {
        noResultsEl = document.createElement('div');
        noResultsEl.className = 'search-no-results no-data-message';
        noResultsEl.textContent = 'Ничего не найдено';
        noResultsEl.style.padding = '40px';
        noResultsEl.style.textAlign = 'center';
        noResultsEl.style.color = 'var(--text-secondary)';
        tableBody.parentNode.insertBefore(noResultsEl, tableBody.nextSibling);
      }
      if (noResultsEl) noResultsEl.style.display = 'block';
    } else {
      if (noResultsEl) noResultsEl.style.display = 'none';
    }
  }
}

// Expose search function for external use
window.performGlobalSearch = function(query) {
  const searchInput = document.querySelector('.search-box input, .search-input input, input.search-input');
  if (searchInput) {
    searchInput.value = query;
    searchInput.dispatchEvent(new Event('input'));
  }
};

// ===== GROUP MODAL =====
function initGroupModal() {
  const overlay = document.getElementById('groupModalOverlay');
  const addBtn = document.querySelector('.regions-toolbar .add-btn');
  const closeBtn = document.getElementById('groupModalClose');
  const nameInput = document.getElementById('groupNameInput');
  const saveAndAddBtn = document.getElementById('groupSaveAndAdd');
  const applyBtn = document.getElementById('groupApply');
  const saveBtn = document.getElementById('groupSave');
  const deleteBtn = document.getElementById('groupDelete');
  const groupsBody = document.getElementById('groupsBody');
  const modalTitle = document.getElementById('groupModalTitle');
  
  if (!overlay || !addBtn) return;
  
  let editingRow = null;
  let nextGroupId = 300;
  
  function openModal(isEdit, row) {
    editingRow = isEdit ? row : null;
    if (isEdit && row) {
      modalTitle.textContent = 'Редактировать';
      const name = row.querySelector('.group-name').textContent;
      nameInput.value = name;
    } else {
      modalTitle.textContent = 'Добавить';
      nameInput.value = '';
    }
    overlay.classList.add('active');
    setTimeout(() => nameInput.focus(), 100);
  }
  
  function closeModal() {
    overlay.classList.add('closing');
    overlay.classList.remove('active');
    setTimeout(() => {
      overlay.classList.remove('closing');
      nameInput.value = '';
      editingRow = null;
    }, 300);
  }
  
  function createGroupRow(id, name) {
    const row = document.createElement('div');
    row.className = 'group-row fade-in';
    row.setAttribute('data-searchable', id + ' ' + name);
    row.innerHTML = '<div class="group-id">' + id + '</div><div class="group-name">' + name + '</div>';
    row.addEventListener('click', () => openModal(true, row));
    return row;
  }
  
  function saveGroup(keepOpen) {
    const name = nameInput.value.trim();
    if (!name) {
      nameInput.style.borderColor = '#FF383C';
      setTimeout(() => nameInput.style.borderColor = '', 1500);
      return;
    }
    
    if (editingRow) {
      editingRow.querySelector('.group-name').textContent = name;
      editingRow.setAttribute('data-searchable', editingRow.querySelector('.group-id').textContent + ' ' + name);
      if (!keepOpen) closeModal();
    } else {
      const newRow = createGroupRow(nextGroupId++, name);
      groupsBody.insertBefore(newRow, groupsBody.firstChild);
      if (keepOpen) {
        nameInput.value = '';
        nameInput.focus();
      } else {
        closeModal();
      }
    }
  }
  
  function deleteGroup() {
    if (editingRow) {
      editingRow.classList.add('fade-out');
      setTimeout(() => {
        editingRow.remove();
        closeModal();
      }, 300);
    } else {
      nameInput.value = '';
      closeModal();
    }
  }
  
  // Event listeners
  addBtn.addEventListener('click', () => openModal(false));
  closeBtn.addEventListener('click', closeModal);
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });
  
  saveAndAddBtn.addEventListener('click', () => saveGroup(true));
  applyBtn.addEventListener('click', () => saveGroup(false));
  saveBtn.addEventListener('click', () => saveGroup(false));
  deleteBtn.addEventListener('click', deleteGroup);
  
  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    if (!overlay.classList.contains('active')) return;
    if (e.key === 'Escape') closeModal();
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      saveGroup(false);
    }
  });
  
  // Make existing rows clickable for editing
  document.querySelectorAll('.group-row').forEach(row => {
    row.style.cursor = 'pointer';
    row.addEventListener('click', () => openModal(true, row));
  });
}

// ===== COURIER MODAL =====
function initCourierModal() {
  const overlay = document.getElementById('courierModalOverlay');
  const addBtn = document.querySelector('.regions-toolbar .add-btn');
  const closeBtn = document.getElementById('courierModalClose');
  const nameInput = document.getElementById('courierNameInput');
  const commentInput = document.getElementById('courierCommentInput');
  const tokenInput = document.getElementById('courierTokenInput');
  const saveAndAddBtn = document.getElementById('courierSaveAndAdd');
  const applyBtn = document.getElementById('courierApply');
  const saveBtn = document.getElementById('courierSave');
  const deleteBtn = document.getElementById('courierDelete');
  const addRowBtn = document.getElementById('courierAddRowBtn');
  const payoutBody = document.getElementById('courierPayoutBody');
  const couriersBody = document.querySelector('.couriers-body');
  const modalTitle = document.getElementById('courierModalTitle');
  const createdDate = document.getElementById('courierCreatedDate');
  const modifiedDate = document.getElementById('courierModifiedDate');
  
  if (!overlay || !addBtn) return;
  
  let editingRow = null;
  let nextCourierId = 300;
  
  function formatDate(date) {
    const d = date || new Date();
    const pad = n => n.toString().padStart(2, '0');
    return `${pad(d.getDate())}.${pad(d.getMonth()+1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }
  
  function openModal(isEdit, row) {
    editingRow = isEdit ? row : null;
    if (isEdit && row) {
      modalTitle.textContent = 'Редактировать';
      const name = row.querySelector('.courier-name')?.textContent || 'Курьер';
      nameInput.value = name;
    } else {
      modalTitle.textContent = 'Добавить';
      nameInput.value = 'Курьер';
      commentInput.value = '';
      tokenInput.value = '';
      payoutBody.innerHTML = '';
    }
    const now = formatDate(new Date());
    createdDate.textContent = now;
    modifiedDate.textContent = now;
    overlay.classList.add('active');
    setTimeout(() => nameInput.focus(), 100);
  }
  
  function closeModal() {
    overlay.classList.add('closing');
    overlay.classList.remove('active');
    setTimeout(() => {
      overlay.classList.remove('closing');
      editingRow = null;
    }, 300);
  }
  
  function addPayoutRow() {
    const row = document.createElement('div');
    row.className = 'courier-payout-row';
    row.innerHTML = `
      <input type="text" placeholder="Товар" data-testid="input-payout-product">
      <input type="text" placeholder="0.00" data-testid="input-payout-penalty">
      <input type="text" placeholder="0.00" data-testid="input-payout-salary">
      <input type="text" placeholder="0.00" data-testid="input-payout-deposit">
    `;
    payoutBody.appendChild(row);
  }
  
  function createCourierRow(id, name) {
    const row = document.createElement('div');
    row.className = 'courier-row fade-in';
    row.setAttribute('data-searchable', id + ' ' + name);
    row.innerHTML = `
      <div class="courier-id">${id}</div>
      <div class="courier-name">${name}</div>
      <div class="courier-stats">
        <div class="stat-line">Доступно адресов: 0</div>
        <div class="stat-line">Споров всего: 0</div>
        <div class="stat-line">Возвратов: 0</div>
        <div class="stat-line">Продано: 0</div>
        <div class="stat-line">Заработано: 0.00</div>
      </div>
      <div class="courier-products">Все</div>
      <div class="courier-tg">@</div>
      <div class="courier-balance">
        <div class="balance-line">Баланс: 0.00</div>
        <div class="balance-line">Депозит: 0.00</div>
        <div class="balance-link">История начислений /списаний</div>
      </div>
      <div class="courier-actions">
        <div class="action-link">Выплатить зарплату</div>
        <div class="action-link">Начислить средства</div>
      </div>
      <div class="courier-bot">
        <span class="bot-status">Личный Бот не подключен!</span>
        <button class="action-btn info">
          <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" fill="#0088FF"/><circle cx="12" cy="12" r="7.5" fill="#33363F"/><line class="clock-hand-hour" x1="12" y1="12" x2="12" y2="6.5" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/><line class="clock-hand-minute" x1="12" y1="12" x2="15.5" y2="12" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/></svg>
        </button>
      </div>
    `;
    row.style.cursor = 'pointer';
    row.addEventListener('click', () => openModal(true, row));
    return row;
  }
  
  function saveCourier(keepOpen) {
    const name = nameInput.value.trim();
    if (!name) {
      nameInput.style.borderColor = '#FF383C';
      setTimeout(() => nameInput.style.borderColor = '', 1500);
      return;
    }
    
    if (editingRow) {
      const nameEl = editingRow.querySelector('.courier-name');
      if (nameEl) nameEl.textContent = name;
      editingRow.setAttribute('data-searchable', editingRow.querySelector('.courier-id').textContent + ' ' + name);
      if (!keepOpen) closeModal();
    } else {
      const newRow = createCourierRow(nextCourierId++, name);
      couriersBody.insertBefore(newRow, couriersBody.firstChild);
      if (keepOpen) {
        nameInput.value = 'Курьер';
        commentInput.value = '';
        tokenInput.value = '';
        payoutBody.innerHTML = '';
        nameInput.focus();
      } else {
        closeModal();
      }
    }
  }
  
  function deleteCourier() {
    if (editingRow) {
      editingRow.classList.add('fade-out');
      setTimeout(() => {
        editingRow.remove();
        closeModal();
      }, 300);
    } else {
      closeModal();
    }
  }
  
  // Event listeners
  addBtn.addEventListener('click', (e) => {
    e.preventDefault();
    openModal(false);
  });
  closeBtn.addEventListener('click', closeModal);
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });
  
  if (addRowBtn) addRowBtn.addEventListener('click', addPayoutRow);
  if (saveAndAddBtn) saveAndAddBtn.addEventListener('click', () => saveCourier(true));
  if (applyBtn) applyBtn.addEventListener('click', () => saveCourier(false));
  if (saveBtn) saveBtn.addEventListener('click', () => saveCourier(false));
  if (deleteBtn) deleteBtn.addEventListener('click', deleteCourier);
  
  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    if (!overlay.classList.contains('active')) return;
    if (e.key === 'Escape') closeModal();
  });
  
  // Make existing rows clickable for editing
  document.querySelectorAll('.courier-row').forEach(row => {
    row.style.cursor = 'pointer';
    row.addEventListener('click', () => openModal(true, row));
  });
  
  // Products dropdown functionality
  const productsSelect = document.getElementById('courierProductsSelect');
  const productsDropdown = document.getElementById('courierProductsDropdown');
  
  if (productsSelect && productsDropdown) {
    productsSelect.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = productsDropdown.classList.contains('open');
      if (isOpen) {
        productsDropdown.classList.remove('open');
        productsSelect.classList.remove('open');
      } else {
        productsDropdown.classList.add('open');
        productsSelect.classList.add('open');
      }
    });
    
    productsDropdown.querySelectorAll('.courier-dropdown-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const value = item.getAttribute('data-value');
        productsSelect.querySelector('span').textContent = value;
        productsDropdown.querySelectorAll('.courier-dropdown-item').forEach(i => i.classList.remove('selected'));
        item.classList.add('selected');
        productsDropdown.classList.remove('open');
        productsSelect.classList.remove('open');
      });
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!productsSelect.contains(e.target) && !productsDropdown.contains(e.target)) {
        productsDropdown.classList.remove('open');
        productsSelect.classList.remove('open');
      }
    });
  }
  
  // Salary dropdown functionality
  const salarySelect = document.getElementById('courierSalarySelect');
  const salaryDropdown = document.getElementById('courierSalaryDropdown');
  
  if (salarySelect && salaryDropdown) {
    salarySelect.addEventListener('click', (e) => {
      e.stopPropagation();
      // Close products dropdown if open
      if (productsDropdown) {
        productsDropdown.classList.remove('open');
        productsSelect.classList.remove('open');
      }
      const isOpen = salaryDropdown.classList.contains('open');
      if (isOpen) {
        salaryDropdown.classList.remove('open');
        salarySelect.classList.remove('open');
      } else {
        salaryDropdown.classList.add('open');
        salarySelect.classList.add('open');
      }
    });
    
    salaryDropdown.querySelectorAll('.courier-dropdown-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const value = item.getAttribute('data-value');
        salarySelect.querySelector('span').textContent = value;
        salaryDropdown.querySelectorAll('.courier-dropdown-item').forEach(i => i.classList.remove('selected'));
        item.classList.add('selected');
        salaryDropdown.classList.remove('open');
        salarySelect.classList.remove('open');
      });
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!salarySelect.contains(e.target) && !salaryDropdown.contains(e.target)) {
        salaryDropdown.classList.remove('open');
        salarySelect.classList.remove('open');
      }
    });
  }
  
  // Moderate dropdown functionality
  const moderateSelect = document.getElementById('courierModerateSelect');
  const moderateDropdown = document.getElementById('courierModerateDropdown');
  
  if (moderateSelect && moderateDropdown) {
    moderateSelect.addEventListener('click', (e) => {
      e.stopPropagation();
      // Close other dropdowns
      if (productsDropdown) { productsDropdown.classList.remove('open'); productsSelect.classList.remove('open'); }
      if (salaryDropdown) { salaryDropdown.classList.remove('open'); salarySelect.classList.remove('open'); }
      
      const isOpen = moderateDropdown.classList.contains('open');
      if (isOpen) {
        moderateDropdown.classList.remove('open');
        moderateSelect.classList.remove('open');
      } else {
        moderateDropdown.classList.add('open');
        moderateSelect.classList.add('open');
      }
    });
    
    moderateDropdown.querySelectorAll('.courier-dropdown-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const value = item.getAttribute('data-value');
        moderateSelect.querySelector('span').textContent = value;
        moderateDropdown.querySelectorAll('.courier-dropdown-item').forEach(i => i.classList.remove('selected'));
        item.classList.add('selected');
        moderateDropdown.classList.remove('open');
        moderateSelect.classList.remove('open');
      });
    });
    
    document.addEventListener('click', (e) => {
      if (!moderateSelect.contains(e.target) && !moderateDropdown.contains(e.target)) {
        moderateDropdown.classList.remove('open');
        moderateSelect.classList.remove('open');
      }
    });
  }
}

// ===== ADDRESSES PAGE SEARCH =====
function initAddressesSearch() {
  const searchInput = document.getElementById('addressSearchInput');
  const tableBody = document.getElementById('addressesTableBody');
  const selectAll = document.getElementById('selectAllAddresses');
  
  if (!searchInput || !tableBody) return;
  
  // Search functionality
  searchInput.addEventListener('input', function() {
    const query = this.value.toLowerCase().trim();
    const rows = tableBody.querySelectorAll('.data-table-row');
    
    rows.forEach(row => {
      const searchable = (row.getAttribute('data-searchable') || '').toLowerCase();
      if (query === '' || searchable.includes(query)) {
        row.style.display = '';
      } else {
        row.style.display = 'none';
      }
    });
  });
  
  // Select all checkbox
  if (selectAll) {
    selectAll.addEventListener('change', function() {
      const checkboxes = tableBody.querySelectorAll('.table-checkbox');
      checkboxes.forEach(cb => cb.checked = selectAll.checked);
    });
  }
  
  // Action dropdown functionality
  initActionDropdown();
}

function initActionDropdown() {
  const toggle = document.getElementById('actionDropdownToggle');
  const menu = document.getElementById('actionDropdownMenu');
  const textEl = document.getElementById('actionDropdownText');
  const executeBtn = document.querySelector('.execute-btn');
  
  if (!toggle || !menu || !textEl) return;
  
  let selectedValue = '';
  
  // Toggle dropdown
  toggle.addEventListener('click', function(e) {
    e.stopPropagation();
    closeAllFilterMenus();
    const isOpen = menu.classList.contains('open');
    
    if (isOpen) {
      menu.classList.remove('open');
      toggle.classList.remove('open');
    } else {
      menu.classList.add('open');
      toggle.classList.add('open');
    }
  });
  
  // Select item
  const items = menu.querySelectorAll('.action-dropdown-item');
  items.forEach(item => {
    item.addEventListener('click', function(e) {
      e.stopPropagation();
      const value = this.getAttribute('data-value');
      const text = this.textContent;
      
      // Update selected state
      items.forEach(i => i.classList.remove('selected'));
      this.classList.add('selected');
      
      // Update text
      textEl.textContent = text;
      selectedValue = value;
      
      // Close dropdown
      menu.classList.remove('open');
      toggle.classList.remove('open');
    });
  });
  
  // Execute button
  if (executeBtn) {
    executeBtn.addEventListener('click', function() {
      if (!selectedValue) {
        showToast('warning', 'Внимание', 'Пожалуйста, выберите действие');
        return;
      }
      
      const tableBody = document.getElementById('addressesTableBody');
      const selectedCheckboxes = tableBody.querySelectorAll('.table-checkbox:checked');
      
      if (selectedCheckboxes.length === 0) {
        showToast('warning', 'Внимание', 'Пожалуйста, выберите адреса');
        return;
      }
      
      const actionText = textEl.textContent;
      const count = selectedCheckboxes.length;
      
      // Handle delete action with danger confirmation
      if (selectedValue === 'delete') {
        showConfirm('Удалить адреса?', 'Будет удалено ' + count + ' адресов. Это действие нельзя отменить.', function() {
          selectedCheckboxes.forEach(function(cb) {
            const row = cb.closest('.data-table-row');
            if (row) row.remove();
          });
          updatePageStats();
          showToast('success', 'Удалено', 'Удалено адресов: ' + count);
          // Reset selection
          textEl.textContent = 'Не выбрано';
          selectedValue = '';
        }, true);
        return;
      }
      
      // Handle other actions
      showConfirm('Выполнить действие?', 'Действие "' + actionText + '" будет выполнено для ' + count + ' адресов.', function() {
        selectedCheckboxes.forEach(function(cb) {
          const row = cb.closest('.data-table-row');
          if (!row) return;
          
          // Handle status changes
          if (selectedValue === 'available') {
            const statusEl = row.querySelector('.col-status .status-badge');
            if (statusEl) {
              statusEl.className = 'status-badge status-new';
              statusEl.textContent = 'Новый';
            }
          } else if (selectedValue === 'unavailable') {
            const statusEl = row.querySelector('.col-status .status-badge');
            if (statusEl) {
              statusEl.className = 'status-badge status-inactive';
              statusEl.textContent = 'Неактивен';
            }
          }
          
          // Handle type changes
          if (selectedValue.startsWith('type_')) {
            const typeMap = {
              'type_1': 'Подъезд',
              'type_2': 'Прикоп',
              'type_3': 'Магнит',
              'type_4': 'Тайник',
              'type_5': 'Камень',
              'type_6': 'Снежный прикоп',
              'type_7': 'Снежный тайник',
              'type_8': 'Кнопка',
              'type_9': 'Земляной прикоп',
              'type_10': 'Без типа'
            };
            const typeEl = row.querySelector('.col-type');
            if (typeEl && typeMap[selectedValue]) {
              typeEl.textContent = typeMap[selectedValue];
            }
          }
          
          // Handle courier changes
          if (selectedValue.startsWith('courier_')) {
            const courierMap = {
              'courier_178': 'Курьер1',
              'courier_262': 'хз'
            };
            const courierEl = row.querySelector('.col-courier');
            if (courierEl && courierMap[selectedValue]) {
              courierEl.textContent = courierMap[selectedValue];
            }
          }
          
          // Handle location changes
          if (selectedValue.startsWith('location_')) {
            const locationMap = {
              'location_1206': 'Кузнецкий мост (Москва)',
              'location_1385': 'Обновлени! (Обновление!)',
              'location_1384': 'Обновление! (Обновление!)',
              'location_776': 'Ленинский (Саратов)'
            };
            const districtEl = row.querySelector('.col-district');
            if (districtEl && locationMap[selectedValue]) {
              districtEl.textContent = locationMap[selectedValue];
            }
          }
          
          // Handle product changes
          if (selectedValue.startsWith('product_')) {
            const productMap = {
              'product_1268': '01',
              'product_1269': 'Aaaa',
              'product_1485': 'Альфа 1 грам',
              'product_1448': 'Мёд 1гр',
              'product_1667': 'Обновление!',
              'product_1431': 'соль'
            };
            const productEl = row.querySelector('.col-product');
            if (productEl && productMap[selectedValue]) {
              productEl.textContent = productMap[selectedValue];
            }
          }
          
          // Uncheck the checkbox after action
          cb.checked = false;
        });
        
        // Uncheck "select all" checkbox
        const selectAll = document.getElementById('selectAllAddresses');
        if (selectAll) selectAll.checked = false;
        
        updatePageStats();
        showToast('success', 'Выполнено', 'Действие "' + actionText + '" выполнено для ' + count + ' адресов');
        
        // Reset selection
        textEl.textContent = 'Не выбрано';
        selectedValue = '';
      });
    });
  }
}

// ===== FILTER DROPDOWNS =====
function initFilterDropdowns() {
  const filters = [
    { toggle: 'cityFilterToggle', menu: 'cityFilterMenu', text: 'cityFilterText' },
    { toggle: 'productFilterToggle', menu: 'productFilterMenu', text: 'productFilterText' },
    { toggle: 'courierFilterToggle', menu: 'courierFilterMenu', text: 'courierFilterText' },
    { toggle: 'typeFilterToggle', menu: 'typeFilterMenu', text: 'typeFilterText' },
    { toggle: 'statusFilterToggle', menu: 'statusFilterMenu', text: 'statusFilterText' }
  ];
  
  filters.forEach(filter => {
    const toggle = document.getElementById(filter.toggle);
    const menu = document.getElementById(filter.menu);
    const textEl = document.getElementById(filter.text);
    
    if (!toggle || !menu || !textEl) return;
    
    toggle.addEventListener('click', function(e) {
      e.stopPropagation();
      closeAllFilterMenus();
      const isOpen = menu.classList.contains('open');
      
      if (!isOpen) {
        menu.classList.add('open');
        toggle.classList.add('open');
      }
    });
    
    const items = menu.querySelectorAll('.filter-menu-item');
    items.forEach(item => {
      item.addEventListener('click', function(e) {
        e.stopPropagation();
        const text = this.textContent;
        
        items.forEach(i => i.classList.remove('selected'));
        this.classList.add('selected');
        textEl.textContent = text;
        
        menu.classList.remove('open');
        toggle.classList.remove('open');
        
        // Apply filter
        applyTableFilters();
      });
    });
  });
  
  // Date filter
  const dateToggle = document.getElementById('dateFilterToggle');
  const dateMenu = document.getElementById('dateFilterMenu');
  const dateText = document.getElementById('dateFilterText');
  const dateApplyBtn = document.getElementById('dateApplyBtn');
  const dateFromInput = document.getElementById('dateFromInput');
  const dateToInput = document.getElementById('dateToInput');
  
  if (dateToggle && dateMenu) {
    dateToggle.addEventListener('click', function(e) {
      e.stopPropagation();
      closeAllFilterMenus();
      const isOpen = dateMenu.classList.contains('open');
      
      if (!isOpen) {
        dateMenu.classList.add('open');
        dateToggle.classList.add('open');
      }
    });
    
    if (dateApplyBtn && dateFromInput && dateToInput && dateText) {
      dateApplyBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        dateText.textContent = dateFromInput.value + ' - ' + dateToInput.value;
        dateMenu.classList.remove('open');
        dateToggle.classList.remove('open');
      });
    }
  }
  
  // Close on outside click - only if not clicking inside a filter
  document.addEventListener('click', function(e) {
    if (!e.target.closest('.filter-dropdown-wrapper') && !e.target.closest('.action-dropdown-wrapper')) {
      closeAllFilterMenus();
    }
  });
}

function closeAllFilterMenus() {
  document.querySelectorAll('.filter-menu.open').forEach(menu => menu.classList.remove('open'));
  document.querySelectorAll('.filter-dropdown.open').forEach(toggle => toggle.classList.remove('open'));
  document.querySelectorAll('.action-dropdown-menu.open').forEach(menu => menu.classList.remove('open'));
  document.querySelectorAll('.action-dropdown.open').forEach(toggle => toggle.classList.remove('open'));
}

// ===== DYNAMIC PAGE STATS =====
function updatePageStats() {
  const tableBody = document.getElementById('addressesTableBody');
  const statsEl = document.querySelector('[data-testid="text-page-stats"]');
  
  if (!tableBody || !statsEl) return;
  
  const visibleRows = tableBody.querySelectorAll('.data-table-row:not([style*="display: none"])');
  const count = visibleRows.length;
  
  // Calculate total price (mock calculation based on count)
  const totalPrice = count * 4729;
  
  statsEl.textContent = 'На этой странице ' + count + ' шт. на ' + totalPrice.toLocaleString('ru-RU') + ' руб';
}

// ===== ADDRESS MODALS =====
function initAddressModals() {
  // Add Address Modal
  const addBtn = document.querySelector('[data-testid="button-add-address"]');
  const addModalOverlay = document.getElementById('addAddressModalOverlay');
  const closeAddModal = document.getElementById('closeAddAddressModal');
  
  if (addBtn && addModalOverlay) {
    addBtn.addEventListener('click', function() {
      addModalOverlay.classList.add('active');
    });
  }
  
  if (closeAddModal && addModalOverlay) {
    closeAddModal.addEventListener('click', function() {
      addModalOverlay.classList.remove('active');
    });
  }
  
  if (addModalOverlay) {
    addModalOverlay.addEventListener('click', function(e) {
      if (e.target === addModalOverlay) {
        addModalOverlay.classList.remove('active');
      }
    });
  }
  
  // Bulk Add Modal
  const bulkBtn = document.querySelector('[data-testid="button-add-bulk"]');
  const bulkModalOverlay = document.getElementById('bulkAddModalOverlay');
  const closeBulkModal = document.getElementById('closeBulkAddModal');
  
  if (bulkBtn && bulkModalOverlay) {
    bulkBtn.addEventListener('click', function() {
      bulkModalOverlay.classList.add('active');
    });
  }
  
  if (closeBulkModal && bulkModalOverlay) {
    closeBulkModal.addEventListener('click', function() {
      bulkModalOverlay.classList.remove('active');
    });
  }
  
  if (bulkModalOverlay) {
    bulkModalOverlay.addEventListener('click', function(e) {
      if (e.target === bulkModalOverlay) {
        bulkModalOverlay.classList.remove('active');
      }
    });
  }
  
  // Initialize modal dropdowns
  initModalDropdowns();
  
  // File upload handlers
  initFileUploads();
  
  // Drop zone
  initDropZone();
  
  // Button handlers
  initModalButtons();
}

function initModalDropdowns() {
  const dropdowns = document.querySelectorAll('.address-form-dropdown');
  
  dropdowns.forEach(dropdown => {
    const wrapper = dropdown.closest('.address-form-dropdown-wrapper');
    if (!wrapper) return;
    
    const menu = wrapper.querySelector('.address-form-dropdown-menu');
    const textEl = dropdown.querySelector('span');
    if (!menu || !textEl) return;
    
    dropdown.addEventListener('click', function(e) {
      e.stopPropagation();
      
      // Close other modal dropdowns
      document.querySelectorAll('.address-form-dropdown-menu.open').forEach(m => {
        if (m !== menu) m.classList.remove('open');
      });
      document.querySelectorAll('.address-form-dropdown.open').forEach(d => {
        if (d !== dropdown) d.classList.remove('open');
      });
      
      const isOpen = menu.classList.contains('open');
      
      if (isOpen) {
        menu.classList.remove('open');
        dropdown.classList.remove('open');
      } else {
        menu.classList.add('open');
        dropdown.classList.add('open');
      }
    });
    
    const items = menu.querySelectorAll('.address-form-dropdown-item');
    items.forEach(item => {
      item.addEventListener('click', function(e) {
        e.stopPropagation();
        const text = this.textContent;
        
        items.forEach(i => i.classList.remove('selected'));
        this.classList.add('selected');
        textEl.textContent = text;
        
        menu.classList.remove('open');
        dropdown.classList.remove('open');
      });
    });
  });
  
  // Close on outside click within modal
  document.addEventListener('click', function(e) {
    if (!e.target.closest('.address-form-dropdown-wrapper')) {
      document.querySelectorAll('.address-form-dropdown-menu.open').forEach(m => m.classList.remove('open'));
      document.querySelectorAll('.address-form-dropdown.open').forEach(d => d.classList.remove('open'));
    }
  });
}

function initFileUploads() {
  const addPhotoBtn = document.getElementById('addPhotoBtn');
  const addPhotoInput = document.getElementById('addPhotoInput');
  const addPhotoText = document.getElementById('addPhotoText');
  
  if (addPhotoBtn && addPhotoInput && addPhotoText) {
    addPhotoBtn.addEventListener('click', function() {
      addPhotoInput.click();
    });
    
    addPhotoInput.addEventListener('change', function() {
      if (this.files.length > 0) {
        addPhotoText.textContent = this.files[0].name;
      } else {
        addPhotoText.textContent = 'Файл не выбран';
      }
    });
  }
}

function initDropZone() {
  const dropZone = document.getElementById('bulkDropZone');
  const fileInput = document.getElementById('bulkFileInput');
  
  if (!dropZone || !fileInput) return;
  
  dropZone.addEventListener('click', function() {
    fileInput.click();
  });
  
  dropZone.addEventListener('dragover', function(e) {
    e.preventDefault();
    dropZone.classList.add('drag-over');
  });
  
  dropZone.addEventListener('dragleave', function(e) {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
  });
  
  dropZone.addEventListener('drop', function(e) {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      console.log('Dropped files:', files.length);
      showToast('success', 'Файлы загружены', 'Загружено файлов: ' + files.length);
    }
  });
  
  fileInput.addEventListener('change', function() {
    if (this.files.length > 0) {
      console.log('Selected files:', this.files.length);
      showToast('success', 'Файлы выбраны', 'Выбрано файлов: ' + this.files.length);
    }
  });
}

// Generate unique ID for rows
let addressRowCounter = 1000;

function getFormattedDate() {
  const now = new Date();
  const day = String(now.getDate()).padStart(2, '0');
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const year = now.getFullYear();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  return {
    date: day + '.' + month + '.' + year,
    time: hours + ':' + minutes + ':' + seconds
  };
}

function addNewAddressRow(formData) {
  const tableBody = document.getElementById('addressesTableBody');
  if (!tableBody) return;
  
  addressRowCounter++;
  const rowId = addressRowCounter;
  const dateInfo = getFormattedDate();
  
  const searchable = rowId + ' ' + formData.product + ' ' + formData.district + ' ' + formData.courier + ' Новый';
  
  const newRow = document.createElement('div');
  newRow.className = 'data-table-row';
  newRow.setAttribute('data-searchable', searchable);
  
  newRow.innerHTML = 
    '<div class="col-checkbox"><input type="checkbox" class="table-checkbox" data-testid="checkbox-row-' + rowId + '"></div>' +
    '<div class="col-num">' + rowId + '</div>' +
    '<div class="col-product">' + formData.product + '</div>' +
    '<div class="col-district">' + formData.district + '</div>' +
    '<div class="col-courier">' + formData.courier + '</div>' +
    '<div class="col-status"><span class="status-badge status-new">Новый</span></div>' +
    '<div class="col-info">' +
      '<a href="#" class="info-link">Фото</a>' +
      '<button type="button" class="info-link copy-btn" data-copy="' + (formData.description || 'Новый адрес') + '" data-testid="button-copy">' + (formData.description || 'Новый адрес').substring(0, 20) + ' <svg viewBox="0 0 24 24" fill="none" width="10" height="10"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' +
    '</div>' +
    '<div class="col-type">' + formData.type + '</div>' +
    '<div class="col-priority">' + formData.priority + '</div>' +
    '<div class="col-date">' +
      '<div class="date-main">' + dateInfo.date + '</div>' +
      '<div class="date-time">' + dateInfo.time + '</div>' +
    '</div>' +
    '<div class="col-action">' +
      '<button class="action-btn info" data-testid="button-action-' + rowId + '">' +
        '<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" fill="#0088FF"/><circle cx="12" cy="12" r="7.5" fill="#33363F"/><line class="clock-hand-hour" x1="12" y1="12" x2="12" y2="6.5" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/><line class="clock-hand-minute" x1="12" y1="12" x2="15.5" y2="12" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/></svg>' +
      '</button>' +
    '</div>';
  
  tableBody.insertBefore(newRow, tableBody.firstChild);
  
  // Re-init copy buttons for the new row
  initCopyButtons();
  
  // Update page stats
  updatePageStats();
}

function getAddFormData() {
  return {
    courier: document.getElementById('addCourierDropdownText')?.textContent || 'Не выбрано',
    district: document.getElementById('addDistrictDropdownText')?.textContent || 'Не выбрано',
    product: document.getElementById('addProductDropdownText')?.textContent || 'Не выбрано',
    type: document.getElementById('addTypeDropdownText')?.textContent || 'Не выбрано',
    priority: document.getElementById('addPriority')?.value || '0',
    description: document.getElementById('addDescription')?.value || ''
  };
}

function resetAddForm() {
  const courierText = document.getElementById('addCourierDropdownText');
  const courier2Text = document.getElementById('addCourier2DropdownText');
  const districtText = document.getElementById('addDistrictDropdownText');
  const productText = document.getElementById('addProductDropdownText');
  const typeText = document.getElementById('addTypeDropdownText');
  const priorityInput = document.getElementById('addPriority');
  const descriptionInput = document.getElementById('addDescription');
  const photoText = document.getElementById('addPhotoText');
  
  if (courierText) courierText.textContent = 'Не выбрано';
  if (courier2Text) courier2Text.textContent = 'Не выбрано';
  if (districtText) districtText.textContent = 'Не выбрано';
  if (productText) productText.textContent = 'Не выбрано';
  if (typeText) typeText.textContent = 'Не выбрано';
  if (priorityInput) priorityInput.value = '0';
  if (descriptionInput) descriptionInput.value = '';
  if (photoText) photoText.textContent = 'Файл не выбран';
}

function initModalButtons() {
  // Add modal buttons
  const addSaveAndNewBtn = document.getElementById('addSaveAndNewBtn');
  const addApplyBtn = document.getElementById('addApplyBtn');
  const addSaveBtn = document.getElementById('addSaveBtn');
  const addDeleteBtn = document.getElementById('addDeleteBtn');
  const addModalOverlay = document.getElementById('addAddressModalOverlay');
  
  if (addSaveAndNewBtn) {
    addSaveAndNewBtn.addEventListener('click', function() {
      const formData = getAddFormData();
      if (formData.product === 'Не выбрано' || formData.district === 'Не выбрано') {
        showToast('error', 'Ошибка', 'Выберите товар и район.');
        return;
      }
      addNewAddressRow(formData);
      resetAddForm();
      showToast('success', 'Успешно', 'Адрес сохранен! Форма очищена для добавления нового.');
    });
  }
  
  if (addApplyBtn) {
    addApplyBtn.addEventListener('click', function() {
      const formData = getAddFormData();
      if (formData.product === 'Не выбрано' || formData.district === 'Не выбрано') {
        showToast('error', 'Ошибка', 'Выберите товар и район.');
        return;
      }
      addNewAddressRow(formData);
      showToast('success', 'Применено', 'Адрес добавлен в список.');
    });
  }
  
  if (addSaveBtn && addModalOverlay) {
    addSaveBtn.addEventListener('click', function() {
      const formData = getAddFormData();
      if (formData.product === 'Не выбрано' || formData.district === 'Не выбрано') {
        showToast('error', 'Ошибка', 'Выберите товар и район.');
        return;
      }
      addNewAddressRow(formData);
      resetAddForm();
      showToast('success', 'Сохранено', 'Адрес успешно сохранен.');
      addModalOverlay.classList.remove('active');
    });
  }
  
  if (addDeleteBtn && addModalOverlay) {
    addDeleteBtn.addEventListener('click', function() {
      showConfirm('Удалить адрес?', 'Это действие нельзя отменить. Адрес будет удален навсегда.', function() {
        showToast('success', 'Удалено', 'Адрес успешно удален.');
        addModalOverlay.classList.remove('active');
      }, true);
    });
  }
  
  // Bulk modal buttons
  const bulkSaveBtn = document.getElementById('bulkSaveBtn');
  const bulkModalOverlay = document.getElementById('bulkAddModalOverlay');
  
  if (bulkSaveBtn && bulkModalOverlay) {
    bulkSaveBtn.addEventListener('click', function() {
      const bulkCourier = document.getElementById('bulkCourierDropdownText')?.textContent || 'Не выбрано';
      const bulkDistrict = document.getElementById('bulkDistrictDropdownText')?.textContent || 'Не выбрано';
      const bulkProduct = document.getElementById('bulkProductDropdownText')?.textContent || 'Не выбрано';
      const bulkType = document.getElementById('bulkTypeDropdownText')?.textContent || 'Не выбрано';
      const bulkPriority = document.getElementById('bulkPriority')?.value || '0';
      const bulkDescription = document.getElementById('bulkDescription')?.value || '';
      
      if (bulkProduct === 'Не выбрано' || bulkDistrict === 'Не выбрано') {
        showToast('error', 'Ошибка', 'Выберите товар и район.');
        return;
      }
      
      // Add 3 rows for bulk (simulating file upload)
      const descriptions = bulkDescription.split('\n\n').filter(function(d) { return d.trim(); });
      const count = Math.max(descriptions.length, 1);
      
      for (let i = 0; i < count; i++) {
        addNewAddressRow({
          courier: bulkCourier,
          district: bulkDistrict,
          product: bulkProduct,
          type: bulkType,
          priority: bulkPriority,
          description: descriptions[i] || bulkDescription || 'Массовое добавление'
        });
      }
      
      showToast('success', 'Сохранено', 'Добавлено адресов: ' + count);
      bulkModalOverlay.classList.remove('active');
    });
  }
}

// ===== TOAST NOTIFICATIONS =====
function initToastContainer() {
  if (!document.querySelector('.toast-container')) {
    const container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
}

function showToast(type, title, message, duration) {
  initToastContainer();
  duration = duration || 4000;
  
  const container = document.querySelector('.toast-container');
  const toast = document.createElement('div');
  toast.className = 'toast';
  
  let iconSvg = '';
  if (type === 'success') {
    iconSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20,6 9,17 4,12"></polyline></svg>';
  } else if (type === 'error') {
    iconSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>';
  } else if (type === 'warning') {
    iconSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>';
  } else {
    iconSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>';
  }
  
  toast.innerHTML = 
    '<div class="toast-icon ' + type + '">' + iconSvg + '</div>' +
    '<div class="toast-content">' +
      '<div class="toast-title">' + title + '</div>' +
      '<div class="toast-message">' + message + '</div>' +
    '</div>' +
    '<button class="toast-close">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>' +
    '</button>';
  
  container.appendChild(toast);
  
  const closeBtn = toast.querySelector('.toast-close');
  closeBtn.addEventListener('click', function() {
    hideToast(toast);
  });
  
  setTimeout(function() {
    hideToast(toast);
  }, duration);
}

function hideToast(toast) {
  toast.classList.add('toast-hide');
  setTimeout(function() {
    toast.remove();
  }, 300);
}

// ===== CONFIRM MODAL =====
function initConfirmModal() {
  if (!document.querySelector('.confirm-modal-overlay')) {
    const overlay = document.createElement('div');
    overlay.className = 'confirm-modal-overlay';
    overlay.id = 'confirmModalOverlay';
    overlay.innerHTML = 
      '<div class="confirm-modal">' +
        '<div class="confirm-modal-title" id="confirmModalTitle">Подтверждение</div>' +
        '<div class="confirm-modal-message" id="confirmModalMessage">Вы уверены?</div>' +
        '<div class="confirm-modal-actions">' +
          '<button class="confirm-modal-btn cancel" id="confirmModalCancel">Отмена</button>' +
          '<button class="confirm-modal-btn confirm" id="confirmModalConfirm">Подтвердить</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(overlay);
    
    overlay.addEventListener('click', function(e) {
      if (e.target === overlay) {
        overlay.classList.remove('active');
      }
    });
    
    document.getElementById('confirmModalCancel').addEventListener('click', function() {
      overlay.classList.remove('active');
    });
  }
}

function showConfirm(title, message, onConfirm, isDanger) {
  initConfirmModal();
  
  const overlay = document.getElementById('confirmModalOverlay');
  const titleEl = document.getElementById('confirmModalTitle');
  const messageEl = document.getElementById('confirmModalMessage');
  const confirmBtn = document.getElementById('confirmModalConfirm');
  
  titleEl.textContent = title;
  messageEl.textContent = message;
  
  confirmBtn.className = 'confirm-modal-btn ' + (isDanger ? 'danger' : 'confirm');
  confirmBtn.textContent = isDanger ? 'Удалить' : 'Подтвердить';
  
  // Remove old listeners
  const newConfirmBtn = confirmBtn.cloneNode(true);
  confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);
  
  newConfirmBtn.addEventListener('click', function() {
    overlay.classList.remove('active');
    if (onConfirm) onConfirm();
  });
  
  overlay.classList.add('active');
}

// ===== COPY FUNCTIONALITY =====
function initCopyButtons() {
  document.querySelectorAll('.copy-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      
      const textToCopy = btn.getAttribute('data-copy') || btn.closest('td').textContent.trim();
      
      navigator.clipboard.writeText(textToCopy).then(function() {
        showToast('success', 'Скопировано', textToCopy);
      }).catch(function() {
        showToast('error', 'Ошибка', 'Не удалось скопировать текст');
      });
    });
  });
}

// ===== TABLE FILTERING =====
function applyTableFilters() {
  const tableBody = document.getElementById('addressesTableBody');
  if (!tableBody) return;
  
  const cityFilter = document.getElementById('cityFilterText')?.textContent?.trim() || 'Город';
  const productFilter = document.getElementById('productFilterText')?.textContent?.trim() || 'Товар';
  const courierFilter = document.getElementById('courierFilterText')?.textContent?.trim() || 'Курьер';
  const typeFilter = document.getElementById('typeFilterText')?.textContent?.trim() || 'Тип';
  const statusFilter = document.getElementById('statusFilterText')?.textContent?.trim() || 'Статус';
  
  console.log('Applying filters:', { cityFilter, productFilter, courierFilter, typeFilter, statusFilter });
  
  const rows = tableBody.querySelectorAll('.data-table-row');
  
  rows.forEach(function(row) {
    let visible = true;
    
    // City filter - check district column which contains city in parentheses
    if (cityFilter !== 'Город' && cityFilter !== 'Все города') {
      const districtEl = row.querySelector('.col-district');
      if (districtEl) {
        const districtText = districtEl.textContent.trim();
        if (!districtText.includes(cityFilter)) visible = false;
      }
    }
    
    // Product filter
    if (productFilter !== 'Товар' && productFilter !== 'Все товары') {
      const productEl = row.querySelector('.col-product');
      if (productEl) {
        const productText = productEl.textContent.trim();
        if (!productText.includes(productFilter)) visible = false;
      }
    }
    
    // Courier filter
    if (courierFilter !== 'Курьер' && courierFilter !== 'Все курьеры') {
      const courierEl = row.querySelector('.col-courier');
      if (courierEl) {
        const courierText = courierEl.textContent.trim();
        if (!courierText.includes(courierFilter)) visible = false;
      }
    }
    
    // Type filter
    if (typeFilter !== 'Тип' && typeFilter !== 'Все типы') {
      const typeEl = row.querySelector('.col-type');
      if (typeEl) {
        const typeText = typeEl.textContent.trim();
        if (!typeText.includes(typeFilter)) visible = false;
      }
    }
    
    // Status filter
    if (statusFilter !== 'Статус' && statusFilter !== 'Все статусы') {
      const statusEl = row.querySelector('.col-status');
      if (statusEl) {
        const statusText = statusEl.textContent.trim();
        if (!statusText.includes(statusFilter)) visible = false;
      }
    }
    
    row.style.display = visible ? '' : 'none';
  });
  
  updatePageStats();
}

// ===== BOT MODAL =====
let botRowCounter = 5000;

function initBotModal() {
  const addBtn = document.getElementById('addBotBtn');
  const modalOverlay = document.getElementById('addBotModalOverlay');
  const closeBtn = document.getElementById('closeBotModal');
  const botsBody = document.getElementById('botsTableBody');
  
  if (!addBtn || !modalOverlay) return;
  
  // Open modal
  addBtn.addEventListener('click', function() {
    modalOverlay.classList.add('active');
  });
  
  // Close modal
  if (closeBtn) {
    closeBtn.addEventListener('click', function() {
      modalOverlay.classList.remove('active');
    });
  }
  
  // Close on overlay click
  modalOverlay.addEventListener('click', function(e) {
    if (e.target === modalOverlay) {
      modalOverlay.classList.remove('active');
    }
  });
  
  // Initialize dropdowns
  initBotDropdown('botTypeDropdownToggle', 'botTypeDropdownMenu', 'botTypeDropdownText');
  initBotDropdown('botStatusDropdownToggle', 'botStatusDropdownMenu', 'botStatusDropdownText');
  
  // Button handlers
  const saveAndNewBtn = document.getElementById('botSaveAndNewBtn');
  const applyBtn = document.getElementById('botApplyBtn');
  const saveBtn = document.getElementById('botSaveBtn');
  const deleteBtn = document.getElementById('botDeleteBtn');
  
  if (saveAndNewBtn) {
    saveAndNewBtn.addEventListener('click', function() {
      const formData = getBotFormData();
      if (formData.type === 'Не выбрано') {
        showToast('error', 'Ошибка', 'Выберите тип бота.');
        return;
      }
      addNewBotRow(formData);
      resetBotForm();
      showToast('success', 'Успешно', 'Бот добавлен! Форма очищена.');
    });
  }
  
  if (applyBtn) {
    applyBtn.addEventListener('click', function() {
      const formData = getBotFormData();
      if (formData.type === 'Не выбрано') {
        showToast('error', 'Ошибка', 'Выберите тип бота.');
        return;
      }
      addNewBotRow(formData);
      showToast('success', 'Применено', 'Бот добавлен в список.');
    });
  }
  
  if (saveBtn) {
    saveBtn.addEventListener('click', function() {
      const formData = getBotFormData();
      if (formData.type === 'Не выбрано') {
        showToast('error', 'Ошибка', 'Выберите тип бота.');
        return;
      }
      addNewBotRow(formData);
      resetBotForm();
      modalOverlay.classList.remove('active');
      showToast('success', 'Сохранено', 'Бот успешно добавлен.');
    });
  }
  
  if (deleteBtn) {
    deleteBtn.addEventListener('click', function() {
      showConfirm('Удалить?', 'Это действие нельзя отменить.', function() {
        resetBotForm();
        modalOverlay.classList.remove('active');
        showToast('success', 'Удалено', 'Данные удалены.');
      }, true);
    });
  }
  
  // Delete selected bots
  const deleteSelectedBtn = document.getElementById('deleteSelectedBots');
  if (deleteSelectedBtn && botsBody) {
    deleteSelectedBtn.addEventListener('click', function(e) {
      e.preventDefault();
      const checkedBoxes = botsBody.querySelectorAll('.checkbox-container input:checked');
      if (checkedBoxes.length === 0) {
        showToast('warning', 'Внимание', 'Выберите ботов для удаления.');
        return;
      }
      showConfirm('Удалить выбранных ботов?', 'Будет удалено ' + checkedBoxes.length + ' ботов.', function() {
        checkedBoxes.forEach(function(cb) {
          const row = cb.closest('.bot-row');
          if (row) row.remove();
        });
        updateBotStats();
        showToast('success', 'Удалено', 'Удалено ботов: ' + checkedBoxes.length);
      }, true);
    });
  }
}

function initBotDropdown(toggleId, menuId, textId) {
  const toggle = document.getElementById(toggleId);
  const menu = document.getElementById(menuId);
  const textEl = document.getElementById(textId);
  
  if (!toggle || !menu || !textEl) return;
  
  toggle.addEventListener('click', function(e) {
    e.stopPropagation();
    const isOpen = menu.classList.contains('open');
    
    // Close all other bot dropdowns
    document.querySelectorAll('.bot-form-dropdown-menu.open').forEach(function(m) {
      m.classList.remove('open');
    });
    
    if (!isOpen) {
      menu.classList.add('open');
    }
  });
  
  menu.querySelectorAll('.bot-form-dropdown-item').forEach(function(item) {
    item.addEventListener('click', function(e) {
      e.stopPropagation();
      const value = this.getAttribute('data-value');
      const text = this.textContent;
      
      menu.querySelectorAll('.bot-form-dropdown-item').forEach(function(i) {
        i.classList.remove('selected');
      });
      this.classList.add('selected');
      
      textEl.textContent = text;
      menu.classList.remove('open');
    });
  });
  
  document.addEventListener('click', function() {
    menu.classList.remove('open');
  });
}

function getBotFormData() {
  return {
    type: document.getElementById('botTypeDropdownText')?.textContent || 'Не выбрано',
    typeValue: getSelectedValue('botTypeDropdownMenu'),
    status: document.getElementById('botStatusDropdownText')?.textContent || 'Активный',
    statusValue: getSelectedValue('botStatusDropdownMenu'),
    description: document.getElementById('botDescription')?.value || '',
    captcha: document.getElementById('botCaptchaCheckbox')?.checked || false
  };
}

function getSelectedValue(menuId) {
  const menu = document.getElementById(menuId);
  if (!menu) return '';
  const selected = menu.querySelector('.bot-form-dropdown-item.selected');
  return selected ? selected.getAttribute('data-value') : '';
}

function resetBotForm() {
  const typeText = document.getElementById('botTypeDropdownText');
  const statusText = document.getElementById('botStatusDropdownText');
  const description = document.getElementById('botDescription');
  const captcha = document.getElementById('botCaptchaCheckbox');
  
  if (typeText) typeText.textContent = 'Не выбрано';
  if (statusText) statusText.textContent = 'Активный';
  if (description) description.value = '';
  if (captcha) captcha.checked = false;
  
  // Reset selected states
  document.querySelectorAll('#botTypeDropdownMenu .bot-form-dropdown-item').forEach(function(item) {
    item.classList.remove('selected');
  });
  document.querySelectorAll('#botStatusDropdownMenu .bot-form-dropdown-item').forEach(function(item, index) {
    item.classList.toggle('selected', index === 0);
  });
}

function addNewBotRow(formData) {
  const botsBody = document.getElementById('botsTableBody');
  if (!botsBody) return;
  
  botRowCounter++;
  const rowId = botRowCounter;
  const dateInfo = getFormattedDate();
  
  // Generate a fake bot username from description or random
  const tokens = formData.description.split('\n').filter(function(t) { return t.trim(); });
  const botUsername = tokens.length > 0 ? '@bot' + tokens[0].substring(0, 10).replace(/[^a-zA-Z0-9]/g, '') + 'bot' : '@newbot' + rowId;
  
  const newRow = document.createElement('div');
  newRow.className = 'bot-row';
  
  newRow.innerHTML = 
    '<div class="bot-check">' +
      '<label class="checkbox-container">' +
        '<input type="checkbox">' +
        '<span class="checkmark"></span>' +
      '</label>' +
    '</div>' +
    '<div class="bot-id">' + rowId + '</div>' +
    '<div class="bot-name">' +
      '<div class="bot-username">' + botUsername + '</div>' +
      '<div class="bot-error">Последняя ошибка:</div>' +
    '</div>' +
    '<div class="bot-type">' + formData.type + '</div>' +
    '<div class="bot-status ' + (formData.status === 'Активный' ? 'active' : '') + '">' + formData.status + '</div>' +
    '<div class="bot-clients">0</div>' +
    '<div class="bot-date">' + dateInfo.date + ' ' + dateInfo.time + '</div>' +
    '<div class="bot-action">' +
      '<button class="action-btn info">' +
        '<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" fill="#0088FF"/><circle cx="12" cy="12" r="7.5" fill="#33363F"/><line class="clock-hand-hour" x1="12" y1="12" x2="12" y2="6.5" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/><line class="clock-hand-minute" x1="12" y1="12" x2="15.5" y2="12" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/></svg>' +
      '</button>' +
    '</div>';
  
  botsBody.insertBefore(newRow, botsBody.firstChild);
  updateBotStats();
}

function updateBotStats() {
  const botsBody = document.getElementById('botsTableBody');
  if (!botsBody) return;
  
  const rows = botsBody.querySelectorAll('.bot-row');
  let sellerCount = 0;
  let distributorCount = 0;
  
  rows.forEach(function(row) {
    const typeEl = row.querySelector('.bot-type');
    if (typeEl) {
      const typeText = typeEl.textContent.trim();
      if (typeText.includes('продавец')) sellerCount++;
      if (typeText.includes('распределитель')) distributorCount++;
    }
  });
  
  const sellerEl = document.getElementById('botSellerCount');
  const distributorEl = document.getElementById('botDistributorCount');
  
  if (sellerEl) sellerEl.textContent = 'Бот продавец: ' + sellerCount + ' шт';
  if (distributorEl) distributorEl.textContent = 'Бот распределитель: ' + distributorCount + ' шт';
}

// ===== BOTS FILTER DROPDOWNS =====
function initBotsFilterDropdowns() {
  initBotsFilter('botsTypeFilter', 'botsTypeFilterMenu', 'botsTypeFilterText');
  initBotsFilter('botsStatusFilter', 'botsStatusFilterMenu', 'botsStatusFilterText');
}

function initBotsFilter(toggleId, menuId, textId) {
  const toggle = document.getElementById(toggleId);
  const menu = document.getElementById(menuId);
  const textEl = document.getElementById(textId);
  
  if (!toggle || !menu || !textEl) return;
  
  toggle.addEventListener('click', function(e) {
    e.stopPropagation();
    const isOpen = menu.classList.contains('open');
    
    // Close all other filter dropdowns
    document.querySelectorAll('.filter-dropdown-menu.open').forEach(function(m) {
      m.classList.remove('open');
    });
    
    if (!isOpen) {
      menu.classList.add('open');
    }
  });
  
  menu.querySelectorAll('.filter-dropdown-item').forEach(function(item) {
    item.addEventListener('click', function(e) {
      e.stopPropagation();
      const value = this.getAttribute('data-value');
      const text = this.textContent;
      
      menu.querySelectorAll('.filter-dropdown-item').forEach(function(i) {
        i.classList.remove('selected');
      });
      this.classList.add('selected');
      
      textEl.textContent = text;
      menu.classList.remove('open');
      
      // Apply filter
      filterBotsTable();
    });
  });
  
  document.addEventListener('click', function() {
    menu.classList.remove('open');
  });
}

function filterBotsTable() {
  const botsBody = document.getElementById('botsTableBody');
  if (!botsBody) return;
  
  const typeText = document.getElementById('botsTypeFilterText')?.textContent || 'Тип';
  const statusText = document.getElementById('botsStatusFilterText')?.textContent || 'Статус';
  
  const rows = botsBody.querySelectorAll('.bot-row');
  
  rows.forEach(function(row) {
    let visible = true;
    
    // Type filter
    if (typeText !== 'Тип') {
      const typeEl = row.querySelector('.bot-type');
      if (typeEl) {
        const rowType = typeEl.textContent.trim();
        if (!rowType.includes(typeText)) visible = false;
      }
    }
    
    // Status filter
    if (statusText !== 'Статус') {
      const statusEl = row.querySelector('.bot-status');
      if (statusEl) {
        const rowStatus = statusEl.textContent.trim();
        if (!rowStatus.includes(statusText)) visible = false;
      }
    }
    
    row.style.display = visible ? '' : 'none';
  });
}

// ===== EDIT BOT MODAL =====
function initEditBotModal() {
  const modalOverlay = document.getElementById('editBotModalOverlay');
  const closeBtn = document.getElementById('closeEditBotModal');
  const botsBody = document.getElementById('botsTableBody');
  
  if (!modalOverlay) return;
  
  // Close modal
  if (closeBtn) {
    closeBtn.addEventListener('click', function() {
      closeEditBotModal();
    });
  }
  
  // Close on overlay click
  modalOverlay.addEventListener('click', function(e) {
    if (e.target === modalOverlay) {
      closeEditBotModal();
    }
  });
  
  // Attach click handlers to existing bot action buttons
  if (botsBody) {
    botsBody.addEventListener('click', function(e) {
      const actionBtn = e.target.closest('.action-btn.info');
      if (actionBtn) {
        e.preventDefault();
        const row = actionBtn.closest('.bot-row');
        if (row) {
          openEditBotModal(row);
        }
      }
    });
  }
  
  // Button handlers
  const applyBtn = document.getElementById('editBotApplyBtn');
  const saveBtn = document.getElementById('editBotSaveBtn');
  
  if (applyBtn) {
    applyBtn.addEventListener('click', function() {
      const text = document.getElementById('editBotText')?.value || '';
      showToast('success', 'Применено', 'Изменения применены.');
    });
  }
  
  if (saveBtn) {
    saveBtn.addEventListener('click', function() {
      const text = document.getElementById('editBotText')?.value || '';
      closeEditBotModal();
      showToast('success', 'Сохранено', 'Сообщение бота сохранено.');
    });
  }
}

// Bot message templates for dynamic content
const botMessageTemplates = [
  {
    slug: 'ORDER-NO-MONEY',
    text: 'Покупка #{{ORDER_ID}}. У вас недостаточно баланса для оплаты покупки! Выберите способ пополнения на недостающую сумму {{NEED_MONEY}} {{CURRENCY}}:',
    variables: [
      { label: 'Номер покупки', value: '{{ORDER_ID}}' },
      { label: 'Недостающая сумма', value: '{{NEED_MONEY}}' },
      { label: 'Валюта магазина', value: '{{CURRENCY}}' }
    ]
  },
  {
    slug: 'ORDER-SUCCESS',
    text: 'Покупка #{{ORDER_ID}} успешно оплачена! Сумма: {{AMOUNT}} {{CURRENCY}}. Спасибо за покупку!',
    variables: [
      { label: 'Номер покупки', value: '{{ORDER_ID}}' },
      { label: 'Сумма', value: '{{AMOUNT}}' },
      { label: 'Валюта', value: '{{CURRENCY}}' }
    ]
  },
  {
    slug: 'ORDER-PENDING',
    text: 'Покупка #{{ORDER_ID}} ожидает подтверждения оплаты. Сумма к оплате: {{AMOUNT}} {{CURRENCY}}.',
    variables: [
      { label: 'Номер покупки', value: '{{ORDER_ID}}' },
      { label: 'Сумма', value: '{{AMOUNT}}' },
      { label: 'Валюта', value: '{{CURRENCY}}' }
    ]
  },
  {
    slug: 'WELCOME-MESSAGE',
    text: 'Добро пожаловать, {{USERNAME}}! Вы успешно зарегистрировались в нашем магазине. Ваш ID: {{USER_ID}}.',
    variables: [
      { label: 'Имя пользователя', value: '{{USERNAME}}' },
      { label: 'ID пользователя', value: '{{USER_ID}}' }
    ]
  }
];

function openEditBotModal(row) {
  const modalOverlay = document.getElementById('editBotModalOverlay');
  if (!modalOverlay) return;
  
  // Get bot data from row
  const botId = row.querySelector('.bot-id')?.textContent || '';
  const botName = row.querySelector('.bot-username')?.textContent || '';
  const botDate = row.querySelector('.bot-date')?.textContent || '';
  const botType = row.querySelector('.bot-type')?.textContent || '';
  
  // Select random template based on bot ID
  const templateIndex = parseInt(botId) % botMessageTemplates.length;
  const template = botMessageTemplates[templateIndex];
  
  // Generate dynamic dates based on bot
  const createdDate = generateRandomDate();
  
  // Update modal with dynamic bot data
  const slugEl = document.getElementById('editBotSlug');
  const textEl = document.getElementById('editBotText');
  const createdEl = document.getElementById('editBotCreatedAt');
  const updatedEl = document.getElementById('editBotUpdatedAt');
  const variablesContainer = document.querySelector('.edit-bot-variables');
  
  if (slugEl) slugEl.textContent = template.slug;
  if (textEl) textEl.value = template.text;
  if (createdEl) createdEl.textContent = createdDate;
  if (updatedEl) updatedEl.textContent = botDate || formatCurrentDate();
  
  // Update variables dynamically
  if (variablesContainer) {
    variablesContainer.innerHTML = '';
    template.variables.forEach(function(variable) {
      const varDiv = document.createElement('div');
      varDiv.className = 'edit-bot-variable';
      varDiv.innerHTML = 
        '<span class="edit-bot-variable-label">' + variable.label + '</span>' +
        '<span class="edit-bot-variable-value">' + variable.value + '</span>';
      variablesContainer.appendChild(varDiv);
    });
  }
  
  // Show modal with animation
  modalOverlay.classList.add('active');
  
  // Focus textarea
  setTimeout(function() {
    const textarea = document.getElementById('editBotText');
    if (textarea) textarea.focus();
  }, 100);
}

function generateRandomDate() {
  const day = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
  const month = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
  const year = '2025';
  const hour = String(Math.floor(Math.random() * 24)).padStart(2, '0');
  const minute = String(Math.floor(Math.random() * 60)).padStart(2, '0');
  const second = String(Math.floor(Math.random() * 60)).padStart(2, '0');
  return day + '.' + month + '.' + year + ' ' + hour + ':' + minute + ':' + second;
}

function formatCurrentDate() {
  const now = new Date();
  const day = String(now.getDate()).padStart(2, '0');
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const year = now.getFullYear();
  const hour = String(now.getHours()).padStart(2, '0');
  const minute = String(now.getMinutes()).padStart(2, '0');
  const second = String(now.getSeconds()).padStart(2, '0');
  return day + '.' + month + '.' + year + ' ' + hour + ':' + minute + ':' + second;
}

function closeEditBotModal() {
  const modalOverlay = document.getElementById('editBotModalOverlay');
  if (!modalOverlay) return;
  
  const modal = modalOverlay.querySelector('.edit-bot-modal');
  if (modal) {
    modal.style.animation = 'modalSlideOut 0.2s ease forwards';
    setTimeout(function() {
      modalOverlay.classList.remove('active');
      modal.style.animation = '';
    }, 200);
  } else {
    modalOverlay.classList.remove('active');
  }
}

// ==================== EMPLOYEES PAGE ====================
var employeeIdCounter = 2087;

function initEmployeesPage() {
  const searchInput = document.querySelector('.employees-table')?.closest('.main-content')?.querySelector('.search-input');
  const accessLevelFilter = document.getElementById('empAccessLevelFilter');
  const accessLevelMenu = document.getElementById('empAccessLevelMenu');
  const accessLevelText = document.getElementById('empAccessLevelText');
  const addEmployeeBtn = document.getElementById('addEmployeeBtn');
  const employeeModalOverlay = document.getElementById('addEmployeeModalOverlay');
  const closeEmployeeModal = document.getElementById('closeAddEmployeeModal');
  
  // Search functionality
  if (searchInput) {
    searchInput.addEventListener('input', function() {
      const searchTerm = this.value.toLowerCase().trim();
      filterEmployeesTable();
    });
  }
  
  // Access level filter dropdown
  if (accessLevelFilter && accessLevelMenu) {
    accessLevelFilter.addEventListener('click', function(e) {
      e.stopPropagation();
      accessLevelFilter.classList.toggle('open');
    });
    
    accessLevelMenu.querySelectorAll('.filter-dropdown-item').forEach(function(item) {
      item.addEventListener('click', function(e) {
        e.stopPropagation();
        const value = this.getAttribute('data-value');
        if (accessLevelText) {
          accessLevelText.textContent = value || 'Уровень доступа';
        }
        accessLevelFilter.classList.remove('open');
        filterEmployeesTable();
      });
    });
    
    document.addEventListener('click', function() {
      accessLevelFilter.classList.remove('open');
    });
  }
  
  // Add employee button
  if (addEmployeeBtn && employeeModalOverlay) {
    addEmployeeBtn.addEventListener('click', function() {
      openAddEmployeeModal();
    });
  }
  
  // Close modal
  if (closeEmployeeModal) {
    closeEmployeeModal.addEventListener('click', closeAddEmployeeModal);
  }
  
  if (employeeModalOverlay) {
    employeeModalOverlay.addEventListener('click', function(e) {
      if (e.target === employeeModalOverlay) {
        closeAddEmployeeModal();
      }
    });
  }
  
  // Form selects
  initFormSelects();
  
  // Generate password button
  const generatePasswordBtn = document.getElementById('generatePasswordBtn');
  if (generatePasswordBtn) {
    generatePasswordBtn.addEventListener('click', function() {
      const passwordInput = document.getElementById('empPasswordInput');
      if (passwordInput) {
        passwordInput.value = generatePassword(16);
      }
    });
  }
  
  // Save employee button
  const saveEmployeeBtn = document.getElementById('saveEmployeeBtn');
  if (saveEmployeeBtn) {
    saveEmployeeBtn.addEventListener('click', function() {
      saveEmployee();
    });
  }
  
  // Apply employee button (same as save but keeps modal open)
  const applyEmployeeBtn = document.getElementById('applyEmployeeBtn');
  if (applyEmployeeBtn) {
    applyEmployeeBtn.addEventListener('click', function() {
      saveEmployee(true);
    });
  }
  
  // Delete employee button
  const deleteEmployeeBtn = document.getElementById('deleteEmployeeBtn');
  if (deleteEmployeeBtn) {
    deleteEmployeeBtn.addEventListener('click', function() {
      const modalOverlay = document.getElementById('addEmployeeModalOverlay');
      const editId = modalOverlay ? modalOverlay.dataset.editId : '';
      if (editId) {
        const row = document.querySelector('.emp-row[data-id="' + editId + '"]');
        if (row) row.remove();
      }
      closeAddEmployeeModal();
      showToast('success', 'Удалено', 'Пользователь удален');
    });
  }
  
  // Attach click handlers to existing rows for editing
  initEmployeeRowEvents();
}

function initEmployeeRowEvents() {
  document.querySelectorAll('.emp-row').forEach(function(row, index) {
    if (!row.dataset.id) {
      row.dataset.id = 2084 + index;
    }
    attachEmployeeRowEvents(row);
  });
}

function attachEmployeeRowEvents(row) {
  // Remove existing listener to avoid duplicates
  row.style.cursor = 'pointer';
  row.addEventListener('click', function(e) {
    // Don't trigger if clicking on action icons
    if (e.target.closest('.emp-action')) return;
    
    const id = row.dataset.id;
    const login = row.querySelector('.emp-login')?.textContent || '';
    const level = row.querySelector('.emp-level')?.textContent || '';
    
    openAddEmployeeModal({ id: id, login: login, level: level });
  });
}

function filterEmployeesTable() {
  const searchInput = document.querySelector('.employees-table')?.closest('.main-content')?.querySelector('.search-input');
  const accessLevelText = document.getElementById('empAccessLevelText');
  const rows = document.querySelectorAll('.emp-row');
  
  const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';
  const levelFilter = accessLevelText ? accessLevelText.textContent : 'Уровень доступа';
  
  rows.forEach(function(row) {
    const id = row.querySelector('.emp-id')?.textContent.toLowerCase() || '';
    const login = row.querySelector('.emp-login')?.textContent.toLowerCase() || '';
    const level = row.querySelector('.emp-level')?.textContent || '';
    
    const matchesSearch = !searchTerm || id.includes(searchTerm) || login.includes(searchTerm);
    const matchesLevel = levelFilter === 'Уровень доступа' || level === levelFilter;
    
    row.style.display = matchesSearch && matchesLevel ? '' : 'none';
  });
}

function openAddEmployeeModal(editData) {
  const modalOverlay = document.getElementById('addEmployeeModalOverlay');
  if (!modalOverlay) return;
  
  // Reset form
  const loginInput = document.getElementById('empLoginInput');
  const passwordInput = document.getElementById('empPasswordInput');
  const groupText = document.getElementById('empGroupText');
  const citiesText = document.getElementById('empCitiesText');
  const modalTitle = modalOverlay.querySelector('.modal-title');
  
  if (editData) {
    // Edit mode
    if (loginInput) loginInput.value = editData.login || '';
    if (passwordInput) passwordInput.value = '';
    if (groupText) groupText.textContent = editData.level || 'Владелец';
    if (citiesText) citiesText.textContent = 'Все города';
    if (modalTitle) modalTitle.textContent = 'Редактировать';
    modalOverlay.dataset.editId = editData.id;
  } else {
    // Add mode
    if (loginInput) loginInput.value = '';
    if (passwordInput) passwordInput.value = '';
    if (groupText) groupText.textContent = 'Владелец';
    if (citiesText) citiesText.textContent = 'Все города';
    if (modalTitle) modalTitle.textContent = 'Добавить';
    modalOverlay.dataset.editId = '';
  }
  
  modalOverlay.classList.add('active');
}

function closeAddEmployeeModal() {
  const modalOverlay = document.getElementById('addEmployeeModalOverlay');
  if (!modalOverlay) return;
  modalOverlay.classList.remove('active');
}

function generatePassword(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
  let password = '';
  for (let i = 0; i < length; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password;
}

function saveEmployee(keepOpen) {
  const loginInput = document.getElementById('empLoginInput');
  const groupText = document.getElementById('empGroupText');
  const modalOverlay = document.getElementById('addEmployeeModalOverlay');
  
  const login = loginInput ? loginInput.value.trim() : '';
  const level = groupText ? groupText.textContent : 'Владелец';
  const editId = modalOverlay ? modalOverlay.dataset.editId : '';
  
  if (!login) {
    showToast('error', 'Ошибка', 'Введите логин пользователя');
    return;
  }
  
  if (editId) {
    // Update existing row
    const row = document.querySelector('.emp-row[data-id="' + editId + '"]');
    if (row) {
      const loginEl = row.querySelector('.emp-login');
      const levelEl = row.querySelector('.emp-level');
      if (loginEl) loginEl.textContent = login;
      if (levelEl) levelEl.textContent = level;
    }
    showToast('success', 'Сохранено', 'Данные сотрудника обновлены');
  } else {
    // Add row to table
    const tableBody = document.querySelector('.employees-body');
    if (tableBody) {
      const newRow = document.createElement('div');
      newRow.className = 'emp-row';
      newRow.dataset.id = employeeIdCounter;
      newRow.setAttribute('data-testid', 'row-employee-' + employeeIdCounter);
      newRow.innerHTML = 
        '<span class="emp-id" data-testid="text-emp-id-' + employeeIdCounter + '">' + employeeIdCounter + '</span>' +
        '<span class="emp-login" data-testid="text-emp-login-' + employeeIdCounter + '">' + login + '</span>' +
        '<span class="emp-level" data-testid="text-emp-level-' + employeeIdCounter + '">' + level + '</span>' +
        '<span class="emp-2fa status-red" data-testid="text-emp-2fa-' + employeeIdCounter + '">Отключен</span>' +
        '<div class="emp-action">' +
          '<svg class="clock-animated" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" fill="#0088FF"/><circle cx="12" cy="12" r="7.5" fill="#33363F"/><line class="clock-hand-hour" x1="12" y1="12" x2="12" y2="6.5" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/><line class="clock-hand-minute" x1="12" y1="12" x2="15.5" y2="12" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/></svg>' +
        '</div>';
      tableBody.appendChild(newRow);
      attachEmployeeRowEvents(newRow);
      employeeIdCounter++;
    }
    showToast('success', 'Сохранено', 'Сотрудник ' + login + ' добавлен');
  }
  
  if (!keepOpen) {
    closeAddEmployeeModal();
  } else {
    if (loginInput) loginInput.value = '';
    modalOverlay.dataset.editId = '';
    const modalTitle = modalOverlay.querySelector('.modal-title');
    if (modalTitle) modalTitle.textContent = 'Добавить';
  }
}

function initFormSelects() {
  document.querySelectorAll('.form-select').forEach(function(select) {
    const menu = select.querySelector('.form-select-menu');
    const textEl = select.querySelector('span');
    
    select.addEventListener('click', function(e) {
      e.stopPropagation();
      // Close other selects
      document.querySelectorAll('.form-select.open').forEach(function(s) {
        if (s !== select) s.classList.remove('open');
      });
      select.classList.toggle('open');
    });
    
    if (menu) {
      menu.querySelectorAll('.form-select-item').forEach(function(item) {
        item.addEventListener('click', function(e) {
          e.stopPropagation();
          if (textEl) {
            textEl.textContent = this.getAttribute('data-value');
          }
          select.classList.remove('open');
        });
      });
    }
  });
  
  document.addEventListener('click', function() {
    document.querySelectorAll('.form-select.open').forEach(function(s) {
      s.classList.remove('open');
    });
  });
}

// ==================== ACCESS LEVELS PAGE ====================
var accessLevelIdCounter = 6;

function initAccessLevelsPage() {
  const searchInput = document.querySelector('.access-levels-table')?.closest('.main-content')?.querySelector('.search-input');
  const addAccessLevelBtn = document.getElementById('addAccessLevelBtn');
  const accessLevelModalOverlay = document.getElementById('addAccessLevelModalOverlay');
  const closeAccessLevelModal = document.getElementById('closeAddAccessLevelModal');
  
  // Search functionality
  if (searchInput) {
    searchInput.addEventListener('input', function() {
      const searchTerm = this.value.toLowerCase().trim();
      filterAccessLevelsTable(searchTerm);
    });
  }
  
  // Add access level button
  if (addAccessLevelBtn && accessLevelModalOverlay) {
    addAccessLevelBtn.addEventListener('click', function() {
      openAddAccessLevelModal();
    });
  }
  
  // Close modal
  if (closeAccessLevelModal) {
    closeAccessLevelModal.addEventListener('click', closeAddAccessLevelModalFn);
  }
  
  if (accessLevelModalOverlay) {
    accessLevelModalOverlay.addEventListener('click', function(e) {
      if (e.target === accessLevelModalOverlay) {
        closeAddAccessLevelModalFn();
      }
    });
  }
  
  // Save buttons
  const saveAccessLevelBtn = document.getElementById('saveAccessLevelBtn');
  if (saveAccessLevelBtn) {
    saveAccessLevelBtn.addEventListener('click', function() {
      saveAccessLevel();
    });
  }
  
  const applyAccessLevelBtn = document.getElementById('applyAccessLevelBtn');
  if (applyAccessLevelBtn) {
    applyAccessLevelBtn.addEventListener('click', function() {
      saveAccessLevel(true);
    });
  }
  
  const saveAndAddAnotherBtn = document.getElementById('saveAndAddAnotherBtn');
  if (saveAndAddAnotherBtn) {
    saveAndAddAnotherBtn.addEventListener('click', function() {
      saveAccessLevel(true, true);
    });
  }
  
  const deleteAccessLevelBtn = document.getElementById('deleteAccessLevelBtn');
  if (deleteAccessLevelBtn) {
    deleteAccessLevelBtn.addEventListener('click', function() {
      closeAddAccessLevelModalFn();
      showToast('success', 'Удалено', 'Уровень доступа удален');
    });
  }
  
  // Init edit/delete icons
  initAccessLevelActions();
}

function filterAccessLevelsTable(searchTerm) {
  const rows = document.querySelectorAll('.level-row');
  
  rows.forEach(function(row) {
    const name = row.querySelector('.level-name')?.textContent.toLowerCase() || '';
    const permissions = row.querySelector('.level-permissions')?.textContent.toLowerCase() || '';
    
    const matches = !searchTerm || name.includes(searchTerm) || permissions.includes(searchTerm);
    row.style.display = matches ? '' : 'none';
  });
}

function openAddAccessLevelModal(editData) {
  const modalOverlay = document.getElementById('addAccessLevelModalOverlay');
  if (!modalOverlay) return;
  
  const nameInput = document.getElementById('accessLevelNameInput');
  const modalTitle = modalOverlay.querySelector('.modal-title');
  
  // Reset form
  if (nameInput) nameInput.value = editData ? editData.name : '';
  modalOverlay.querySelectorAll('.permission-checkbox').forEach(function(cb) {
    cb.checked = false;
  });
  
  if (modalTitle) {
    modalTitle.textContent = editData ? 'Редактировать' : 'Добавить';
  }
  
  // Store edit data
  modalOverlay.dataset.editId = editData ? editData.id : '';
  
  modalOverlay.classList.add('active');
}

function closeAddAccessLevelModalFn() {
  const modalOverlay = document.getElementById('addAccessLevelModalOverlay');
  if (!modalOverlay) return;
  modalOverlay.classList.remove('active');
}

function saveAccessLevel(keepOpen, resetForm) {
  const nameInput = document.getElementById('accessLevelNameInput');
  const modalOverlay = document.getElementById('addAccessLevelModalOverlay');
  const name = nameInput ? nameInput.value.trim() : '';
  
  if (!name) {
    showToast('error', 'Ошибка', 'Введите название уровня доступа');
    return;
  }
  
  // Collect checked permissions
  const checkedPerms = [];
  modalOverlay.querySelectorAll('.permission-checkbox:checked').forEach(function(cb) {
    const label = cb.nextElementSibling;
    if (label) checkedPerms.push(label.textContent);
  });
  
  const permissionsText = checkedPerms.length > 0 ? checkedPerms.slice(0, 3).join(', ') : 'Нет прав';
  const editId = modalOverlay ? modalOverlay.dataset.editId : '';
  
  if (editId) {
    // Edit existing row
    const row = document.querySelector('.level-row[data-id="' + editId + '"]');
    if (row) {
      row.querySelector('.level-name').textContent = name;
      row.querySelector('.level-permissions').textContent = permissionsText;
    }
    showToast('success', 'Сохранено', 'Уровень доступа обновлен');
  } else {
    // Add new row
    const tableBody = document.querySelector('.access-levels-body');
    if (tableBody) {
      const newRow = document.createElement('div');
      newRow.className = 'level-row';
      newRow.dataset.id = accessLevelIdCounter;
      newRow.setAttribute('data-testid', 'row-level-' + accessLevelIdCounter);
      newRow.innerHTML = 
        '<span class="level-id" data-testid="text-level-id-' + accessLevelIdCounter + '">' + accessLevelIdCounter + '</span>' +
        '<span class="level-name" data-testid="text-level-name-' + accessLevelIdCounter + '">' + name + '</span>' +
        '<span class="level-permissions" data-testid="text-level-perms-' + accessLevelIdCounter + '">' + permissionsText + '</span>' +
        '<div class="level-actions">' +
          '<svg class="action-icon edit" data-testid="button-edit-level-' + accessLevelIdCounter + '" viewBox="0 0 24 24" fill="#0088ff"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>' +
          '<svg class="action-icon delete" data-testid="button-delete-level-' + accessLevelIdCounter + '" viewBox="0 0 24 24" fill="#ff383c"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>' +
        '</div>';
      tableBody.appendChild(newRow);
      
      // Attach event listeners to new row
      attachAccessLevelRowEvents(newRow);
      accessLevelIdCounter++;
    }
    showToast('success', 'Сохранено', 'Уровень доступа "' + name + '" добавлен');
  }
  
  if (!keepOpen) {
    closeAddAccessLevelModalFn();
  } else if (resetForm) {
    if (nameInput) nameInput.value = '';
    modalOverlay.querySelectorAll('.permission-checkbox').forEach(function(cb) {
      cb.checked = false;
    });
    modalOverlay.dataset.editId = '';
    const modalTitle = modalOverlay.querySelector('.modal-title');
    if (modalTitle) modalTitle.textContent = 'Добавить';
  }
}

function initAccessLevelActions() {
  document.querySelectorAll('.level-row').forEach(function(row, index) {
    row.dataset.id = index + 1;
    attachAccessLevelRowEvents(row);
  });
}

function attachAccessLevelRowEvents(row) {
  const editIcon = row.querySelector('.action-icon.edit');
  const deleteIcon = row.querySelector('.action-icon.delete');
  
  if (editIcon) {
    editIcon.addEventListener('click', function(e) {
      e.stopPropagation();
      const name = row.querySelector('.level-name')?.textContent || '';
      const id = row.dataset.id;
      openAddAccessLevelModal({ id: id, name: name });
    });
  }
  
  if (deleteIcon) {
    deleteIcon.addEventListener('click', function(e) {
      e.stopPropagation();
      row.remove();
      showToast('success', 'Удалено', 'Уровень доступа удален');
    });
  }
}

// Initialize pages on DOMContentLoaded
document.addEventListener('DOMContentLoaded', function() {
  // Check if we're on employees page
  if (document.querySelector('.employees-table')) {
    initEmployeesPage();
  }
  
  // Check if we're on access levels page
  if (document.querySelector('.access-levels-table')) {
    initAccessLevelsPage();
  }
  
  // Check if we're on promocodes page
  if (document.querySelector('.promocodes-table')) {
    initPromocodesPage();
  }
  
  // Check if we're on promo actions page
  if (document.querySelector('.promo-actions-table')) {
    initPromoActionsPage();
  }
});

// ==================== PROMOCODES PAGE ====================
var promoIdCounter = 1428;

function initPromocodesPage() {
  const searchInput = document.getElementById('promoSearchInput');
  const statusFilter = document.getElementById('promoStatusFilter');
  const addBtn = document.getElementById('addPromoBtn');
  const closeBtn = document.getElementById('closePromoModal');
  const modalOverlay = document.getElementById('addPromoModalOverlay');
  const saveBtn = document.getElementById('savePromoBtn');
  const saveAndAddBtn = document.getElementById('saveAndAddPromoBtn');
  const applyBtn = document.getElementById('applyPromoBtn');
  const deleteBtn = document.getElementById('deletePromoBtn');
  
  if (searchInput) {
    searchInput.addEventListener('input', filterPromocodes);
  }
  
  if (statusFilter) {
    statusFilter.addEventListener('change', filterPromocodes);
  }
  
  if (addBtn) {
    addBtn.addEventListener('click', openAddPromoModal);
  }
  
  if (closeBtn) {
    closeBtn.addEventListener('click', closeAddPromoModal);
  }
  
  if (modalOverlay) {
    modalOverlay.addEventListener('click', function(e) {
      if (e.target === modalOverlay) closeAddPromoModal();
    });
  }
  
  if (saveBtn) {
    saveBtn.addEventListener('click', function() { savePromocode(false); });
  }
  
  if (saveAndAddBtn) {
    saveAndAddBtn.addEventListener('click', function() { savePromocode(true); });
  }
  
  if (applyBtn) {
    applyBtn.addEventListener('click', function() { 
      showToast('success', 'Применено', 'Изменения применены');
    });
  }
  
  if (deleteBtn) {
    deleteBtn.addEventListener('click', function() {
      showToast('success', 'Удалено', 'Промокод удален');
      closeAddPromoModal();
    });
  }
  
  // Init form selects in modal
  initFormSelects();
  
  // Attach events to existing rows
  document.querySelectorAll('.promo-row').forEach(function(row, index) {
    attachPromoRowEvents(row, 1425 + index);
  });
}

function filterPromocodes() {
  const searchInput = document.getElementById('promoSearchInput');
  const statusFilter = document.getElementById('promoStatusFilter');
  const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
  const statusTerm = statusFilter ? statusFilter.value : '';
  
  document.querySelectorAll('.promo-row').forEach(function(row) {
    const id = row.querySelector('.promo-id')?.textContent.toLowerCase() || '';
    const code = row.querySelector('.promo-code')?.textContent.toLowerCase() || '';
    const status = row.querySelector('.promo-status')?.textContent || '';
    
    const matchesSearch = id.includes(searchTerm) || code.includes(searchTerm);
    const matchesStatus = !statusTerm || status === statusTerm;
    
    row.style.display = matchesSearch && matchesStatus ? '' : 'none';
  });
}

function openAddPromoModal() {
  const modalOverlay = document.getElementById('addPromoModalOverlay');
  if (!modalOverlay) return;
  
  // Reset form
  const codeInput = document.getElementById('promoCodeInput');
  const amountInput = document.getElementById('promoAmountInput');
  const countInput = document.getElementById('promoCountInput');
  const groupText = document.getElementById('promoGroupText');
  const modalTitle = modalOverlay.querySelector('.modal-title');
  
  if (codeInput) codeInput.value = '';
  if (amountInput) amountInput.value = '';
  if (countInput) countInput.value = '1';
  if (groupText) groupText.textContent = 'Одноразовый';
  if (modalTitle) modalTitle.textContent = 'Добавить';
  
  // Clear edit mode
  delete modalOverlay.dataset.editingId;
  delete modalOverlay.dataset.editingRow;
  
  modalOverlay.classList.add('active');
}

function closeAddPromoModal() {
  const modalOverlay = document.getElementById('addPromoModalOverlay');
  if (modalOverlay) modalOverlay.classList.remove('active');
}

function savePromocode(keepOpen) {
  const codeInput = document.getElementById('promoCodeInput');
  const amountInput = document.getElementById('promoAmountInput');
  const groupText = document.getElementById('promoGroupText');
  
  var code = codeInput ? codeInput.value.trim() : '';
  const amount = amountInput ? amountInput.value.trim() : '';
  const type = groupText ? groupText.textContent : 'Одноразовый';
  
  if (!amount) {
    showToast('error', 'Ошибка', 'Введите сумму');
    return;
  }
  
  // Auto-generate code if empty
  if (!code) {
    code = generatePromoCode();
  }
  
  // Add row to table
  const tableBody = document.querySelector('.promocodes-body');
  if (tableBody) {
    const newRow = document.createElement('div');
    newRow.className = 'promo-row';
    newRow.setAttribute('data-testid', 'row-promo-' + promoIdCounter);
    newRow.innerHTML = 
      '<span class="promo-id" data-testid="text-promo-id-' + promoIdCounter + '">' + promoIdCounter + '</span>' +
      '<div class="promo-code-cell">' +
        '<span class="promo-code" data-testid="text-promo-code-' + promoIdCounter + '">' + code + '</span>' +
        '<svg class="copy-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>' +
      '</div>' +
      '<span class="promo-value" data-testid="text-promo-value-' + promoIdCounter + '">' + formatNumber(amount) + '</span>' +
      '<span class="promo-type">' + type + '</span>' +
      '<span class="promo-creator">TestRUTOR</span>' +
      '<span class="promo-status status-active">Активирован</span>' +
      '<div class="promo-dates"><span>' + getCurrentDateTime() + '</span><span>' + getCurrentDateTime() + '</span></div>' +
      '<div class="promo-actions">' +
        '<svg class="action-icon edit" data-testid="button-edit-promo-' + promoIdCounter + '" viewBox="0 0 24 24" fill="#0088ff"><path d="M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"/></svg>' +
        '<svg class="action-icon delete" data-testid="button-delete-promo-' + promoIdCounter + '" viewBox="0 0 24 24" fill="#ff383c"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>' +
      '</div>';
    tableBody.appendChild(newRow);
    attachPromoRowEvents(newRow, promoIdCounter);
    promoIdCounter++;
  }
  
  showToast('success', 'Сохранено', 'Промокод ' + code + ' добавлен');
  
  if (!keepOpen) {
    closeAddPromoModal();
  } else {
    if (codeInput) codeInput.value = '';
    if (amountInput) amountInput.value = '';
  }
}

function generatePromoCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  var code = '';
  for (var i = 0; i < 12; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

function formatNumber(num) {
  return parseFloat(num).toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function getCurrentDateTime() {
  const now = new Date();
  const day = String(now.getDate()).padStart(2, '0');
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const year = now.getFullYear();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  return day + '.' + month + '.' + year + ' ' + hours + ':' + minutes + ':' + seconds;
}

function attachPromoRowEvents(row, id) {
  const editIcon = row.querySelector('.action-icon.edit');
  const deleteIcon = row.querySelector('.action-icon.delete');
  const copyIcon = row.querySelector('.copy-icon');
  
  // Row click opens edit modal
  row.addEventListener('click', function(e) {
    if (e.target.closest('.copy-icon') || e.target.closest('.action-icon.delete')) return;
    openEditPromoModal(row, id);
  });
  
  if (editIcon) {
    editIcon.addEventListener('click', function(e) {
      e.stopPropagation();
      openEditPromoModal(row, id);
    });
  }
  
  if (deleteIcon) {
    deleteIcon.addEventListener('click', function(e) {
      e.stopPropagation();
      row.remove();
      showToast('success', 'Удалено', 'Промокод удален');
    });
  }
  
  if (copyIcon) {
    copyIcon.addEventListener('click', function(e) {
      e.stopPropagation();
      const code = row.querySelector('.promo-code')?.textContent || '';
      navigator.clipboard.writeText(code).then(function() {
        showToast('success', 'Скопировано', 'Промокод скопирован в буфер');
      });
    });
  }
}

function openEditPromoModal(row, id) {
  const modalOverlay = document.getElementById('addPromoModalOverlay');
  if (!modalOverlay) return;
  
  // Get data from row
  const code = row.querySelector('.promo-code')?.textContent || '';
  const value = row.querySelector('.promo-value')?.textContent.replace(/[^\d.,]/g, '').replace(',', '.') || '';
  const type = row.querySelector('.promo-type')?.textContent || 'Одноразовый';
  
  // Populate modal
  const codeInput = document.getElementById('promoCodeInput');
  const amountInput = document.getElementById('promoAmountInput');
  const groupText = document.getElementById('promoGroupText');
  const modalTitle = modalOverlay.querySelector('.modal-title');
  
  if (codeInput) codeInput.value = code;
  if (amountInput) amountInput.value = parseFloat(value.replace(/\s/g, '')) || '';
  if (groupText) groupText.textContent = type;
  if (modalTitle) modalTitle.textContent = 'Редактирование #' + id;
  
  // Store current editing row
  modalOverlay.dataset.editingId = id;
  modalOverlay.dataset.editingRow = 'true';
  
  modalOverlay.classList.add('active');
}

// ==================== PROMO ACTIONS PAGE ====================
var actionIdCounter = 1429;

function initPromoActionsPage() {
  const typeFilter = document.getElementById('actionTypeFilter');
  const statusFilter = document.getElementById('actionStatusFilter');
  const dateRangeBtn = document.getElementById('actionDateRangeBtn');
  const dateRangePanel = document.getElementById('actionDateRangePanel');
  const applyDateBtn = document.getElementById('applyActionDateBtn');
  const addBtn = document.getElementById('addActionBtn');
  const closeBtn = document.getElementById('closeActionModal');
  const modalOverlay = document.getElementById('addActionModalOverlay');
  const saveBtn = document.getElementById('saveActionBtn');
  const saveAndAddBtn = document.getElementById('saveAndAddActionBtn');
  const applyBtn = document.getElementById('applyActionBtn');
  const deleteBtn = document.getElementById('deleteActionBtn');
  
  if (typeFilter) {
    typeFilter.addEventListener('change', filterPromoActions);
  }
  
  if (statusFilter) {
    statusFilter.addEventListener('change', filterPromoActions);
  }
  
  if (dateRangeBtn && dateRangePanel) {
    dateRangeBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      dateRangePanel.classList.toggle('active');
    });
    
    document.addEventListener('click', function(e) {
      if (!dateRangePanel.contains(e.target) && e.target !== dateRangeBtn) {
        dateRangePanel.classList.remove('active');
      }
    });
  }
  
  if (applyDateBtn) {
    applyDateBtn.addEventListener('click', function() {
      const dateFrom = document.getElementById('actionDateFrom');
      const dateTo = document.getElementById('actionDateTo');
      const dateText = document.getElementById('actionDateRangeText');
      
      if (dateFrom && dateTo && dateText) {
        dateText.textContent = dateFrom.value + ' - ' + dateTo.value;
      }
      if (dateRangePanel) dateRangePanel.classList.remove('active');
      showToast('success', 'Применено', 'Диапазон дат обновлен');
    });
  }
  
  if (addBtn) {
    addBtn.addEventListener('click', openAddActionModal);
  }
  
  if (closeBtn) {
    closeBtn.addEventListener('click', closeAddActionModal);
  }
  
  if (modalOverlay) {
    modalOverlay.addEventListener('click', function(e) {
      if (e.target === modalOverlay) closeAddActionModal();
    });
  }
  
  if (saveBtn) {
    saveBtn.addEventListener('click', function() { savePromoAction(false); });
  }
  
  if (saveAndAddBtn) {
    saveAndAddBtn.addEventListener('click', function() { savePromoAction(true); });
  }
  
  if (applyBtn) {
    applyBtn.addEventListener('click', function() { 
      showToast('success', 'Применено', 'Изменения применены');
    });
  }
  
  if (deleteBtn) {
    deleteBtn.addEventListener('click', function() {
      showToast('success', 'Удалено', 'Промо-акция удалена');
      closeAddActionModal();
    });
  }
  
  // Init form selects in modal
  initFormSelects();
  
  // Attach events to existing rows
  document.querySelectorAll('.action-row').forEach(function(row, index) {
    attachActionRowEvents(row, 1425 + index);
  });
}

function filterPromoActions() {
  const typeFilter = document.getElementById('actionTypeFilter');
  const statusFilter = document.getElementById('actionStatusFilter');
  const typeTerm = typeFilter ? typeFilter.value : '';
  const statusTerm = statusFilter ? statusFilter.value : '';
  
  document.querySelectorAll('.action-row').forEach(function(row) {
    const type = row.dataset.type || row.querySelector('.action-type')?.textContent.replace(/\n/g, ' ').trim() || '';
    const status = row.querySelector('.action-status')?.textContent.trim() || '';
    
    const matchesType = !typeTerm || type.includes(typeTerm);
    const matchesStatus = !statusTerm || status === statusTerm;
    
    row.style.display = matchesType && matchesStatus ? '' : 'none';
  });
}

function openAddActionModal() {
  const modalOverlay = document.getElementById('addActionModalOverlay');
  if (!modalOverlay) return;
  
  // Reset form
  const typeText = document.getElementById('actionTypeText');
  const statusText = document.getElementById('actionStatusText');
  const countInput = document.getElementById('actionCountInput');
  const bonusInput = document.getElementById('actionBonusInput');
  const modalTitle = modalOverlay.querySelector('.modal-title');
  
  if (typeText) typeText.textContent = 'По кол-ву покупок';
  if (statusText) statusText.textContent = 'Не выбрано';
  if (countInput) countInput.value = '5';
  if (bonusInput) bonusInput.value = '50';
  if (modalTitle) modalTitle.textContent = 'Добавить';
  
  // Clear edit mode
  delete modalOverlay.dataset.editingId;
  delete modalOverlay.dataset.editingRow;
  
  modalOverlay.classList.add('active');
}

function closeAddActionModal() {
  const modalOverlay = document.getElementById('addActionModalOverlay');
  if (modalOverlay) modalOverlay.classList.remove('active');
}

function savePromoAction(keepOpen) {
  const typeText = document.getElementById('actionTypeText');
  const statusText = document.getElementById('actionStatusText');
  const countInput = document.getElementById('actionCountInput');
  const bonusInput = document.getElementById('actionBonusInput');
  
  const type = typeText ? typeText.textContent : 'По кол-ву покупок';
  const status = statusText ? statusText.textContent : 'Активный';
  const count = countInput ? countInput.value : '5';
  const bonus = bonusInput ? bonusInput.value : '50';
  
  // Add row to table
  const tableBody = document.querySelector('.promo-actions-body');
  if (tableBody) {
    const newRow = document.createElement('div');
    newRow.className = 'action-row';
    newRow.setAttribute('data-testid', 'row-action-' + actionIdCounter);
    
    const statusClass = status === 'Активный' ? 'status-active' : 'status-paused';
    const statusDisplay = status === 'Не выбрано' ? 'Активный' : status;
    
    newRow.innerHTML = 
      '<span class="action-id" data-testid="text-action-id-' + actionIdCounter + '">' + actionIdCounter + '</span>' +
      '<span class="action-type" data-testid="text-action-type-' + actionIdCounter + '">' + type + '</span>' +
      '<span class="action-start">' + getCurrentDateTime() + '</span>' +
      '<span class="action-end">15.12.2025 21:26:00</span>' +
      '<span class="action-status ' + statusClass + '" data-testid="text-action-status-' + actionIdCounter + '">' + statusDisplay + '</span>' +
      '<span class="action-count">' + count + '</span>' +
      '<span class="action-bonus">' + formatNumber(bonus) + ' ₽</span>' +
      '<div class="action-actions">' +
        '<svg class="action-icon edit" data-testid="button-edit-action-' + actionIdCounter + '" viewBox="0 0 24 24" fill="#0088ff"><path d="M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"/></svg>' +
      '</div>';
    tableBody.appendChild(newRow);
    attachActionRowEvents(newRow, actionIdCounter);
    actionIdCounter++;
  }
  
  showToast('success', 'Сохранено', 'Промо-акция добавлена');
  
  if (!keepOpen) {
    closeAddActionModal();
  } else {
    if (countInput) countInput.value = '5';
    if (bonusInput) bonusInput.value = '50';
  }
}

function attachActionRowEvents(row, id) {
  const editIcon = row.querySelector('.action-icon.edit');
  
  // Row click opens edit modal
  row.addEventListener('click', function(e) {
    openEditActionModal(row, id);
  });
  
  if (editIcon) {
    editIcon.addEventListener('click', function(e) {
      e.stopPropagation();
      openEditActionModal(row, id);
    });
  }
}

function openEditActionModal(row, id) {
  const modalOverlay = document.getElementById('addActionModalOverlay');
  if (!modalOverlay) return;
  
  // Get data from row
  const type = row.querySelector('.action-type')?.textContent.trim() || 'По кол-ву покупок';
  const status = row.querySelector('.action-status')?.textContent.trim() || 'Активный';
  const count = row.querySelector('.action-count')?.textContent.trim() || '5';
  const bonus = row.querySelector('.action-bonus')?.textContent.replace(/[^\d.,]/g, '').replace(',', '.').replace(/\s/g, '') || '50';
  const startDate = row.querySelector('.action-start')?.textContent.trim() || '';
  const endDate = row.querySelector('.action-end')?.textContent.trim() || '';
  
  // Populate modal
  const typeText = document.getElementById('actionTypeText');
  const statusText = document.getElementById('actionStatusText');
  const countInput = document.getElementById('actionCountInput');
  const bonusInput = document.getElementById('actionBonusInput');
  const startInput = document.getElementById('actionStartDate');
  const endInput = document.getElementById('actionEndDate');
  const modalTitle = modalOverlay.querySelector('.modal-title');
  
  if (typeText) typeText.textContent = type;
  if (statusText) statusText.textContent = status;
  if (countInput) countInput.value = count;
  if (bonusInput) bonusInput.value = parseFloat(bonus) || 50;
  if (startInput) startInput.value = startDate.replace(/\./g, '-');
  if (endInput) endInput.value = endDate.replace(/\./g, '-');
  if (modalTitle) modalTitle.textContent = 'Редактирование #' + id;
  
  // Store current editing row
  modalOverlay.dataset.editingId = id;
  modalOverlay.dataset.editingRow = 'true';
  
  modalOverlay.classList.add('active');
}

// ==================== CUMULATIVE DISCOUNT PAGE ====================
var cumulIdCounter = 4;

document.addEventListener('DOMContentLoaded', function() {
  if (document.querySelector('.cumulative-table')) {
    initCumulativePage();
  }
});

function initCumulativePage() {
  const addBtn = document.getElementById('addCumulBtn');
  const closeBtn = document.getElementById('closeCumulModal');
  const modalOverlay = document.getElementById('addCumulModalOverlay');
  const saveBtn = document.getElementById('saveCumulBtn');
  const saveAndAddBtn = document.getElementById('saveAndAddCumulBtn');
  const deleteBtn = document.getElementById('deleteCumulBtn');
  
  if (addBtn) {
    addBtn.addEventListener('click', openAddCumulModal);
  }
  
  if (closeBtn) {
    closeBtn.addEventListener('click', closeCumulModal);
  }
  
  if (modalOverlay) {
    modalOverlay.addEventListener('click', function(e) {
      if (e.target === modalOverlay) closeCumulModal();
    });
  }
  
  if (saveBtn) {
    saveBtn.addEventListener('click', function() { saveCumulative(false); });
  }
  
  if (saveAndAddBtn) {
    saveAndAddBtn.addEventListener('click', function() { saveCumulative(true); });
  }
  
  if (deleteBtn) {
    deleteBtn.addEventListener('click', deleteCumulative);
  }
  
  // Attach events to existing rows
  document.querySelectorAll('.cumul-row').forEach(function(row) {
    const id = row.dataset.id;
    attachCumulRowEvents(row, id);
  });
}

function openAddCumulModal() {
  const modalOverlay = document.getElementById('addCumulModalOverlay');
  if (!modalOverlay) return;
  
  const countInput = document.getElementById('cumulCountInput');
  const discountInput = document.getElementById('cumulDiscountInput');
  const modalTitle = modalOverlay.querySelector('.modal-title');
  
  if (countInput) countInput.value = '';
  if (discountInput) discountInput.value = '';
  if (modalTitle) modalTitle.textContent = 'Добавить';
  
  delete modalOverlay.dataset.editingId;
  delete modalOverlay.dataset.editingRow;
  
  modalOverlay.classList.add('active');
}

function closeCumulModal() {
  const modalOverlay = document.getElementById('addCumulModalOverlay');
  if (modalOverlay) modalOverlay.classList.remove('active');
}

function saveCumulative(keepOpen) {
  const countInput = document.getElementById('cumulCountInput');
  const discountInput = document.getElementById('cumulDiscountInput');
  const modalOverlay = document.getElementById('addCumulModalOverlay');
  
  const count = countInput ? countInput.value.trim() : '';
  const discount = discountInput ? discountInput.value.trim() : '';
  
  if (!count || !discount) {
    showToast('error', 'Ошибка', 'Заполните все поля');
    return;
  }
  
  const isEditing = modalOverlay && modalOverlay.dataset.editingRow === 'true';
  const editingId = modalOverlay ? modalOverlay.dataset.editingId : null;
  
  if (isEditing && editingId) {
    // Update existing row
    const row = document.querySelector('.cumul-row[data-id="' + editingId + '"]');
    if (row) {
      row.querySelector('.cumul-count').textContent = count;
      row.querySelector('.cumul-discount').textContent = discount + '%';
      showToast('success', 'Сохранено', 'Накопительная скидка обновлена');
    }
  } else {
    // Add new row
    const tableBody = document.querySelector('.cumulative-body');
    if (tableBody) {
      const newRow = document.createElement('div');
      newRow.className = 'cumul-row';
      newRow.dataset.id = cumulIdCounter;
      newRow.setAttribute('data-testid', 'row-cumul-' + cumulIdCounter);
      newRow.innerHTML = 
        '<span class="cumul-count" data-testid="text-cumul-count-' + cumulIdCounter + '">' + count + '</span>' +
        '<span class="cumul-discount" data-testid="text-cumul-discount-' + cumulIdCounter + '">' + discount + '%</span>' +
        '<span class="cumul-date">' + getCurrentDateTime() + '</span>' +
        '<div class="cumul-actions">' +
          '<svg class="action-icon edit" data-testid="button-edit-cumul-' + cumulIdCounter + '" viewBox="0 0 24 24" fill="#0088ff"><path d="M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"/></svg>' +
        '</div>';
      tableBody.appendChild(newRow);
      attachCumulRowEvents(newRow, cumulIdCounter);
      cumulIdCounter++;
      showToast('success', 'Сохранено', 'Накопительная скидка добавлена');
    }
  }
  
  if (!keepOpen) {
    closeCumulModal();
  } else {
    if (countInput) countInput.value = '';
    if (discountInput) discountInput.value = '';
  }
}

function deleteCumulative() {
  const modalOverlay = document.getElementById('addCumulModalOverlay');
  const editingId = modalOverlay ? modalOverlay.dataset.editingId : null;
  
  if (editingId) {
    const row = document.querySelector('.cumul-row[data-id="' + editingId + '"]');
    if (row) {
      row.remove();
      showToast('success', 'Удалено', 'Накопительная скидка удалена');
    }
  }
  closeCumulModal();
}

function attachCumulRowEvents(row, id) {
  const editIcon = row.querySelector('.action-icon.edit');
  
  // Row click opens edit modal
  row.addEventListener('click', function(e) {
    openEditCumulModal(row, id);
  });
  
  if (editIcon) {
    editIcon.addEventListener('click', function(e) {
      e.stopPropagation();
      openEditCumulModal(row, id);
    });
  }
}

function openEditCumulModal(row, id) {
  const modalOverlay = document.getElementById('addCumulModalOverlay');
  if (!modalOverlay) return;
  
  const count = row.querySelector('.cumul-count')?.textContent.trim() || '';
  const discount = row.querySelector('.cumul-discount')?.textContent.replace('%', '').trim() || '';
  
  const countInput = document.getElementById('cumulCountInput');
  const discountInput = document.getElementById('cumulDiscountInput');
  const modalTitle = modalOverlay.querySelector('.modal-title');
  
  if (countInput) countInput.value = count;
  if (discountInput) discountInput.value = discount;
  if (modalTitle) modalTitle.textContent = 'Редактирование #' + id;
  
  modalOverlay.dataset.editingId = id;
  modalOverlay.dataset.editingRow = 'true';
  
  modalOverlay.classList.add('active');
}

// Helper function to close all filter dropdowns
function closeAllDropdowns() {
  document.querySelectorAll('.filter-dropdown').forEach(function(d) {
    d.classList.remove('active');
  });
}

// ==================== REVIEWS PAGE ====================
var reviewFilters = {
  rating: 'all',
  status: 'all',
  dateFrom: null,
  dateTo: null
};

document.addEventListener('DOMContentLoaded', function() {
  if (document.querySelector('.reviews-table')) {
    initReviewsPage();
  }
});

function initReviewsPage() {
  // Rating filter
  const ratingFilter = document.getElementById('reviewRatingFilter');
  if (ratingFilter) {
    ratingFilter.addEventListener('click', function(e) {
      e.stopPropagation();
      closeAllDropdowns();
      this.classList.toggle('active');
    });
    
    ratingFilter.querySelectorAll('.filter-dropdown-item').forEach(function(item) {
      item.addEventListener('click', function(e) {
        e.stopPropagation();
        const value = this.dataset.value;
        reviewFilters.rating = value;
        const text = document.getElementById('reviewRatingText');
        if (text) {
          text.textContent = value === 'all' ? 'Рейтинг' : 'Рейтинг: ' + value;
        }
        ratingFilter.classList.remove('active');
        applyReviewFilters();
      });
    });
  }
  
  // Status filter
  const statusFilter = document.getElementById('reviewStatusFilter');
  if (statusFilter) {
    statusFilter.addEventListener('click', function(e) {
      e.stopPropagation();
      closeAllDropdowns();
      this.classList.toggle('active');
    });
    
    statusFilter.querySelectorAll('.filter-dropdown-item').forEach(function(item) {
      item.addEventListener('click', function(e) {
        e.stopPropagation();
        const value = this.dataset.value;
        reviewFilters.status = value;
        const text = document.getElementById('reviewStatusText');
        if (text) {
          var displayText = 'Статус';
          if (value === 'moderation') displayText = 'На модерации';
          else if (value === 'approved') displayText = 'Одобрено';
          else if (value === 'rejected') displayText = 'Отклонено';
          text.textContent = displayText;
        }
        statusFilter.classList.remove('active');
        applyReviewFilters();
      });
    });
  }
  
  // Date filter
  const dateFilter = document.getElementById('reviewDateFilter');
  if (dateFilter) {
    dateFilter.addEventListener('click', function(e) {
      if (e.target.closest('.date-picker-menu')) return;
      e.stopPropagation();
      closeAllDropdowns();
      this.classList.toggle('active');
    });
  }
  
  const applyDateBtn = document.getElementById('applyDateFilter');
  if (applyDateBtn) {
    applyDateBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      const fromInput = document.getElementById('reviewDateFrom');
      const toInput = document.getElementById('reviewDateTo');
      const dateText = document.getElementById('reviewDateText');
      
      reviewFilters.dateFrom = fromInput && fromInput.value ? fromInput.value : null;
      reviewFilters.dateTo = toInput && toInput.value ? toInput.value : null;
      
      if (reviewFilters.dateFrom && reviewFilters.dateTo) {
        dateText.textContent = formatDateDisplay(reviewFilters.dateFrom) + ' - ' + formatDateDisplay(reviewFilters.dateTo);
      } else if (reviewFilters.dateFrom) {
        dateText.textContent = 'От ' + formatDateDisplay(reviewFilters.dateFrom);
      } else if (reviewFilters.dateTo) {
        dateText.textContent = 'До ' + formatDateDisplay(reviewFilters.dateTo);
      } else {
        dateText.textContent = 'Выберите даты';
      }
      
      dateFilter.classList.remove('active');
      applyReviewFilters();
    });
  }
  
  const resetDateBtn = document.getElementById('resetDateFilter');
  if (resetDateBtn) {
    resetDateBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      const fromInput = document.getElementById('reviewDateFrom');
      const toInput = document.getElementById('reviewDateTo');
      const dateText = document.getElementById('reviewDateText');
      
      if (fromInput) fromInput.value = '';
      if (toInput) toInput.value = '';
      reviewFilters.dateFrom = null;
      reviewFilters.dateTo = null;
      dateText.textContent = 'Выберите даты';
      
      dateFilter.classList.remove('active');
      applyReviewFilters();
    });
  }
  
  // Close dropdowns when clicking outside
  document.addEventListener('click', function() {
    document.querySelectorAll('.filter-dropdown').forEach(function(d) {
      d.classList.remove('active');
    });
  });
  
  // Attach events to review cards
  document.querySelectorAll('.review-card').forEach(function(card) {
    attachReviewCardEvents(card);
  });
}

function formatDateDisplay(dateStr) {
  if (!dateStr) return '';
  var parts = dateStr.split('-');
  if (parts.length === 3) {
    return parts[2] + '.' + parts[1] + '.' + parts[0];
  }
  return dateStr;
}

function parseDateFromText(dateText) {
  // Parse date from format "DD.MM.YYYY HH:MM:SS"
  if (!dateText) return null;
  var parts = dateText.trim().split(' ');
  if (parts.length >= 1) {
    var dateParts = parts[0].split('.');
    if (dateParts.length === 3) {
      return new Date(dateParts[2], dateParts[1] - 1, dateParts[0]);
    }
  }
  return null;
}

function applyReviewFilters() {
  document.querySelectorAll('.review-card').forEach(function(card) {
    var show = true;
    
    // Filter by rating
    if (reviewFilters.rating !== 'all') {
      var cardRating = card.dataset.rating;
      if (cardRating !== reviewFilters.rating) {
        show = false;
      }
    }
    
    // Filter by status
    if (reviewFilters.status !== 'all') {
      var cardStatus = card.dataset.status;
      if (cardStatus !== reviewFilters.status) {
        show = false;
      }
    }
    
    // Filter by date
    if (reviewFilters.dateFrom || reviewFilters.dateTo) {
      var dateEl = card.querySelector('.review-date');
      if (dateEl) {
        var cardDate = parseDateFromText(dateEl.textContent);
        if (cardDate) {
          if (reviewFilters.dateFrom) {
            var fromDate = new Date(reviewFilters.dateFrom);
            fromDate.setHours(0, 0, 0, 0);
            if (cardDate < fromDate) {
              show = false;
            }
          }
          if (reviewFilters.dateTo) {
            var toDate = new Date(reviewFilters.dateTo);
            toDate.setHours(23, 59, 59, 999);
            if (cardDate > toDate) {
              show = false;
            }
          }
        }
      }
    }
    
    // Animate show/hide
    var isCurrentlyHidden = card.classList.contains('hidden');
    
    if (show && isCurrentlyHidden) {
      // Show card with animation
      card.classList.remove('hidden', 'hiding');
      card.classList.add('showing');
      setTimeout(function() {
        card.classList.remove('showing');
      }, 300);
    } else if (!show && !isCurrentlyHidden) {
      // Hide card with animation
      card.classList.add('hiding');
      setTimeout(function() {
        card.classList.remove('hiding');
        card.classList.add('hidden');
      }, 300);
    }
  });
}

function attachReviewCardEvents(card) {
  const thumbUp = card.querySelector('.thumb-up');
  const thumbDown = card.querySelector('.thumb-down');
  
  if (thumbUp) {
    thumbUp.addEventListener('click', function(e) {
      e.stopPropagation();
      approveReview(card);
    });
  }
  
  if (thumbDown) {
    thumbDown.addEventListener('click', function(e) {
      e.stopPropagation();
      rejectReview(card);
    });
  }
}

function approveReview(card) {
  card.dataset.status = 'approved';
  const statusEl = card.querySelector('.review-status');
  if (statusEl) {
    statusEl.className = 'review-status status-approved';
    statusEl.textContent = 'Одобрено';
  }
  showToast('success', 'Одобрено', 'Отзыв одобрен');
  applyReviewFilters();
}

function rejectReview(card) {
  card.dataset.status = 'rejected';
  const statusEl = card.querySelector('.review-status');
  if (statusEl) {
    statusEl.className = 'review-status status-rejected';
    statusEl.textContent = 'Отклонено';
  }
  showToast('success', 'Отклонено', 'Отзыв отклонён');
  applyReviewFilters();
}

// ==================== MAILING CHANNELS MODAL ====================
var channelsData = [];
var channelIdCounter = 10;
var editingChannelId = null;

document.addEventListener('DOMContentLoaded', function() {
  const addBtn = document.querySelector('.btn-add');
  const modal = document.getElementById('addChannelModal');
  const closeBtn = document.getElementById('closeAddChannelModal');
  const tableBody = document.querySelector('.mailing-channels-table .table-body');
  
  // Load existing channels from table
  if (tableBody) {
    loadExistingChannels();
  }
  
  if (addBtn && modal) {
    addBtn.addEventListener('click', function() {
      openChannelModal();
    });
  }
  
  if (closeBtn && modal) {
    closeBtn.addEventListener('click', function() {
      closeChannelModal();
    });
  }
  
  if (modal) {
    modal.addEventListener('click', function(e) {
      if (e.target === modal) {
        closeChannelModal();
      }
    });
    
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && modal.classList.contains('active')) {
        closeChannelModal();
      }
    });
    
    // Button handlers
    const btnSaveAddAnother = modal.querySelector('[data-testid="button-save-add-another"]');
    const btnApply = modal.querySelector('[data-testid="button-apply"]');
    const btnSave = modal.querySelector('[data-testid="button-save"]');
    const btnDelete = modal.querySelector('[data-testid="button-delete"]');
    
    if (btnSaveAddAnother) {
      btnSaveAddAnother.addEventListener('click', function() {
        if (saveChannel()) {
          clearChannelForm();
          showToast('success', 'Сохранено', 'Канал добавлен. Добавьте следующий.');
        }
      });
    }
    
    if (btnApply) {
      btnApply.addEventListener('click', function() {
        if (saveChannel()) {
          showToast('success', 'Применено', 'Изменения применены');
        }
      });
    }
    
    if (btnSave) {
      btnSave.addEventListener('click', function() {
        if (saveChannel()) {
          closeChannelModal();
          showToast('success', 'Сохранено', 'Канал сохранён');
        }
      });
    }
    
    if (btnDelete) {
      btnDelete.addEventListener('click', function() {
        if (editingChannelId !== null) {
          deleteChannel(editingChannelId);
          closeChannelModal();
          showToast('success', 'Удалено', 'Канал удалён');
        }
      });
    }
  }
});

function loadExistingChannels() {
  const rows = document.querySelectorAll('.mailing-channels-table .table-row');
  rows.forEach(function(row) {
    const id = parseInt(row.querySelector('.td-id').textContent);
    const name = row.querySelector('.td-name').textContent;
    const date = row.querySelector('.td-date').textContent;
    channelsData.push({
      id: id,
      name: name,
      channelId: '',
      botToken: '',
      forumThread: '0',
      date: date
    });
    if (id >= channelIdCounter) {
      channelIdCounter = id + 1;
    }
    
    // Add click handler to edit
    row.style.cursor = 'pointer';
    row.addEventListener('click', function() {
      openChannelModal(id);
    });
  });
}

function openChannelModal(channelId) {
  const modal = document.getElementById('addChannelModal');
  const title = modal.querySelector('.modal-title');
  const btnDelete = modal.querySelector('[data-testid="button-delete"]');
  
  if (channelId !== undefined) {
    editingChannelId = channelId;
    const channel = channelsData.find(c => c.id === channelId);
    if (channel) {
      document.getElementById('channelName').value = channel.name;
      document.getElementById('channelId').value = channel.channelId || '';
      document.getElementById('botToken').value = channel.botToken || '';
      document.getElementById('forumThread').value = channel.forumThread || '0';
      title.textContent = 'Редактировать';
      btnDelete.style.display = 'flex';
    }
  } else {
    editingChannelId = null;
    clearChannelForm();
    title.textContent = 'Добавить';
    btnDelete.style.display = 'none';
  }
  
  modal.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeChannelModal() {
  const modal = document.getElementById('addChannelModal');
  modal.classList.remove('active');
  document.body.style.overflow = '';
  editingChannelId = null;
}

function clearChannelForm() {
  document.getElementById('channelName').value = '';
  document.getElementById('channelId').value = '';
  document.getElementById('botToken').value = '';
  document.getElementById('forumThread').value = '0';
}

function saveChannel() {
  const name = document.getElementById('channelName').value.trim();
  const channelIdVal = document.getElementById('channelId').value.trim();
  const botToken = document.getElementById('botToken').value.trim();
  const forumThread = document.getElementById('forumThread').value.trim() || '0';
  
  if (!name) {
    showToast('error', 'Ошибка', 'Введите название канала');
    return false;
  }
  
  const now = new Date();
  const dateStr = formatDateTime(now);
  
  if (editingChannelId !== null) {
    // Update existing
    const channel = channelsData.find(c => c.id === editingChannelId);
    if (channel) {
      channel.name = name;
      channel.channelId = channelIdVal;
      channel.botToken = botToken;
      channel.forumThread = forumThread;
      updateChannelRow(channel);
    }
  } else {
    // Add new
    const newChannel = {
      id: channelIdCounter++,
      name: name,
      channelId: channelIdVal,
      botToken: botToken,
      forumThread: forumThread,
      date: dateStr
    };
    channelsData.push(newChannel);
    addChannelRow(newChannel);
    editingChannelId = newChannel.id;
  }
  
  return true;
}

function addChannelRow(channel) {
  const tableBody = document.querySelector('.mailing-channels-table .table-body');
  if (!tableBody) return;
  
  const row = document.createElement('div');
  row.className = 'table-row';
  row.dataset.channelId = channel.id;
  row.style.cursor = 'pointer';
  row.innerHTML = `
    <div class="td td-id">${channel.id}</div>
    <div class="td td-name">${escapeHtml(channel.name)}</div>
    <div class="td td-status"></div>
    <div class="td td-date">${channel.date}</div>
    <div class="td td-actions">
      <svg class="action-icon history-icon clock-animated" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" fill="#0088FF"/><circle cx="12" cy="12" r="7.5" fill="#33363F"/><line class="clock-hand-hour" x1="12" y1="12" x2="12" y2="6.5" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/><line class="clock-hand-minute" x1="12" y1="12" x2="15.5" y2="12" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/></svg>
    </div>
  `;
  
  row.addEventListener('click', function() {
    openChannelModal(channel.id);
  });
  
  // Add with animation
  row.style.opacity = '0';
  row.style.transform = 'translateY(-10px)';
  tableBody.insertBefore(row, tableBody.firstChild);
  
  setTimeout(function() {
    row.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    row.style.opacity = '1';
    row.style.transform = 'translateY(0)';
  }, 10);
}

function updateChannelRow(channel) {
  const row = document.querySelector(`.table-row[data-channel-id="${channel.id}"]`);
  if (row) {
    row.querySelector('.td-name').textContent = channel.name;
  } else {
    // Find by id text
    const rows = document.querySelectorAll('.mailing-channels-table .table-row');
    rows.forEach(function(r) {
      if (parseInt(r.querySelector('.td-id').textContent) === channel.id) {
        r.querySelector('.td-name').textContent = channel.name;
        r.dataset.channelId = channel.id;
      }
    });
  }
}

function deleteChannel(channelId) {
  const index = channelsData.findIndex(c => c.id === channelId);
  if (index > -1) {
    channelsData.splice(index, 1);
  }
  
  // Find and remove row
  const rows = document.querySelectorAll('.mailing-channels-table .table-row');
  rows.forEach(function(row) {
    if (row.dataset.channelId == channelId || parseInt(row.querySelector('.td-id').textContent) === channelId) {
      row.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
      row.style.opacity = '0';
      row.style.transform = 'translateX(-20px)';
      setTimeout(function() {
        row.remove();
      }, 300);
    }
  });
}

function formatDateTime(date) {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  return `${day}.${month}.${year} ${hours}:${minutes}:${seconds}`;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Publication Modal for Channel Publications Page
let publicationIdCounter = 100;

function initPublicationModal() {
  const overlay = document.getElementById('publicationModalOverlay');
  const addBtn = document.querySelector('.toolbar .btn-add');
  const closeBtn = document.getElementById('publicationModalClose');
  const modalTitle = document.getElementById('publicationModalTitle');
  const channelDropdown = document.getElementById('pubChannelDropdown');
  const channelMenu = document.getElementById('pubChannelMenu');
  const fileBtn = document.getElementById('pubFileBtn');
  const fileInput = document.getElementById('pubFileInput');
  const fileDisplay = document.getElementById('pubFileDisplay');
  const messageInput = document.getElementById('pubMessageInput');
  const buttonsInput = document.getElementById('pubButtonsInput');
  const saveAndAddBtn = document.getElementById('pubSaveAndAdd');
  const applyBtn = document.getElementById('pubApply');
  const saveBtn = document.getElementById('pubSave');
  const deleteBtn = document.getElementById('pubDelete');
  const tableBody = document.querySelector('.publications-table .table-body');
  
  if (!overlay || !addBtn) return;
  
  let editingRow = null;
  let selectedChannel = 'Каналы';
  let selectedFile = null;
  let selectedFileDataUrl = null;
  
  function openModal(isEdit, row) {
    editingRow = isEdit ? row : null;
    
    if (isEdit && row) {
      modalTitle.textContent = 'Редактировать публикацию';
      const text = row.querySelector('.pub-text')?.textContent || '';
      messageInput.value = text;
      deleteBtn.style.display = 'flex';
    } else {
      modalTitle.textContent = 'Добавить публикацию';
      resetForm();
      deleteBtn.style.display = 'none';
    }
    
    overlay.classList.add('active');
    setTimeout(function() { messageInput.focus(); }, 100);
  }
  
  function closeModal() {
    overlay.classList.add('closing');
    overlay.classList.remove('active');
    setTimeout(function() {
      overlay.classList.remove('closing');
      editingRow = null;
    }, 300);
  }
  
  function resetForm() {
    messageInput.value = '';
    buttonsInput.value = '';
    selectedChannel = 'Каналы';
    selectedFile = null;
    selectedFileDataUrl = null;
    channelDropdown.querySelector('span').textContent = 'Каналы';
    fileDisplay.querySelector('span').textContent = 'Файл не выбран';
    fileInput.value = '';
  }
  
  function createPublicationRow(id, message, imageDataUrl) {
    const row = document.createElement('div');
    row.className = 'publication-row simple fade-in';
    row.dataset.pubId = id;
    
    const attachmentHtml = imageDataUrl 
      ? '<div class="pub-attachment"><img src="' + imageDataUrl + '" alt="Вложение" class="pub-image"></div>'
      : '<div class="pub-attachment-text">Без вложения</div>';
    
    row.innerHTML = 
      '<div class="pub-id">' + id + '</div>' +
      attachmentHtml +
      '<div class="pub-text">' + escapeHtml(message || 'Новая публикация') + '</div>' +
      '<div class="pub-status"></div>' +
      '<div class="pub-action"><button class="btn-launch">Запуск</button></div>';
    
    row.addEventListener('click', function(e) {
      if (!e.target.closest('.btn-launch')) {
        openModal(true, row);
      }
    });
    
    const launchBtn = row.querySelector('.btn-launch');
    if (launchBtn) {
      launchBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        handleLaunch(row);
      });
    }
    
    return row;
  }
  
  function savePublication(keepOpen) {
    const message = messageInput.value.trim();
    
    if (editingRow) {
      editingRow.querySelector('.pub-text').textContent = message || 'Публикация';
      if (selectedFileDataUrl) {
        const attachmentEl = editingRow.querySelector('.pub-attachment-text');
        const existingImg = editingRow.querySelector('.pub-attachment img');
        if (attachmentEl) {
          attachmentEl.outerHTML = '<div class="pub-attachment"><img src="' + selectedFileDataUrl + '" alt="Вложение" class="pub-image"></div>';
        } else if (existingImg) {
          existingImg.src = selectedFileDataUrl;
        }
      }
      showToast('success', 'Успешно', 'Публикация обновлена');
      if (!keepOpen) closeModal();
    } else {
      const newRow = createPublicationRow(publicationIdCounter++, message, selectedFileDataUrl);
      tableBody.insertBefore(newRow, tableBody.firstChild);
      showToast('success', 'Успешно', 'Публикация добавлена');
      if (keepOpen) {
        resetForm();
      } else {
        closeModal();
      }
    }
  }
  
  function deletePublication() {
    if (editingRow) {
      editingRow.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
      editingRow.style.opacity = '0';
      editingRow.style.transform = 'translateX(-20px)';
      setTimeout(function() {
        editingRow.remove();
      }, 300);
      showToast('success', 'Удалено', 'Публикация удалена');
      closeModal();
    }
  }
  
  function handleLaunch(row) {
    const statusEl = row.querySelector('.pub-status');
    if (statusEl) {
      const now = new Date();
      const dateStr = formatDateTime(now).substring(0, 16);
      statusEl.innerHTML = 
        '<div class="pub-status-label">Последний запуск</div>' +
        '<div class="pub-status-date">' + dateStr + '</div>' +
        '<div class="pub-status-badges">' +
        '<span class="badge badge-gray">' + Math.floor(Math.random() * 20) + '</span>' +
        '<span class="badge badge-green">' + Math.floor(Math.random() * 50) + '</span>' +
        '<span class="badge badge-red">' + Math.floor(Math.random() * 15) + '</span>' +
        '</div>';
    }
    showToast('success', 'Запущено', 'Публикация отправлена в каналы');
  }
  
  // Event listeners
  addBtn.addEventListener('click', function() {
    openModal(false, null);
  });
  
  closeBtn.addEventListener('click', closeModal);
  
  overlay.addEventListener('click', function(e) {
    if (e.target === overlay) closeModal();
  });
  
  // Dropdown
  channelDropdown.addEventListener('click', function(e) {
    e.stopPropagation();
    channelDropdown.closest('.pub-dropdown-wrapper').classList.toggle('open');
  });
  
  channelMenu.querySelectorAll('.pub-dropdown-item').forEach(function(item) {
    item.addEventListener('click', function(e) {
      e.stopPropagation();
      selectedChannel = item.textContent;
      channelDropdown.querySelector('span').textContent = selectedChannel;
      channelDropdown.closest('.pub-dropdown-wrapper').classList.remove('open');
    });
  });
  
  document.addEventListener('click', function() {
    document.querySelectorAll('.pub-dropdown-wrapper.open').forEach(function(w) {
      w.classList.remove('open');
    });
  });
  
  // File upload
  fileBtn.addEventListener('click', function() {
    fileInput.click();
  });
  
  fileInput.addEventListener('change', function() {
    if (fileInput.files.length > 0) {
      selectedFile = fileInput.files[0];
      fileDisplay.querySelector('span').textContent = selectedFile.name;
      
      // Read file as data URL for preview
      const reader = new FileReader();
      reader.onload = function(e) {
        selectedFileDataUrl = e.target.result;
      };
      reader.readAsDataURL(selectedFile);
    }
  });
  
  // Button handlers
  saveAndAddBtn.addEventListener('click', function() {
    savePublication(true);
  });
  
  applyBtn.addEventListener('click', function() {
    savePublication(false);
  });
  
  saveBtn.addEventListener('click', function() {
    savePublication(false);
  });
  
  deleteBtn.addEventListener('click', deletePublication);
  
  // Init existing rows
  document.querySelectorAll('.publication-row').forEach(function(row) {
    row.addEventListener('click', function(e) {
      if (!e.target.closest('.btn-launch')) {
        openModal(true, row);
      }
    });
    
    const launchBtn = row.querySelector('.btn-launch');
    if (launchBtn) {
      launchBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        handleLaunch(row);
      });
    }
  });
}

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', function() {
  initPublicationModal();
});

// Bot Mailing Modal for Bot Mailings Page
let mailingIdCounter = 100;

function initBotMailingModal() {
  const overlay = document.getElementById('botMailingModalOverlay');
  const addBtn = document.querySelector('.toolbar .btn-add');
  const closeBtn = document.getElementById('botMailingModalClose');
  const modalTitle = document.getElementById('botMailingModalTitle');
  const fileBtn = document.getElementById('mailingFileBtn');
  const fileInput = document.getElementById('mailingFileInput');
  const fileDisplay = document.getElementById('mailingFileDisplay');
  const textInput = document.getElementById('mailingTextInput');
  const buttonsInput = document.getElementById('mailingButtonsInput');
  const saveAndAddBtn = document.getElementById('mailingSaveAndAdd');
  const applyBtn = document.getElementById('mailingApply');
  const saveBtn = document.getElementById('mailingSave');
  const deleteBtn = document.getElementById('mailingDelete');
  const tableBody = document.querySelector('.data-table .table-body');
  
  if (!overlay || !addBtn) return;
  
  let editingRow = null;
  let selectedFile = null;
  let selectedFileDataUrl = null;
  
  function openModal(isEdit, row) {
    editingRow = isEdit ? row : null;
    
    if (isEdit && row) {
      modalTitle.textContent = 'Редактировать рассылку';
      const name = row.querySelector('.td-name')?.textContent || '';
      textInput.value = name;
      deleteBtn.style.display = 'flex';
    } else {
      modalTitle.textContent = 'Добавить рассылку';
      resetForm();
      deleteBtn.style.display = 'none';
    }
    
    overlay.classList.add('active');
    setTimeout(function() { textInput.focus(); }, 100);
  }
  
  function closeModal() {
    overlay.classList.add('closing');
    overlay.classList.remove('active');
    setTimeout(function() {
      overlay.classList.remove('closing');
      editingRow = null;
    }, 300);
  }
  
  function resetForm() {
    textInput.value = '';
    buttonsInput.value = '';
    selectedFile = null;
    selectedFileDataUrl = null;
    fileDisplay.querySelector('span').textContent = 'Файл не выбран';
    fileInput.value = '';
    document.getElementById('mailingNoClients').checked = false;
    document.getElementById('mailingOnlyBuyers').checked = false;
    
    // Reset dropdowns
    document.querySelector('#mailingTypeDropdown span').textContent = 'Ручной запуск';
    document.querySelector('#mailingCitiesDropdown span').textContent = 'Все города';
    document.querySelector('#mailingChannelsDropdown span').textContent = 'Каналы';
    document.querySelector('#mailingStatusDropdown span').textContent = 'Активная';
  }
  
  function getStatusBadgeClass(status) {
    switch(status) {
      case 'Активная': return 'status-active';
      case 'На паузе': return 'status-paused';
      case 'Неактивная': return 'status-inactive';
      default: return 'status-active';
    }
  }
  
  function createMailingRow(id, name, status) {
    const row = document.createElement('div');
    row.className = 'table-row fade-in';
    row.dataset.mailingId = id;
    
    const now = new Date();
    const dateStr = formatDateTime(now);
    const badgeClass = getStatusBadgeClass(status);
    const statusText = status === 'Активная' ? 'Активно' : (status === 'На паузе' ? 'На паузе' : 'Неактивно');
    
    row.innerHTML = 
      '<div class="td td-id">' + id + '</div>' +
      '<div class="td td-name">' + escapeHtml(name || 'Новая рассылка') + '</div>' +
      '<div class="td td-status"><span class="status-badge ' + badgeClass + '">' + statusText + '</span></div>' +
      '<div class="td td-date">' + dateStr + '</div>' +
      '<div class="td td-actions"><svg class="action-icon history-icon clock-animated" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" fill="#0088FF"/><circle cx="12" cy="12" r="7.5" fill="#33363F"/><line class="clock-hand-hour" x1="12" y1="12" x2="12" y2="6.5" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/><line class="clock-hand-minute" x1="12" y1="12" x2="15.5" y2="12" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/></svg></div>';
    
    row.addEventListener('click', function(e) {
      if (!e.target.closest('.action-icon')) {
        openModal(true, row);
      }
    });
    
    return row;
  }
  
  function saveMailing(keepOpen) {
    const name = textInput.value.trim();
    const status = document.querySelector('#mailingStatusDropdown span').textContent;
    
    if (editingRow) {
      editingRow.querySelector('.td-name').textContent = name || 'Рассылка';
      const badgeClass = getStatusBadgeClass(status);
      const statusText = status === 'Активная' ? 'Активно' : (status === 'На паузе' ? 'На паузе' : 'Неактивно');
      editingRow.querySelector('.status-badge').className = 'status-badge ' + badgeClass;
      editingRow.querySelector('.status-badge').textContent = statusText;
      showToast('success', 'Успешно', 'Рассылка обновлена');
      if (!keepOpen) closeModal();
    } else {
      const newRow = createMailingRow(mailingIdCounter++, name, status);
      tableBody.insertBefore(newRow, tableBody.firstChild);
      showToast('success', 'Успешно', 'Рассылка добавлена');
      if (keepOpen) {
        resetForm();
      } else {
        closeModal();
      }
    }
  }
  
  function deleteMailing() {
    if (editingRow) {
      editingRow.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
      editingRow.style.opacity = '0';
      editingRow.style.transform = 'translateX(-20px)';
      setTimeout(function() {
        editingRow.remove();
      }, 300);
      showToast('success', 'Удалено', 'Рассылка удалена');
      closeModal();
    }
  }
  
  // Event listeners
  addBtn.addEventListener('click', function() {
    openModal(false, null);
  });
  
  closeBtn.addEventListener('click', closeModal);
  
  overlay.addEventListener('click', function(e) {
    if (e.target === overlay) closeModal();
  });
  
  // Initialize all dropdowns
  const dropdowns = [
    { toggle: 'mailingTypeDropdown', menu: 'mailingTypeMenu' },
    { toggle: 'mailingCitiesDropdown', menu: 'mailingCitiesMenu' },
    { toggle: 'mailingChannelsDropdown', menu: 'mailingChannelsMenu' },
    { toggle: 'mailingStatusDropdown', menu: 'mailingStatusMenu' }
  ];
  
  dropdowns.forEach(function(dd) {
    const toggle = document.getElementById(dd.toggle);
    const menu = document.getElementById(dd.menu);
    if (!toggle || !menu) return;
    
    toggle.addEventListener('click', function(e) {
      e.stopPropagation();
      // Close other dropdowns
      document.querySelectorAll('.mailing-dropdown-wrapper.open').forEach(function(w) {
        if (w !== toggle.closest('.mailing-dropdown-wrapper')) {
          w.classList.remove('open');
        }
      });
      toggle.closest('.mailing-dropdown-wrapper').classList.toggle('open');
    });
    
    menu.querySelectorAll('.mailing-dropdown-item').forEach(function(item) {
      item.addEventListener('click', function(e) {
        e.stopPropagation();
        toggle.querySelector('span').textContent = item.textContent;
        toggle.closest('.mailing-dropdown-wrapper').classList.remove('open');
      });
    });
  });
  
  document.addEventListener('click', function() {
    document.querySelectorAll('.mailing-dropdown-wrapper.open').forEach(function(w) {
      w.classList.remove('open');
    });
  });
  
  // File upload
  fileBtn.addEventListener('click', function() {
    fileInput.click();
  });
  
  fileInput.addEventListener('change', function() {
    if (fileInput.files.length > 0) {
      selectedFile = fileInput.files[0];
      fileDisplay.querySelector('span').textContent = selectedFile.name;
      
      const reader = new FileReader();
      reader.onload = function(e) {
        selectedFileDataUrl = e.target.result;
      };
      reader.readAsDataURL(selectedFile);
    }
  });
  
  // Button handlers
  saveAndAddBtn.addEventListener('click', function() {
    saveMailing(true);
  });
  
  applyBtn.addEventListener('click', function() {
    saveMailing(false);
  });
  
  saveBtn.addEventListener('click', function() {
    saveMailing(false);
  });
  
  deleteBtn.addEventListener('click', deleteMailing);
  
  // Init existing rows
  document.querySelectorAll('.data-table .table-row').forEach(function(row) {
    row.addEventListener('click', function(e) {
      if (!e.target.closest('.action-icon')) {
        openModal(true, row);
      }
    });
  });
}

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', function() {
  initBotMailingModal();
});

// Bot Mailings Page - Filter dropdown handler
function initBotMailingsFilters() {
  const typeFilterWrapper = document.getElementById('typeFilterWrapper');
  const typeFilterBtn = document.getElementById('typeFilterBtn');
  const typeFilterMenu = document.getElementById('typeFilterMenu');
  
  if (!typeFilterBtn) return;
  
  typeFilterBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    typeFilterWrapper.classList.toggle('open');
  });
  
  typeFilterMenu?.querySelectorAll('.bot-filter-item').forEach(function(item) {
    item.addEventListener('click', function(e) {
      e.stopPropagation();
      typeFilterBtn.querySelector('span').textContent = item.textContent;
      typeFilterWrapper.classList.remove('open');
    });
  });
  
  document.addEventListener('click', function() {
    typeFilterWrapper?.classList.remove('open');
  });
}

// Bot Mailings launch button handler
function initBotMailingsLaunchButtons() {
  document.querySelectorAll('.bot-launch-btn').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      const row = btn.closest('.bot-mailing-row');
      const statusInfo = row.querySelector('.bot-status-info');
      
      // Update status with current time
      const now = new Date();
      const dateStr = now.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' }) + ' ' + 
                      now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
      
      statusInfo.innerHTML = 
        '<span class="bot-status-label">Последний запуск</span>' +
        '<span class="bot-status-date">' + dateStr + '</span>' +
        '<div class="bot-status-badges">' +
          '<span class="bot-stat-badge bot-stat-blue">0</span>' +
          '<span class="bot-stat-badge bot-stat-green">0</span>' +
          '<span class="bot-stat-badge bot-stat-green">0</span>' +
        '</div>';
      statusInfo.classList.remove('empty');
      
      showToast('success', 'Запущено', 'Рассылка успешно запущена');
    });
  });
}

// Init bot mailings row click for edit
function initBotMailingsRowClick() {
  document.querySelectorAll('.bot-mailing-row').forEach(function(row) {
    row.addEventListener('click', function(e) {
      if (e.target.closest('.bot-launch-btn')) return;
      
      // Open edit modal
      const overlay = document.getElementById('botMailingModalOverlay');
      const modalTitle = document.getElementById('botMailingModalTitle');
      const textInput = document.getElementById('mailingTextInput');
      const deleteBtn = document.getElementById('mailingDelete');
      
      if (overlay) {
        modalTitle.textContent = 'Редактировать рассылку';
        textInput.value = row.querySelector('.bot-td-text')?.textContent || '';
        deleteBtn.style.display = 'flex';
        overlay.classList.add('active');
      }
    });
  });
}

document.addEventListener('DOMContentLoaded', function() {
  initBotMailingsFilters();
  initBotMailingsLaunchButtons();
  initBotMailingsRowClick();
});

// Bot Mailings Filter Functionality
function initBotMailingsFilterFunctionality() {
  const typeFilterWrapper = document.getElementById('typeFilterWrapper');
  const typeFilterBtn = document.getElementById('typeFilterBtn');
  const typeFilterMenu = document.getElementById('typeFilterMenu');
  const rows = document.querySelectorAll('.bot-mailing-row');
  
  if (!typeFilterBtn || !typeFilterMenu) return;
  
  typeFilterMenu.querySelectorAll('.bot-filter-item').forEach(function(item) {
    item.addEventListener('click', function(e) {
      e.stopPropagation();
      const value = item.dataset.value;
      const text = item.textContent;
      
      typeFilterBtn.querySelector('span').textContent = text;
      typeFilterWrapper.classList.remove('open');
      
      // Filter rows
      rows.forEach(function(row) {
        const typeCell = row.querySelector('.bot-td-type');
        if (!typeCell) return;
        
        const rowType = typeCell.textContent.trim();
        
        if (value === 'all') {
          row.style.display = '';
        } else if (value === 'manual' && rowType === 'Ручной запуск') {
          row.style.display = '';
        } else if (value === 'auto' && rowType === 'Автоматический запуск') {
          row.style.display = '';
        } else {
          row.style.display = 'none';
        }
      });
    });
  });
}

document.addEventListener('DOMContentLoaded', function() {
  initBotMailingsFilterFunctionality();
});

// Date Range Picker for Bot Mailings
function initDateRangePicker() {
  const dateInput = document.getElementById('dateRangeInput');
  if (!dateInput) return;
  
  // Create date picker dropdown
  const datePickerHtml = `
    <div class="date-picker-dropdown" id="datePickerDropdown">
      <div class="date-picker-header">
        <span>Выберите период</span>
      </div>
      <div class="date-picker-body">
        <div class="date-picker-row">
          <label class="date-picker-label">От:</label>
          <input type="date" class="date-picker-input" id="dateFromInput">
        </div>
        <div class="date-picker-row">
          <label class="date-picker-label">До:</label>
          <input type="date" class="date-picker-input" id="dateToInput">
        </div>
      </div>
      <div class="date-picker-footer">
        <button class="date-picker-btn" id="datePickerApply">Применить</button>
      </div>
    </div>
  `;
  
  const wrapper = dateInput.closest('.bot-date-range');
  wrapper.style.position = 'relative';
  wrapper.insertAdjacentHTML('beforeend', datePickerHtml);
  
  const dropdown = document.getElementById('datePickerDropdown');
  const fromInput = document.getElementById('dateFromInput');
  const toInput = document.getElementById('dateToInput');
  const applyBtn = document.getElementById('datePickerApply');
  
  // Set default dates
  const today = new Date();
  const weekAgo = new Date(today);
  weekAgo.setDate(weekAgo.getDate() - 7);
  
  fromInput.value = weekAgo.toISOString().split('T')[0];
  toInput.value = today.toISOString().split('T')[0];
  
  // Toggle dropdown
  dateInput.addEventListener('click', function(e) {
    e.stopPropagation();
    dropdown.classList.toggle('open');
  });
  
  // Apply date range
  applyBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    const fromDate = fromInput.value;
    const toDate = toInput.value;
    
    if (fromDate && toDate) {
      dateInput.value = fromDate + ' - ' + toDate;
    }
    dropdown.classList.remove('open');
  });
  
  // Close on outside click
  document.addEventListener('click', function(e) {
    if (!dropdown.contains(e.target) && e.target !== dateInput) {
      dropdown.classList.remove('open');
    }
  });
}

document.addEventListener('DOMContentLoaded', function() {
  initDateRangePicker();
});

// Fix: Connect Add button to modal on bot-mailings page
document.addEventListener('DOMContentLoaded', function() {
  const addBtn = document.querySelector('.bot-mailings-filters .btn-add');
  const overlay = document.getElementById('botMailingModalOverlay');
  const modalTitle = document.getElementById('botMailingModalTitle');
  const deleteBtn = document.getElementById('mailingDelete');
  const textInput = document.getElementById('mailingTextInput');
  
  if (addBtn && overlay) {
    addBtn.addEventListener('click', function() {
      if (modalTitle) modalTitle.textContent = 'Добавить рассылку';
      if (deleteBtn) deleteBtn.style.display = 'none';
      if (textInput) textInput.value = '';
      
      // Reset form
      const buttonsInput = document.getElementById('mailingButtonsInput');
      const fileDisplay = document.getElementById('mailingFileDisplay');
      const fileInput = document.getElementById('mailingFileInput');
      const noClients = document.getElementById('mailingNoClients');
      const onlyBuyers = document.getElementById('mailingOnlyBuyers');
      
      if (buttonsInput) buttonsInput.value = '';
      if (fileDisplay) fileDisplay.querySelector('span').textContent = 'Файл не выбран';
      if (fileInput) fileInput.value = '';
      if (noClients) noClients.checked = false;
      if (onlyBuyers) onlyBuyers.checked = false;
      
      overlay.classList.add('active');
      setTimeout(function() { if (textInput) textInput.focus(); }, 100);
    });
  }
});

// Date Range Button Picker
function initDateRangeButton() {
  const dateBtn = document.getElementById('dateRangeBtn');
  const dateText = document.getElementById('dateRangeText');
  if (!dateBtn) return;
  
  const wrapper = dateBtn.closest('.bot-date-range');
  wrapper.style.position = 'relative';
  
  // Check if dropdown already exists
  let dropdown = document.getElementById('datePickerDropdown');
  if (!dropdown) {
    const datePickerHtml = `
      <div class="date-picker-dropdown" id="datePickerDropdown">
        <div class="date-picker-header">
          <span>Выберите период</span>
        </div>
        <div class="date-picker-body">
          <div class="date-picker-row">
            <label class="date-picker-label">От:</label>
            <input type="date" class="date-picker-input" id="dateFromInput">
          </div>
          <div class="date-picker-row">
            <label class="date-picker-label">До:</label>
            <input type="date" class="date-picker-input" id="dateToInput">
          </div>
        </div>
        <div class="date-picker-footer">
          <button class="date-picker-btn" id="datePickerApply">Применить</button>
        </div>
      </div>
    `;
    wrapper.insertAdjacentHTML('beforeend', datePickerHtml);
    dropdown = document.getElementById('datePickerDropdown');
  }
  
  const fromInput = document.getElementById('dateFromInput');
  const toInput = document.getElementById('dateToInput');
  const applyBtn = document.getElementById('datePickerApply');
  
  // Set default dates
  const today = new Date();
  const weekAgo = new Date(today);
  weekAgo.setDate(weekAgo.getDate() - 7);
  
  if (fromInput) fromInput.value = weekAgo.toISOString().split('T')[0];
  if (toInput) toInput.value = today.toISOString().split('T')[0];
  
  // Toggle dropdown
  dateBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    dropdown.classList.toggle('open');
  });
  
  // Apply date range
  if (applyBtn) {
    applyBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      const fromDate = fromInput.value;
      const toDate = toInput.value;
      
      if (fromDate && toDate && dateText) {
        dateText.textContent = fromDate + ' - ' + toDate;
      }
      dropdown.classList.remove('open');
    });
  }
  
  // Close on outside click
  document.addEventListener('click', function(e) {
    if (dropdown && !dropdown.contains(e.target) && e.target !== dateBtn && !dateBtn.contains(e.target)) {
      dropdown.classList.remove('open');
    }
  });
}

document.addEventListener('DOMContentLoaded', function() {
  initDateRangeButton();
});

// Bot Mailing Modal Complete Functionality
function initBotMailingModalComplete() {
  const overlay = document.getElementById('botMailingModalOverlay');
  const closeBtn = document.getElementById('botMailingModalClose');
  const modalTitle = document.getElementById('botMailingModalTitle');
  const fileBtn = document.getElementById('mailingFileBtn');
  const fileInput = document.getElementById('mailingFileInput');
  const fileDisplay = document.getElementById('mailingFileDisplay');
  const textInput = document.getElementById('mailingTextInput');
  const buttonsInput = document.getElementById('mailingButtonsInput');
  const noClients = document.getElementById('mailingNoClients');
  const onlyBuyers = document.getElementById('mailingOnlyBuyers');
  const saveAndAddBtn = document.getElementById('mailingSaveAndAdd');
  const applyBtn = document.getElementById('mailingApply');
  const saveBtn = document.getElementById('mailingSave');
  const deleteBtn = document.getElementById('mailingDelete');
  const tableBody = document.getElementById('botMailingsBody');
  
  if (!overlay) return;
  
  let editingRow = null;
  let selectedFile = null;
  let mailingCounter = 100;
  
  function closeModal() {
    overlay.classList.add('closing');
    overlay.classList.remove('active');
    setTimeout(function() {
      overlay.classList.remove('closing');
      editingRow = null;
    }, 300);
  }
  
  function resetForm() {
    if (textInput) textInput.value = '';
    if (buttonsInput) buttonsInput.value = '';
    if (fileDisplay) fileDisplay.querySelector('span').textContent = 'Файл не выбран';
    if (fileInput) fileInput.value = '';
    if (noClients) noClients.checked = false;
    if (onlyBuyers) onlyBuyers.checked = false;
    selectedFile = null;
    
    // Reset dropdowns
    document.querySelectorAll('.mailing-dropdown-toggle span').forEach(function(span, idx) {
      if (idx === 0) span.textContent = 'Ручной запуск';
      else if (idx === 1) span.textContent = 'Все города';
      else if (idx === 2) span.textContent = 'Каналы';
      else if (idx === 3) span.textContent = 'Активная';
    });
  }
  
  function createNewRow(text, type, hasAttachment) {
    const row = document.createElement('div');
    row.className = 'bot-mailing-row bot-mailing-card' + (hasAttachment ? '' : ' no-attachment');
    row.dataset.id = mailingCounter++;
    
    const now = new Date();
    const dateStr = now.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' }) + ' ' +
                    now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    
    row.innerHTML = `
      <div class="bot-td bot-td-id">${row.dataset.id}</div>
      <div class="bot-td bot-td-attachment">
        ${hasAttachment ? '<div class="bot-attachment-preview bot-attachment-large"><img src="assets/bot-mailing-preview.png" alt="Attachment" class="bot-attachment-img"></div>' : '<span class="bot-no-attachment">Без вложения</span>'}
      </div>
      <div class="bot-td bot-td-text">${text || 'Новая рассылка'}</div>
      <div class="bot-td bot-td-status">
        <div class="bot-status-info empty">
          <span class="bot-status-label">—</span>
        </div>
      </div>
      <div class="bot-td bot-td-type">${type}</div>
      <div class="bot-td bot-td-action">
        <button class="bot-launch-btn bot-launch-blue" data-testid="button-launch-${row.dataset.id}">Запуск</button>
      </div>
    `;
    
    // Add click handlers
    row.addEventListener('click', function(e) {
      if (e.target.closest('.bot-launch-btn')) return;
      openEditModal(row);
    });
    
    row.querySelector('.bot-launch-btn').addEventListener('click', function(e) {
      e.stopPropagation();
      launchMailing(row);
    });
    
    return row;
  }
  
  function openEditModal(row) {
    editingRow = row;
    if (modalTitle) modalTitle.textContent = 'Редактировать рассылку';
    if (deleteBtn) deleteBtn.style.display = 'flex';
    if (textInput) textInput.value = row.querySelector('.bot-td-text')?.textContent || '';
    overlay.classList.add('active');
  }
  
  function launchMailing(row) {
    const statusInfo = row.querySelector('.bot-status-info');
    const now = new Date();
    const dateStr = now.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' }) + ' ' +
                    now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    
    statusInfo.innerHTML = `
      <span class="bot-status-label">Последний запуск</span>
      <span class="bot-status-date">${dateStr}</span>
      <div class="bot-status-badges">
        <span class="bot-stat-badge bot-stat-gray">0</span>
        <span class="bot-stat-badge bot-stat-green">0</span>
        <span class="bot-stat-badge bot-stat-red">0</span>
      </div>
    `;
    statusInfo.classList.remove('empty');
    showToast('success', 'Успешно', 'Рассылка запущена');
  }
  
  function saveMailing(keepOpen) {
    const text = textInput?.value?.trim() || 'Новая рассылка';
    const typeSpan = document.querySelector('#mailingTypeDropdown span');
    const type = typeSpan?.textContent || 'Ручной запуск';
    const hasAttachment = selectedFile !== null;
    
    if (editingRow) {
      editingRow.querySelector('.bot-td-text').textContent = text;
      editingRow.querySelector('.bot-td-type').textContent = type;
      showToast('success', 'Успешно', 'Рассылка обновлена');
    } else {
      const newRow = createNewRow(text, type, hasAttachment);
      if (tableBody) tableBody.insertBefore(newRow, tableBody.firstChild);
      showToast('success', 'Успешно', 'Рассылка добавлена');
    }
    
    if (keepOpen) {
      resetForm();
      editingRow = null;
    } else {
      closeModal();
    }
  }
  
  function deleteMailing() {
    if (editingRow) {
      editingRow.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
      editingRow.style.opacity = '0';
      editingRow.style.transform = 'translateX(-20px)';
      setTimeout(function() {
        editingRow.remove();
      }, 300);
      showToast('success', 'Удалено', 'Рассылка удалена');
      closeModal();
    }
  }
  
  // Close button
  if (closeBtn) {
    closeBtn.addEventListener('click', closeModal);
  }
  
  // Overlay click
  overlay.addEventListener('click', function(e) {
    if (e.target === overlay) closeModal();
  });
  
  // File upload
  if (fileBtn && fileInput) {
    fileBtn.addEventListener('click', function() {
      fileInput.click();
    });
    
    fileInput.addEventListener('change', function() {
      if (fileInput.files.length > 0) {
        selectedFile = fileInput.files[0];
        if (fileDisplay) fileDisplay.querySelector('span').textContent = selectedFile.name;
      }
    });
  }
  
  // Dropdown handlers
  const dropdowns = [
    { toggle: 'mailingTypeDropdown', menu: 'mailingTypeMenu' },
    { toggle: 'mailingCitiesDropdown', menu: 'mailingCitiesMenu' },
    { toggle: 'mailingChannelsDropdown', menu: 'mailingChannelsMenu' },
    { toggle: 'mailingStatusDropdown', menu: 'mailingStatusMenu' }
  ];
  
  dropdowns.forEach(function(dd) {
    const toggle = document.getElementById(dd.toggle);
    const menu = document.getElementById(dd.menu);
    if (!toggle || !menu) return;
    
    toggle.addEventListener('click', function(e) {
      e.stopPropagation();
      document.querySelectorAll('.mailing-dropdown-wrapper.open').forEach(function(w) {
        if (w !== toggle.closest('.mailing-dropdown-wrapper')) {
          w.classList.remove('open');
        }
      });
      toggle.closest('.mailing-dropdown-wrapper').classList.toggle('open');
    });
    
    menu.querySelectorAll('.mailing-dropdown-item').forEach(function(item) {
      item.addEventListener('click', function(e) {
        e.stopPropagation();
        toggle.querySelector('span').textContent = item.textContent;
        toggle.closest('.mailing-dropdown-wrapper').classList.remove('open');
      });
    });
  });
  
  document.addEventListener('click', function() {
    document.querySelectorAll('.mailing-dropdown-wrapper.open').forEach(function(w) {
      w.classList.remove('open');
    });
  });
  
  // Save buttons
  if (saveAndAddBtn) saveAndAddBtn.addEventListener('click', function() { saveMailing(true); });
  if (applyBtn) applyBtn.addEventListener('click', function() { saveMailing(false); });
  if (saveBtn) saveBtn.addEventListener('click', function() { saveMailing(false); });
  if (deleteBtn) deleteBtn.addEventListener('click', deleteMailing);
  
  // Init existing rows
  document.querySelectorAll('.bot-mailing-row').forEach(function(row) {
    row.addEventListener('click', function(e) {
      if (e.target.closest('.bot-launch-btn')) return;
      openEditModal(row);
    });
    
    const launchBtn = row.querySelector('.bot-launch-btn');
    if (launchBtn) {
      launchBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        launchMailing(row);
      });
    }
  });
}

document.addEventListener('DOMContentLoaded', function() {
  initBotMailingModalComplete();
});

// Add button opens modal
document.addEventListener('DOMContentLoaded', function() {
  const addBtn = document.querySelector('.btn-add');
  const overlay = document.getElementById('botMailingModalOverlay');
  const modalTitle = document.getElementById('botMailingModalTitle');
  const deleteBtn = document.getElementById('mailingDelete');
  
  if (addBtn && overlay) {
    addBtn.addEventListener('click', function() {
      // Reset form for new entry
      const textInput = document.getElementById('mailingTextInput');
      const buttonsInput = document.getElementById('mailingButtonsInput');
      const fileDisplay = document.getElementById('mailingFileDisplay');
      const fileInput = document.getElementById('mailingFileInput');
      const noClients = document.getElementById('mailingNoClients');
      const onlyBuyers = document.getElementById('mailingOnlyBuyers');
      
      if (textInput) textInput.value = '';
      if (buttonsInput) buttonsInput.value = '';
      if (fileDisplay) fileDisplay.querySelector('span').textContent = 'Файл не выбран';
      if (fileInput) fileInput.value = '';
      if (noClients) noClients.checked = false;
      if (onlyBuyers) onlyBuyers.checked = false;
      
      if (modalTitle) modalTitle.textContent = 'Добавить рассылку';
      if (deleteBtn) deleteBtn.style.display = 'none';
      
      overlay.classList.add('active');
    });
  }
});

// ===== DASHBOARD ANIMATIONS =====
function initDashboardAnimations() {
  // Check if we're on the main dashboard page
  const barChart = document.querySelector('.bar-chart');
  const chartValue = document.querySelector('.chart-value[data-target]');
  
  if (!barChart && !chartValue) return;
  
  // Animate elements with data-animate attribute
  animateOnLoad();
  
  // Counter animations for chart values
  animateCounters();
  
  // Bar chart animations and tooltips
  initBarChartAnimations();
  
  // Line graph animations
  initLineGraphAnimations();
  
  // Inventory table value animations
  animateInventoryValues();
}

function animateOnLoad() {
  const elements = document.querySelectorAll('[data-animate]');
  
  elements.forEach(function(el) {
    const delay = parseInt(el.dataset.delay) || 0;
    
    setTimeout(function() {
      el.classList.add('animated');
    }, delay);
  });
}

function animateCounters() {
  const counters = document.querySelectorAll('.chart-value[data-target], .chart-count[data-target], .stat-value[data-target]');
  
  counters.forEach(function(counter, index) {
    const target = parseInt(counter.dataset.target) || 0;
    const suffix = counter.dataset.suffix || '';
    const delay = 300 + (index * 100);
    
    setTimeout(function() {
      animateValue(counter, 0, target, 1500, suffix);
    }, delay);
  });
}

function animateValue(element, start, end, duration, suffix) {
  const startTime = performance.now();
  
  function easeOutExpo(t) {
    return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
  }
  
  function formatWithSpaces(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  }
  
  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const easedProgress = easeOutExpo(progress);
    
    const current = Math.floor(start + (end - start) * easedProgress);
    element.textContent = formatWithSpaces(current) + suffix;
    
    if (progress < 1) {
      requestAnimationFrame(update);
    } else {
      element.textContent = formatWithSpaces(end) + suffix;
    }
  }
  
  requestAnimationFrame(update);
}

function initBarChartAnimations() {
  const bars = document.querySelectorAll('.bar-chart .bar');
  const tooltip = document.getElementById('barTooltip');
  const chartCard = document.querySelector('.chart-card.large');
  
  if (!bars.length || !chartCard) return;
  
  // Animate bars on load
  bars.forEach(function(bar, index) {
    const targetHeight = bar.dataset.height || bar.style.height.replace('px', '');
    bar.style.height = '0px';
    bar.style.transition = 'height 0.8s ease';
    
    setTimeout(function() {
      bar.style.height = targetHeight + 'px';
    }, 200 + (index * 80));
  });
  
  // Tooltip on hover
  if (tooltip) {
    bars.forEach(function(bar) {
      bar.addEventListener('mouseenter', function(e) {
        const purchases = bar.dataset.purchases || 0;
        const returns = bar.dataset.returns || 0;
        const day = bar.dataset.day || '';
        
        tooltip.innerHTML = 
          '<div class="bar-tooltip-label">День ' + day + '</div>' +
          '<div class="bar-tooltip-row"><span>Покупок:</span><span>' + purchases + '</span></div>' +
          '<div class="bar-tooltip-row"><span>Возврата:</span><span>' + returns + '</span></div>';
        
        tooltip.classList.add('visible');
        positionTooltip(e, tooltip, chartCard);
      });
      
      bar.addEventListener('mousemove', function(e) {
        positionTooltip(e, tooltip, chartCard);
      });
      
      bar.addEventListener('mouseleave', function() {
        tooltip.classList.remove('visible');
      });
    });
  }
}

function positionTooltip(e, tooltip, container) {
  const containerRect = container.getBoundingClientRect();
  const tooltipRect = tooltip.getBoundingClientRect();
  const x = e.clientX - containerRect.left;
  const y = e.clientY - containerRect.top;
  
  const tooltipWidth = tooltipRect.width || 120;
  const tooltipHeight = tooltipRect.height || 80;
  
  let left = x + 15;
  let top = y - tooltipHeight - 10;
  
  if (left + tooltipWidth > containerRect.width - 10) {
    left = x - tooltipWidth - 15;
  }
  
  if (top < 10) {
    top = 10;
  }
  
  tooltip.style.left = left + 'px';
  tooltip.style.top = top + 'px';
}

function initLineGraphAnimations() {
  // Deposits graph animation
  const depositsLine = document.getElementById('depositsLine');
  const depositsArea = document.getElementById('depositsGraphArea');
  const depositsTooltip = document.getElementById('depositsTooltip');
  
  if (depositsLine) {
    const targetPoints = depositsLine.dataset.targetPoints;
    animatePolyline(depositsLine, targetPoints, 1000, 700);
    
    // Add hover points and tooltip
    if (depositsArea && depositsTooltip) {
      initDepositsTooltip(depositsArea, depositsTooltip);
    }
  }
  
  // Sales by city graph animation
  const moscowLine = document.getElementById('moscowLine');
  const saratovLine = document.getElementById('saratovLine');
  const salesArea = document.getElementById('salesByCityArea');
  const salesTooltip = document.getElementById('salesByCityTooltip');
  
  if (moscowLine) {
    const targetPoints = moscowLine.dataset.targetPoints;
    animatePolyline(moscowLine, targetPoints, 1000, 800);
  }
  
  if (saratovLine) {
    const targetPoints = saratovLine.dataset.targetPoints;
    animatePolyline(saratovLine, targetPoints, 1000, 900);
  }
  
  if (salesArea && salesTooltip) {
    initSalesByCityTooltip(salesArea, salesTooltip);
  }
}

function animatePolyline(polyline, targetPointsStr, duration, delay) {
  if (!polyline || !targetPointsStr) return;
  
  const startPointsStr = polyline.getAttribute('points');
  const startPoints = parsePoints(startPointsStr);
  const targetPoints = parsePoints(targetPointsStr);
  
  setTimeout(function() {
    const startTime = performance.now();
    
    function easeOutCubic(t) {
      return 1 - Math.pow(1 - t, 3);
    }
    
    function update(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easedProgress = easeOutCubic(progress);
      
      const currentPoints = startPoints.map(function(startPoint, i) {
        const targetPoint = targetPoints[i] || startPoint;
        return {
          x: startPoint.x + (targetPoint.x - startPoint.x) * easedProgress,
          y: startPoint.y + (targetPoint.y - startPoint.y) * easedProgress
        };
      });
      
      const pointsStr = currentPoints.map(function(p) {
        return p.x + ',' + p.y;
      }).join(' ');
      
      polyline.setAttribute('points', pointsStr);
      
      if (progress < 1) {
        requestAnimationFrame(update);
      } else {
        polyline.setAttribute('points', targetPointsStr);
      }
    }
    
    requestAnimationFrame(update);
  }, delay);
}

function parsePoints(pointsStr) {
  return pointsStr.trim().split(/\s+/).map(function(pair) {
    const parts = pair.split(',');
    return { x: parseFloat(parts[0]), y: parseFloat(parts[1]) };
  });
}

function initDepositsTooltip(area, tooltip) {
  // Sample data for deposits by date
  const depositsData = [
    { date: '02.12', btc: 0, card: 1500, promocode: 0, sbp: 2000 },
    { date: '02.12', btc: 500, card: 0, promocode: 3000, sbp: 0 },
    { date: '02.12', btc: 0, card: 2500, promocode: 0, sbp: 1000 },
    { date: '03.12', btc: 1000, card: 0, promocode: 0, sbp: 3500 },
    { date: '03.12', btc: 0, card: 4000, promocode: 2000, sbp: 0 },
    { date: '03.12', btc: 2000, card: 1500, promocode: 0, sbp: 500 },
    { date: '03.12', btc: 0, card: 0, promocode: 5000, sbp: 2500 },
    { date: '03.12', btc: 1500, card: 2000, promocode: 0, sbp: 0 },
    { date: '03.12', btc: 0, card: 3000, promocode: 1000, sbp: 1500 },
    { date: '03.12', btc: 3000, card: 0, promocode: 0, sbp: 4000 }
  ];
  
  // Create hover point element
  const svg = document.getElementById('depositsSvg');
  let hoverPoint = null;
  let hoverLine = null;
  
  if (svg) {
    hoverPoint = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    hoverPoint.setAttribute('r', '6');
    hoverPoint.setAttribute('fill', '#008fcd');
    hoverPoint.setAttribute('stroke', '#fff');
    hoverPoint.setAttribute('stroke-width', '2');
    hoverPoint.classList.add('graph-point');
    svg.appendChild(hoverPoint);
    
    hoverLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    hoverLine.classList.add('graph-hover-line');
    svg.insertBefore(hoverLine, svg.firstChild);
  }
  
  // Get target points for positioning
  const depositsLine = document.getElementById('depositsLine');
  const targetPointsStr = depositsLine ? depositsLine.dataset.targetPoints : '';
  const targetPoints = targetPointsStr ? parsePoints(targetPointsStr) : [];
  
  area.addEventListener('mousemove', function(e) {
    const rect = area.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const width = rect.width;
    const index = Math.min(Math.floor(x / (width / 10)), 9);
    const data = depositsData[index];
    
    if (data) {
      tooltip.innerHTML = 
        '<div class="graph-tooltip-label">' + data.date + '</div>' +
        '<div class="graph-tooltip-row"><span class="graph-tooltip-dot btc"></span><span class="graph-tooltip-text">btc:</span><span class="graph-tooltip-value">' + formatNum(data.btc) + '</span></div>' +
        '<div class="graph-tooltip-row"><span class="graph-tooltip-dot card"></span><span class="graph-tooltip-text">card:</span><span class="graph-tooltip-value">' + formatNum(data.card) + '</span></div>' +
        '<div class="graph-tooltip-row"><span class="graph-tooltip-dot promocode"></span><span class="graph-tooltip-text">promocode:</span><span class="graph-tooltip-value">' + formatNum(data.promocode) + '</span></div>' +
        '<div class="graph-tooltip-row"><span class="graph-tooltip-dot sbp"></span><span class="graph-tooltip-text">sbp:</span><span class="graph-tooltip-value">' + formatNum(data.sbp) + '</span></div>';
      
      tooltip.classList.add('visible');
      
      const tooltipX = Math.min(x + 15, width - 180);
      tooltip.style.left = tooltipX + 'px';
      tooltip.style.top = '50px';
      
      // Show hover point
      if (hoverPoint && targetPoints[index]) {
        hoverPoint.setAttribute('cx', targetPoints[index].x);
        hoverPoint.setAttribute('cy', targetPoints[index].y);
        hoverPoint.classList.add('visible');
      }
      
      // Show hover line
      if (hoverLine && targetPoints[index]) {
        hoverLine.setAttribute('x1', targetPoints[index].x);
        hoverLine.setAttribute('y1', 0);
        hoverLine.setAttribute('x2', targetPoints[index].x);
        hoverLine.setAttribute('y2', 187);
        hoverLine.classList.add('visible');
      }
    }
  });
  
  area.addEventListener('mouseleave', function() {
    tooltip.classList.remove('visible');
    if (hoverPoint) hoverPoint.classList.remove('visible');
    if (hoverLine) hoverLine.classList.remove('visible');
  });
}

function initSalesByCityTooltip(area, tooltip) {
  // Sample data for sales by city
  const salesData = [
    { date: '02.12', moscow: 2500, saratov: 1500 },
    { date: '02.12', moscow: 4500, saratov: 2500 },
    { date: '02.12', moscow: 3500, saratov: 2000 },
    { date: '03.12', moscow: 5500, saratov: 3500 },
    { date: '03.12', moscow: 4000, saratov: 2500 },
    { date: '03.12', moscow: 6500, saratov: 4500 },
    { date: '03.12', moscow: 5000, saratov: 3000 },
    { date: '03.12', moscow: 6000, saratov: 4000 },
    { date: '03.12', moscow: 4500, saratov: 3000 },
    { date: '03.12', moscow: 7000, saratov: 5000 }
  ];
  
  // Create hover point elements
  const svg = document.getElementById('salesByCitySvg');
  let moscowPoint = null;
  let saratovPoint = null;
  let hoverLine = null;
  
  if (svg) {
    hoverLine = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    hoverLine.classList.add('graph-hover-line');
    svg.insertBefore(hoverLine, svg.firstChild);
    
    moscowPoint = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    moscowPoint.setAttribute('r', '6');
    moscowPoint.setAttribute('fill', '#6155f5');
    moscowPoint.setAttribute('stroke', '#fff');
    moscowPoint.setAttribute('stroke-width', '2');
    moscowPoint.classList.add('graph-point');
    svg.appendChild(moscowPoint);
    
    saratovPoint = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    saratovPoint.setAttribute('r', '6');
    saratovPoint.setAttribute('fill', '#ff383c');
    saratovPoint.setAttribute('stroke', '#fff');
    saratovPoint.setAttribute('stroke-width', '2');
    saratovPoint.classList.add('graph-point');
    svg.appendChild(saratovPoint);
  }
  
  // Get target points for positioning
  const moscowLine = document.getElementById('moscowLine');
  const saratovLine = document.getElementById('saratovLine');
  const moscowPointsStr = moscowLine ? moscowLine.dataset.targetPoints : '';
  const saratovPointsStr = saratovLine ? saratovLine.dataset.targetPoints : '';
  const moscowPoints = moscowPointsStr ? parsePoints(moscowPointsStr) : [];
  const saratovPoints = saratovPointsStr ? parsePoints(saratovPointsStr) : [];
  
  area.addEventListener('mousemove', function(e) {
    const rect = area.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const width = rect.width;
    const index = Math.min(Math.floor(x / (width / 10)), 9);
    const data = salesData[index];
    
    if (data) {
      tooltip.innerHTML = 
        '<div class="graph-tooltip-label">' + data.date + '</div>' +
        '<div class="graph-tooltip-row"><span class="graph-tooltip-dot moscow"></span><span class="graph-tooltip-text">Москва:</span><span class="graph-tooltip-value">' + formatNum(data.moscow) + ' ₽</span></div>' +
        '<div class="graph-tooltip-row"><span class="graph-tooltip-dot saratov"></span><span class="graph-tooltip-text">Саратов:</span><span class="graph-tooltip-value">' + formatNum(data.saratov) + ' ₽</span></div>';
      
      tooltip.classList.add('visible');
      
      const tooltipX = Math.min(x + 15, width - 180);
      tooltip.style.left = tooltipX + 'px';
      tooltip.style.top = '50px';
      
      // Show hover points
      if (moscowPoint && moscowPoints[index]) {
        moscowPoint.setAttribute('cx', moscowPoints[index].x);
        moscowPoint.setAttribute('cy', moscowPoints[index].y);
        moscowPoint.classList.add('visible');
      }
      
      if (saratovPoint && saratovPoints[index]) {
        saratovPoint.setAttribute('cx', saratovPoints[index].x);
        saratovPoint.setAttribute('cy', saratovPoints[index].y);
        saratovPoint.classList.add('visible');
      }
      
      // Show hover line
      if (hoverLine && moscowPoints[index]) {
        hoverLine.setAttribute('x1', moscowPoints[index].x);
        hoverLine.setAttribute('y1', 0);
        hoverLine.setAttribute('x2', moscowPoints[index].x);
        hoverLine.setAttribute('y2', 187);
        hoverLine.classList.add('visible');
      }
    }
  });
  
  area.addEventListener('mouseleave', function() {
    tooltip.classList.remove('visible');
    if (moscowPoint) moscowPoint.classList.remove('visible');
    if (saratovPoint) saratovPoint.classList.remove('visible');
    if (hoverLine) hoverLine.classList.remove('visible');
  });
}

function formatNum(num) {
  if (num === 0) return '0';
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function animateInventoryValues() {
  const animatedValues = document.querySelectorAll('.animated-value[data-target]');
  
  animatedValues.forEach(function(el, index) {
    const target = parseInt(el.dataset.target) || 0;
    const suffix = el.dataset.suffix || '';
    const delay = 600 + (index * 50);
    
    setTimeout(function() {
      animateValue(el, 0, target, 1200, suffix);
    }, delay);
  });
}

// ===============================
// DEPOSITS PAGE FUNCTIONALITY
// ===============================

function initDepositsPage() {
  const depositsTable = document.getElementById('deposits-table');
  if (!depositsTable) return;
  
  const searchInput = document.getElementById('depositsSearch');
  const currencyBtn = document.getElementById('currencyFilterBtn');
  const statusBtn = document.getElementById('statusFilterBtn');
  const dateBtn = document.getElementById('dateFilterBtn');
  const currencyMenu = document.getElementById('currencyFilterMenu');
  const statusMenu = document.getElementById('statusFilterMenu');
  const dateMenu = document.getElementById('dateFilterMenu');
  const noResultsMessage = document.getElementById('noResultsMessage');
  
  let currentFilters = {
    search: '',
    currency: 'all',
    status: 'all',
    date: 'all'
  };
  
  // Setup filter dropdowns
  setupFilterDropdown(currencyBtn, currencyMenu, 'currencyFilterText', function(value) {
    currentFilters.currency = value;
    filterDeposits();
  });
  
  setupFilterDropdown(statusBtn, statusMenu, 'statusFilterText', function(value) {
    currentFilters.status = value;
    filterDeposits();
  });
  
  setupFilterDropdown(dateBtn, dateMenu, 'dateFilterText', function(value) {
    currentFilters.date = value;
    filterDeposits();
  });
  
  // Search input listener
  if (searchInput) {
    searchInput.addEventListener('input', function() {
      currentFilters.search = this.value.toLowerCase().trim();
      filterDeposits();
    });
  }
  
  function setupFilterDropdown(btn, menu, textId, onSelect) {
    if (!btn || !menu) return;
    
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      
      // Close other dropdowns
      document.querySelectorAll('.filter-dropdown-menu.show').forEach(function(m) {
        if (m !== menu) m.classList.remove('show');
      });
      
      menu.classList.toggle('show');
    });
    
    menu.querySelectorAll('.filter-dropdown-item').forEach(function(item) {
      item.addEventListener('click', function() {
        const value = this.dataset.value;
        const text = this.textContent;
        
        // Update active state
        menu.querySelectorAll('.filter-dropdown-item').forEach(function(i) {
          i.classList.remove('active');
        });
        this.classList.add('active');
        
        // Update button text
        const textEl = document.getElementById(textId);
        if (textEl) {
          if (value === 'all') {
            if (textId === 'currencyFilterText') textEl.textContent = 'Валюта';
            else if (textId === 'statusFilterText') textEl.textContent = 'Статус';
            else if (textId === 'dateFilterText') textEl.textContent = 'Все даты';
          } else {
            textEl.textContent = text;
          }
        }
        
        menu.classList.remove('show');
        onSelect(value);
      });
    });
  }
  
  // Close dropdowns when clicking outside
  document.addEventListener('click', function() {
    document.querySelectorAll('.filter-dropdown-menu.show').forEach(function(m) {
      m.classList.remove('show');
    });
  });
  
  function filterDeposits() {
    const rows = depositsTable.querySelectorAll('.deposit-row');
    let visibleCount = 0;
    let completedCount = 0;
    let totalAmount = 0;
    
    rows.forEach(function(row) {
      const id = row.dataset.id || '';
      const status = row.dataset.status || '';
      const currency = row.dataset.currency || '';
      const amount = parseFloat(row.dataset.amount) || 0;
      const date = row.dataset.date || '';
      const clientName = row.querySelector('.client-name')?.textContent?.toLowerCase() || '';
      
      let visible = true;
      
      // Search filter
      if (currentFilters.search) {
        const searchMatch = id.includes(currentFilters.search) || 
                           clientName.includes(currentFilters.search);
        if (!searchMatch) visible = false;
      }
      
      // Currency filter
      if (currentFilters.currency !== 'all' && currency !== currentFilters.currency) {
        visible = false;
      }
      
      // Status filter
      if (currentFilters.status !== 'all' && status !== currentFilters.status) {
        visible = false;
      }
      
      // Date filter
      if (currentFilters.date !== 'all') {
        const rowDate = new Date(date);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        if (currentFilters.date === 'today') {
          const todayStr = today.toISOString().split('T')[0];
          if (date !== todayStr) visible = false;
        } else if (currentFilters.date === 'yesterday') {
          const yesterday = new Date(today);
          yesterday.setDate(yesterday.getDate() - 1);
          const yesterdayStr = yesterday.toISOString().split('T')[0];
          if (date !== yesterdayStr) visible = false;
        } else if (currentFilters.date === 'week') {
          const weekAgo = new Date(today);
          weekAgo.setDate(weekAgo.getDate() - 7);
          if (rowDate < weekAgo) visible = false;
        } else if (currentFilters.date === 'month') {
          const monthAgo = new Date(today);
          monthAgo.setMonth(monthAgo.getMonth() - 1);
          if (rowDate < monthAgo) visible = false;
        }
      }
      
      if (visible) {
        row.style.display = '';
        row.style.animation = 'none';
        row.offsetHeight; // Trigger reflow
        row.style.animation = '';
        visibleCount++;
        
        if (status === 'completed') {
          completedCount++;
          totalAmount += amount;
        }
      } else {
        row.style.display = 'none';
      }
    });
    
    // Update stats
    updateDepositsStats(visibleCount, completedCount, totalAmount);
    
    // Show/hide no results message
    if (noResultsMessage) {
      noResultsMessage.style.display = visibleCount === 0 ? 'block' : 'none';
    }
  }
  
  function updateDepositsStats(total, completed, amount) {
    const totalEl = document.getElementById('totalDeposits');
    const completedEl = document.getElementById('completedDeposits');
    const amountEl = document.getElementById('totalAmount');
    
    if (totalEl) totalEl.textContent = total;
    if (completedEl) completedEl.textContent = completed;
    if (amountEl) amountEl.textContent = formatAmount(amount) + ' ₽';
  }
  
  function formatAmount(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  }
  
  // Initial stats update
  const rows = depositsTable.querySelectorAll('.deposit-row');
  let initialCompleted = 0;
  let initialAmount = 0;
  
  rows.forEach(function(row) {
    if (row.dataset.status === 'completed') {
      initialCompleted++;
      initialAmount += parseFloat(row.dataset.amount) || 0;
    }
  });
  
  updateDepositsStats(rows.length, initialCompleted, initialAmount);
}

// ===============================
// PURCHASES STOCK PAGE FUNCTIONALITY
// ===============================

function initPurchasesStockPage() {
  const stockTable = document.getElementById('stockTable');
  if (!stockTable) return;
  
  const cityBtn = document.getElementById('cityFilterBtn');
  const dateBtn = document.getElementById('dateFilterBtn');
  const cityMenu = document.getElementById('cityFilterMenu');
  const dateMenu = document.getElementById('dateFilterMenu');
  const exportBtn = document.getElementById('exportBtn');
  const noResultsMessage = document.getElementById('noStockResults');
  
  let currentFilters = {
    city: 'all',
    date: 'all'
  };
  
  // Setup filter dropdowns
  setupStockFilterDropdown(cityBtn, cityMenu, 'cityFilterText', function(value) {
    currentFilters.city = value;
    filterStock();
  });
  
  setupStockFilterDropdown(dateBtn, dateMenu, 'dateFilterText', function(value) {
    currentFilters.date = value;
    filterStock();
  });
  
  function setupStockFilterDropdown(btn, menu, textId, onSelect) {
    if (!btn || !menu) return;
    
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      
      // Close other dropdowns
      document.querySelectorAll('.filter-dropdown-menu.show').forEach(function(m) {
        if (m !== menu) m.classList.remove('show');
      });
      
      menu.classList.toggle('show');
    });
    
    menu.querySelectorAll('.filter-dropdown-item').forEach(function(item) {
      item.addEventListener('click', function() {
        const value = this.dataset.value;
        const text = this.textContent;
        
        // Update active state
        menu.querySelectorAll('.filter-dropdown-item').forEach(function(i) {
          i.classList.remove('active');
        });
        this.classList.add('active');
        
        // Update button text
        const textEl = document.getElementById(textId);
        if (textEl) {
          if (value === 'all') {
            if (textId === 'cityFilterText') textEl.textContent = 'Город';
            else if (textId === 'dateFilterText') textEl.textContent = 'Все даты';
          } else {
            textEl.textContent = text;
          }
        }
        
        menu.classList.remove('show');
        onSelect(value);
      });
    });
  }
  
  // Close dropdowns when clicking outside
  document.addEventListener('click', function() {
    document.querySelectorAll('.filter-dropdown-menu.show').forEach(function(m) {
      m.classList.remove('show');
    });
  });
  
  function filterStock() {
    const citySections = stockTable.querySelectorAll('.city-section');
    let visibleSections = 0;
    let totalStockCount = 0;
    let totalStockWeight = 0;
    let totalStockValue = 0;
    let totalSoldCount = 0;
    let totalSoldValue = 0;
    
    citySections.forEach(function(section) {
      const city = section.dataset.city;
      let sectionVisible = true;
      
      // City filter
      if (currentFilters.city !== 'all' && city !== currentFilters.city) {
        sectionVisible = false;
      }
      
      if (sectionVisible) {
        // Filter products by date if needed
        const products = section.querySelectorAll('.product-row');
        let visibleProducts = 0;
        let cityStockCount = 0;
        let cityStockWeight = 0;
        let cityStockValue = 0;
        let citySoldCount = 0;
        let citySoldValue = 0;
        
        products.forEach(function(product) {
          const productDate = product.dataset.date;
          let productVisible = true;
          
          // Date filter
          if (currentFilters.date !== 'all') {
            const rowDate = new Date(productDate);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            
            if (currentFilters.date === 'today') {
              const todayStr = today.toISOString().split('T')[0];
              if (productDate !== todayStr) productVisible = false;
            } else if (currentFilters.date === 'yesterday') {
              const yesterday = new Date(today);
              yesterday.setDate(yesterday.getDate() - 1);
              const yesterdayStr = yesterday.toISOString().split('T')[0];
              if (productDate !== yesterdayStr) productVisible = false;
            } else if (currentFilters.date === 'week') {
              const weekAgo = new Date(today);
              weekAgo.setDate(weekAgo.getDate() - 7);
              if (rowDate < weekAgo) productVisible = false;
            } else if (currentFilters.date === 'month') {
              const monthAgo = new Date(today);
              monthAgo.setMonth(monthAgo.getMonth() - 1);
              if (rowDate < monthAgo) productVisible = false;
            }
          }
          
          if (productVisible) {
            product.style.display = '';
            visibleProducts++;
            cityStockCount += parseInt(product.dataset.stock) || 0;
            cityStockWeight += parseFloat(product.dataset.weight) || 0;
            cityStockValue += (parseInt(product.dataset.stock) || 0) * (parseInt(product.dataset.price) || 0);
            citySoldCount += parseInt(product.dataset.sold) || 0;
            citySoldValue += parseInt(product.dataset.soldAmount) || 0;
          } else {
            product.style.display = 'none';
          }
        });
        
        if (visibleProducts > 0) {
          section.style.display = '';
          visibleSections++;
          totalStockCount += cityStockCount;
          totalStockWeight += cityStockWeight;
          totalStockValue += cityStockValue;
          totalSoldCount += citySoldCount;
          totalSoldValue += citySoldValue;
          
          // Update city stats
          const stockCountEl = section.querySelector('.city-stock-count');
          const stockWeightEl = section.querySelector('.city-stock-weight');
          const stockValueEl = section.querySelector('.city-stock-value');
          const soldCountEl = section.querySelector('.city-sold-count');
          const soldValueEl = section.querySelector('.city-sold-value');
          
          if (stockCountEl) stockCountEl.textContent = cityStockCount;
          if (stockWeightEl) stockWeightEl.textContent = cityStockWeight.toFixed(1);
          if (stockValueEl) stockValueEl.textContent = formatStockAmount(cityStockValue);
          if (soldCountEl) soldCountEl.textContent = citySoldCount;
          if (soldValueEl) soldValueEl.textContent = formatStockAmount(citySoldValue);
        } else {
          section.style.display = 'none';
        }
      } else {
        section.style.display = 'none';
      }
    });
    
    // Update totals
    updateStockSummary(totalStockCount, totalStockWeight, totalStockValue, totalSoldCount, totalSoldValue);
    
    // Show/hide no results message
    if (noResultsMessage) {
      noResultsMessage.style.display = visibleSections === 0 ? 'block' : 'none';
    }
  }
  
  function updateStockSummary(stockCount, stockWeight, stockValue, soldCount, soldValue) {
    const stockSummaryEl = document.getElementById('stockSummary');
    const salesSummaryEl = document.getElementById('salesSummary');
    
    if (stockSummaryEl) {
      stockSummaryEl.textContent = 'Всего в остатках: ' + stockCount + ' шт. (' + stockWeight.toFixed(1) + ' г.) на ' + formatStockAmount(stockValue) + ' ₽';
    }
    
    if (salesSummaryEl) {
      salesSummaryEl.textContent = 'Всего покупок: ' + soldCount + ' на ' + formatStockAmount(soldValue) + ' ₽';
    }
  }
  
  function formatStockAmount(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  }
  
  // Export to XLSX
  if (exportBtn) {
    exportBtn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      exportToXLSX();
      return false;
    });
  }
  
  function exportToXLSX() {
    if (typeof XLSX === 'undefined') {
      alert('XLSX library not loaded');
      return;
    }
    
    const data = [];
    
    // Header row
    data.push(['Город', 'Товар', 'Цена', 'Остатки (шт)', 'Остатки (г)', 'Продано (шт)', 'Сумма продаж']);
    
    // Collect visible data
    const citySections = stockTable.querySelectorAll('.city-section');
    citySections.forEach(function(section) {
      if (section.style.display === 'none') return;
      
      const cityTitle = section.querySelector('.city-title');
      const cityName = cityTitle ? cityTitle.textContent : 'Неизвестно';
      
      const products = section.querySelectorAll('.product-row');
      products.forEach(function(product) {
        if (product.style.display === 'none') return;
        
        const name = product.dataset.name || '';
        const price = parseInt(product.dataset.price) || 0;
        const stock = parseInt(product.dataset.stock) || 0;
        const weight = parseFloat(product.dataset.weight) || 0;
        const sold = parseInt(product.dataset.sold) || 0;
        const soldAmount = parseInt(product.dataset.soldAmount) || 0;
        
        data.push([cityName, name, price, stock, weight, sold, soldAmount]);
      });
    });
    
    // Create workbook and worksheet
    const ws = XLSX.utils.aoa_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Покупки и остатки');
    
    // Set column widths
    ws['!cols'] = [
      { wch: 20 },  // Город
      { wch: 30 },  // Товар
      { wch: 12 },  // Цена
      { wch: 15 },  // Остатки (шт)
      { wch: 15 },  // Остатки (г)
      { wch: 15 },  // Продано (шт)
      { wch: 15 }   // Сумма продаж
    ];
    
    // Generate file and download
    const today = new Date();
    const dateStr = today.toISOString().split('T')[0];
    XLSX.writeFile(wb, 'purchases_stock_' + dateStr + '.xlsx');
  }
  
  // Calculate initial summary
  calculateInitialSummary();
  
  function calculateInitialSummary() {
    let totalStockCount = 0;
    let totalStockWeight = 0;
    let totalStockValue = 0;
    let totalSoldCount = 0;
    let totalSoldValue = 0;
    
    const products = stockTable.querySelectorAll('.product-row');
    products.forEach(function(product) {
      totalStockCount += parseInt(product.dataset.stock) || 0;
      totalStockWeight += parseFloat(product.dataset.weight) || 0;
      totalStockValue += (parseInt(product.dataset.stock) || 0) * (parseInt(product.dataset.price) || 0);
      totalSoldCount += parseInt(product.dataset.sold) || 0;
      totalSoldValue += parseInt(product.dataset.soldAmount) || 0;
    });
    
    updateStockSummary(totalStockCount, totalStockWeight, totalStockValue, totalSoldCount, totalSoldValue);
  }
  
}

// ===============================
// DEPOSITS DYNAMICS PAGE FUNCTIONALITY
// ===============================

function initDepositsDynamicsPage() {
  const chartContainer = document.getElementById('dynamicsChartContainer');
  if (!chartContainer) return;
  
  const showBtn = document.getElementById('showChartBtn');
  const chartArea = document.getElementById('dynamicsChartArea');
  const tooltip = document.getElementById('dynamicsTooltip');
  const hoverLine = document.getElementById('dynamicsHoverLine');
  const cyanPoint = document.getElementById('cyanPoint');
  const purplePoint = document.getElementById('purplePoint');
  const lineCyan = document.getElementById('lineCyan');
  const linePurple = document.getElementById('linePurple');
  
  let chartVisible = true;
  
  // Sample data for the chart (hourly deposits for two dates)
  const chartData = {
    date1: '20.12.2025',
    date2: '21.12.2025',
    hourly: [
      { hour: 0, deposits1: 0, total1: 0, deposits2: 0, total2: 0 },
      { hour: 1, deposits1: 2, total1: 1500, deposits2: 1, total2: 800 },
      { hour: 2, deposits1: 1, total1: 2200, deposits2: 0, total2: 800 },
      { hour: 3, deposits1: 3, total1: 4500, deposits2: 2, total2: 2100 },
      { hour: 4, deposits1: 1, total1: 5200, deposits2: 1, total2: 2800 },
      { hour: 5, deposits1: 0, total1: 5200, deposits2: 0, total2: 2800 },
      { hour: 6, deposits1: 2, total1: 6800, deposits2: 3, total2: 4500 },
      { hour: 7, deposits1: 4, total1: 9200, deposits2: 2, total2: 6100 },
      { hour: 8, deposits1: 5, total1: 13500, deposits2: 4, total2: 9400 },
      { hour: 9, deposits1: 8, total1: 20000, deposits2: 5, total2: 13200 },
      { hour: 10, deposits1: 12, total1: 32500, deposits2: 8, total2: 19800 },
      { hour: 11, deposits1: 10, total1: 42000, deposits2: 6, total2: 25200 },
      { hour: 12, deposits1: 15, total1: 58000, deposits2: 10, total2: 34500 },
      { hour: 13, deposits1: 18, total1: 78000, deposits2: 12, total2: 45800 },
      { hour: 14, deposits1: 22, total1: 102000, deposits2: 15, total2: 60500 },
      { hour: 15, deposits1: 20, total1: 125000, deposits2: 18, total2: 78000 },
      { hour: 16, deposits1: 18, total1: 145000, deposits2: 14, total2: 92500 },
      { hour: 17, deposits1: 16, total1: 163000, deposits2: 12, total2: 105000 },
      { hour: 18, deposits1: 14, total1: 178000, deposits2: 10, total2: 115000 },
      { hour: 19, deposits1: 12, total1: 192000, deposits2: 8, total2: 123000 },
      { hour: 20, deposits1: 10, total1: 204000, deposits2: 6, total2: 129000 },
      { hour: 21, deposits1: 8, total1: 213000, deposits2: 5, total2: 134000 },
      { hour: 22, deposits1: 6, total1: 220000, deposits2: 4, total2: 138000 },
      { hour: 23, deposits1: 4, total1: 225000, deposits2: 3, total2: 141000 }
    ]
  };
  
  // Parse path data to get Y values at each X position
  function getPathYAtX(pathD, xRatio) {
    const parts = pathD.replace(/[MLZ]/g, '').trim().split(/\s+L\s*|\s+/);
    const points = [];
    for (let i = 0; i < parts.length; i += 2) {
      if (parts[i] && parts[i+1]) {
        points.push({ x: parseFloat(parts[i]), y: parseFloat(parts[i+1]) });
      }
    }
    
    const xPos = xRatio * 1000;
    for (let i = 0; i < points.length - 1; i++) {
      if (xPos >= points[i].x && xPos <= points[i+1].x) {
        const t = (xPos - points[i].x) / (points[i+1].x - points[i].x);
        return points[i].y + t * (points[i+1].y - points[i].y);
      }
    }
    return points[points.length - 1].y;
  }
  
  // Show/hide chart button functionality
  if (showBtn) {
    showBtn.addEventListener('click', function() {
      chartVisible = !chartVisible;
      
      if (chartVisible) {
        chartContainer.style.display = 'block';
        showBtn.classList.remove('hidden');
        showBtn.querySelector('span:first-child').textContent = 'Показать';
        
        // Re-animate lines
        lineCyan.style.animation = 'none';
        linePurple.style.animation = 'none';
        void lineCyan.offsetWidth;
        lineCyan.style.animation = 'drawLine 2s ease forwards';
        linePurple.style.animation = 'drawLine 2s ease 0.3s forwards';
      } else {
        chartContainer.style.display = 'none';
        showBtn.classList.add('hidden');
        showBtn.querySelector('span:first-child').textContent = 'Скрыть';
      }
    });
  }
  
  // Chart hover interaction
  if (chartArea) {
    chartArea.addEventListener('mousemove', function(e) {
      const rect = chartArea.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const width = rect.width;
      const xRatio = x / width;
      const hourIndex = Math.min(23, Math.max(0, Math.round(xRatio * 23)));
      
      // Get Y positions for hover points
      const cyanPath = lineCyan.getAttribute('d');
      const purplePath = linePurple.getAttribute('d');
      const cyanY = getPathYAtX(cyanPath, xRatio);
      const purpleY = getPathYAtX(purplePath, xRatio);
      
      // Update hover line position
      const lineX = xRatio * 1000;
      hoverLine.setAttribute('x1', lineX);
      hoverLine.setAttribute('x2', lineX);
      hoverLine.classList.add('visible');
      
      // Update point positions
      cyanPoint.setAttribute('cx', lineX);
      cyanPoint.setAttribute('cy', cyanY);
      cyanPoint.classList.add('visible');
      
      purplePoint.setAttribute('cx', lineX);
      purplePoint.setAttribute('cy', purpleY);
      purplePoint.classList.add('visible');
      
      // Get data for this hour
      const hourData = chartData.hourly[hourIndex];
      
      // Update tooltip content
      tooltip.innerHTML = 
        '<div class="chart-tooltip-date">' + chartData.date1 + '</div>' +
        '<div class="chart-tooltip-row">' +
          '<span class="chart-tooltip-dot cyan"></span>' +
          '<span class="chart-tooltip-label">За час</span>' +
          '<span class="chart-tooltip-value">' + hourData.deposits1 + ' пополнений</span>' +
        '</div>' +
        '<div class="chart-tooltip-row">' +
          '<span class="chart-tooltip-dot cyan"></span>' +
          '<span class="chart-tooltip-label">С начала суток</span>' +
          '<span class="chart-tooltip-value">' + formatDynamicsAmount(hourData.total1) + ' р.</span>' +
        '</div>' +
        '<div style="height: 12px;"></div>' +
        '<div class="chart-tooltip-date">' + chartData.date2 + '</div>' +
        '<div class="chart-tooltip-row">' +
          '<span class="chart-tooltip-dot purple"></span>' +
          '<span class="chart-tooltip-label">За час</span>' +
          '<span class="chart-tooltip-value">' + hourData.deposits2 + ' пополнений</span>' +
        '</div>' +
        '<div class="chart-tooltip-row">' +
          '<span class="chart-tooltip-dot purple"></span>' +
          '<span class="chart-tooltip-label">С начала суток</span>' +
          '<span class="chart-tooltip-value">' + formatDynamicsAmount(hourData.total2) + ' р.</span>' +
        '</div>';
      
      // Position tooltip
      const tooltipWidth = 200;
      let tooltipX = x + 15;
      if (tooltipX + tooltipWidth > width) {
        tooltipX = x - tooltipWidth - 15;
      }
      tooltip.style.left = tooltipX + 'px';
      tooltip.style.top = '20px';
      tooltip.classList.add('visible');
    });
    
    chartArea.addEventListener('mouseleave', function() {
      hoverLine.classList.remove('visible');
      cyanPoint.classList.remove('visible');
      purplePoint.classList.remove('visible');
      tooltip.classList.remove('visible');
    });
  }
  
  function formatDynamicsAmount(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  }
}

// ===============================
// DYNAMIC DATES FUNCTIONALITY
// ===============================

function updateDynamicDates() {
  const today = new Date();
  const todayStr = formatDateISO(today);
  
  // Calculate date ranges
  const weekAgo = new Date(today);
  weekAgo.setDate(weekAgo.getDate() - 7);
  const weekAgoStr = formatDateISO(weekAgo);
  
  const monthAgo = new Date(today);
  monthAgo.setMonth(monthAgo.getMonth() - 1);
  const monthAgoStr = formatDateISO(monthAgo);
  
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = formatDateISO(yesterday);
  
  // Update dateFilterText
  const dateFilterText = document.getElementById('dateFilterText');
  if (dateFilterText) {
    const currentText = dateFilterText.textContent;
    if (currentText.includes('2025-12-09') || currentText.includes('2025-12-15')) {
      dateFilterText.textContent = weekAgoStr + ' - ' + todayStr;
    }
  }
  
  // Update date filter dropdown items
  const dateFilterMenu = document.getElementById('dateFilterMenu');
  if (dateFilterMenu) {
    dateFilterMenu.querySelectorAll('.filter-dropdown-item').forEach(function(item) {
      const value = item.dataset.value;
      if (value === 'week') {
        item.dataset.label = weekAgoStr + ' - ' + todayStr;
      } else if (value === 'today') {
        item.dataset.label = todayStr;
      } else if (value === 'yesterday') {
        item.dataset.label = yesterdayStr;
      } else if (value === 'month') {
        item.dataset.label = monthAgoStr + ' - ' + todayStr;
      }
    });
  }
  
  // Update notification timestamps
  const notificationTimes = document.querySelectorAll('.notification-item-time');
  notificationTimes.forEach(function(el, index) {
    const hoursAgo = (index + 1) * 2;
    const notifDate = new Date(today);
    notifDate.setHours(notifDate.getHours() - hoursAgo);
    el.textContent = formatDateTimeRu(notifDate);
  });
  
  // Update date pickers with dots (old style)
  const datePickers = document.querySelectorAll('.date-picker span:not(.dot)');
  datePickers.forEach(function(el) {
    const text = el.textContent;
    if (text.match(/\d{4}-\d{2}-\d{2}/)) {
      el.textContent = todayStr;
    }
  });
  
  function formatDateISO(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return year + '-' + month + '-' + day;
  }
  
  function formatDateTimeRu(date) {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return day + '.' + month + '.' + year + ' ' + hours + ':' + minutes + ':' + seconds;
  }
}

// ===============================
// MINI LINE CHARTS
// ===============================

function initMiniLineCharts() {
  const charts = document.querySelectorAll('.mini-line-chart');
  if (!charts.length) return;
  
  let tooltip = document.getElementById('miniChartTooltip');
  if (!tooltip) {
    tooltip = document.createElement('div');
    tooltip.id = 'miniChartTooltip';
    tooltip.className = 'mini-chart-tooltip';
    document.body.appendChild(tooltip);
  }
  
  charts.forEach(function(chart) {
    const pointsStr = chart.dataset.points;
    const valuesStr = chart.dataset.values;
    const labelsStr = chart.dataset.labels;
    
    if (!pointsStr || !valuesStr) return;
    
    const points = pointsStr.split(' ').map(function(p) {
      const coords = p.split(',');
      return { x: parseFloat(coords[0]), y: parseFloat(coords[1]) };
    });
    
    const values = valuesStr.split(',').map(function(v) { return parseInt(v, 10); });
    const labels = labelsStr ? labelsStr.split(',') : [];
    
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 94 19');
    
    const polyline = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
    polyline.setAttribute('fill', 'none');
    polyline.setAttribute('stroke', '#008FCD');
    polyline.setAttribute('stroke-width', '2');
    polyline.setAttribute('stroke-linecap', 'round');
    polyline.setAttribute('stroke-linejoin', 'round');
    polyline.setAttribute('points', pointsStr);
    svg.appendChild(polyline);
    
    points.forEach(function(point, index) {
      const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      circle.setAttribute('cx', point.x);
      circle.setAttribute('cy', point.y);
      circle.setAttribute('r', '4');
      circle.setAttribute('class', 'chart-point');
      circle.setAttribute('data-index', index);
      svg.appendChild(circle);
      
      circle.addEventListener('mouseenter', function(e) {
        const value = values[index] || 0;
        const label = labels[index] || 'Точка ' + (index + 1);
        
        tooltip.innerHTML = 
          '<div class="mini-chart-tooltip-label">' + label + '</div>' +
          '<div class="mini-chart-tooltip-value">' + formatMiniChartValue(value) + ' ₽</div>';
        tooltip.classList.add('visible');
        
        circle.classList.add('visible');
      });
      
      circle.addEventListener('mousemove', function(e) {
        tooltip.style.left = (e.clientX + 10) + 'px';
        tooltip.style.top = (e.clientY - 40) + 'px';
      });
      
      circle.addEventListener('mouseleave', function() {
        tooltip.classList.remove('visible');
        circle.classList.remove('visible');
      });
    });
    
    chart.appendChild(svg);
  });
  
  function formatMiniChartValue(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  }
}
