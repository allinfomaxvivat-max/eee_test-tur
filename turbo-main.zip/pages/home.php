<div class="container">
    <h1 class="page-title home-page-title">Главная страница</h1>

    <div class="dashboard-top">
        <div class="chart-card large" data-animate="fade-up">
            <p class="chart-label">Продажи за последние 30 дней</p>
            <div class="chart-value-row">
                <span class="chart-value" data-target="25342" data-suffix=" ₽">0 ₽</span>
                <span class="chart-count" data-target="4" data-suffix=" шт.">0 шт.</span>
            </div>
            <div class="bar-chart">
                <div class="bar" data-height="58" data-purchases="3" data-returns="0" data-day="1"></div>
                <div class="bar" data-height="142" data-purchases="8" data-returns="1" data-day="2"></div>
                <div class="bar" data-height="98" data-purchases="5" data-returns="0" data-day="3"></div>
                <div class="bar" data-height="112" data-purchases="6" data-returns="2" data-day="4"></div>
                <div class="bar" data-height="90" data-purchases="4" data-returns="0" data-day="5"></div>
                <div class="bar" data-height="161" data-purchases="10" data-returns="1" data-day="6"></div>
                <div class="bar" data-height="78" data-purchases="4" data-returns="0" data-day="7"></div>
                <div class="bar" data-height="142" data-purchases="7" data-returns="1" data-day="8"></div>
                <div class="bar" data-height="39" data-purchases="2" data-returns="0" data-day="9"></div>
                <div class="bar" data-height="112" data-purchases="5" data-returns="1" data-day="10"></div>
            </div>
            <div class="bar-labels">
                <span>1</span><span>2</span><span>3</span><span>4</span><span>5</span>
                <span>6</span><span>7</span><span>8</span><span>9</span><span>10</span>
            </div>
            <div class="bar-tooltip" id="barTooltip"></div>
        </div>

        <div class="stats-cards">
            <div class="stat-card wide" data-animate="fade-up" data-delay="100">
                <div class="stat-card-header">
                    <span class="stat-card-title">Продажи за сегодня</span>
                    <div class="mini-line-chart" id="chartToday" data-points="2,15 15,10 28,12 41,6 54,9 67,4 80,8 92,3"
                        data-values="1200,1800,1500,2200,1900,2500,2100,2800"
                        data-labels="00:00,03:00,06:00,09:00,12:00,15:00,18:00,21:00"></div>
                </div>
                <p class="stat-card-detail">
                    <span class="stat-value" data-target="5" data-suffix=" пополнений">0 пополнений</span>
                    /
                    <span class="stat-value" data-target="12500" data-suffix=" ₽">0 ₽</span>
                    /
                    <span class="stat-value" data-target="3" data-suffix=" продаж">0 продаж</span>
                    /
                    <span class="stat-value" data-target="8750" data-suffix=" ₽">0 ₽</span>
                </p>
            </div>

            <div class="stats-cards-row">
                <div class="stat-card" data-animate="fade-up" data-delay="200">
                    <div class="mini-line-chart" id="chartYesterday" style="margin-bottom: auto"
                        data-points="2,12 15,8 28,14 41,5 54,11 67,7 80,10 92,4"
                        data-values="2400,3200,2100,3800,2800,3500,3100,4200"
                        data-labels="00:00,03:00,06:00,09:00,12:00,15:00,18:00,21:00"></div>
                    <div class="stat-card-content">
                        <span class="stat-card-title">Продажи за вчера</span>
                        <p class="stat-card-detail-multi">
                            <span class="stat-value" data-target="8" data-suffix=" пополнений">0 пополнений</span>
                            /
                            <span class="stat-value" data-target="24000" data-suffix=" ₽">0 ₽</span><br />/
                            <span class="stat-value" data-target="6" data-suffix=" продаж">0 продаж</span>
                            /
                            <span class="stat-value" data-target="18500" data-suffix=" ₽">0 ₽</span>
                        </p>
                    </div>
                </div>
                <div class="stat-card" data-animate="fade-up" data-delay="300">
                    <div class="mini-line-chart" id="chartWeek" style="margin-bottom: auto"
                        data-points="2,16 15,11 28,8 41,13 54,6 67,9 80,5 92,2"
                        data-values="18500,22000,25000,21000,28000,24000,30000,35000"
                        data-labels="Пн,Вт,Ср,Чт,Пт,Сб,Вс,Сегодня"></div>
                    <div class="stat-card-content">
                        <span class="stat-card-title">Продажи 7 дней</span>
                        <p class="stat-card-detail-multi">
                            <span class="stat-value" data-target="42" data-suffix=" пополнений">0 пополнений</span>
                            /
                            <span class="stat-value" data-target="156000" data-suffix=" ₽">0 ₽</span><br />/
                            <span class="stat-value" data-target="31" data-suffix=" продаж">0 продаж</span>
                            /
                            <span class="stat-value" data-target="98500" data-suffix=" ₽">0 ₽</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="inventory-table" data-animate="fade-up" data-delay="400">
        <h2 class="table-title">Остатки по городам</h2>

        <div class="city-section" data-animate="slide-in" data-delay="500">
            <span class="city-name">Москва</span>
            <div class="inventory-row">
                <span class="product-name">Альфа 1 грамм</span>
                <span class="product-price animated-value" data-target="5434" data-suffix=".00 ₽">0.00 ₽</span>
                <span class="product-weight">1 грамм</span>
                <span class="product-count animated-value" data-target="2" data-suffix=" штуки">0 штуки</span>
                <span class="product-total animated-value" data-target="5434" data-suffix=".00 ₽">0.00 ₽</span>
            </div>
        </div>

        <div class="city-section" data-animate="slide-in" data-delay="600">
            <span class="city-name">Саратов</span>
            <div class="inventory-row">
                <span class="product-name">Hash Amezia 3 грамма</span>
                <span class="product-price animated-value" data-target="5434" data-suffix=".00 ₽">0.00 ₽</span>
                <span class="product-weight">1 грамм</span>
                <span class="product-count animated-value" data-target="2" data-suffix=" штуки">0 штуки</span>
                <span class="product-total animated-value" data-target="5434" data-suffix=".00 ₽">0.00 ₽</span>
            </div>
            <div class="inventory-row">
                <span class="product-name">Hash Amezia 3 грамма</span>
                <span class="product-price animated-value" data-target="5434" data-suffix=".00 ₽">0.00 ₽</span>
                <span class="product-weight">1 грамм</span>
                <span class="product-count animated-value" data-target="2" data-suffix=" штуки">0 штуки</span>
                <span class="product-total animated-value" data-target="5434" data-suffix=".00 ₽">0.00 ₽</span>
            </div>
            <div class="inventory-row">
                <span class="product-name">Hash Amezia 3 грамма</span>
                <span class="product-price animated-value" data-target="5434" data-suffix=".00 ₽">0.00 ₽</span>
                <span class="product-weight">1 грамм</span>
                <span class="product-count animated-value" data-target="2" data-suffix=" штуки">0 штуки</span>
                <span class="product-total animated-value" data-target="5434" data-suffix=".00 ₽">0.00 ₽</span>
            </div>
            <div class="inventory-row">
                <span class="product-name">Hash Amezia 3 грамма</span>
                <span class="product-price animated-value" data-target="5434" data-suffix=".00 ₽">0.00 ₽</span>
                <span class="product-weight">1 грамм</span>
                <span class="product-count animated-value" data-target="2" data-suffix=" штуки">0 штуки</span>
                <span class="product-total animated-value" data-target="5434" data-suffix=".00 ₽">0.00 ₽</span>
            </div>
        </div>
    </div>

    <div class="graphs-row">
        <div class="graph-card" data-animate="fade-up" data-delay="700" id="depositsGraph">
            <div class="graph-header">
                <span class="graph-title">Дневной график пополнений</span>
                <span class="graph-date">02.12 - 03.12</span>
            </div>
            <div class="graph-content">
                <div class="graph-y-axis">
                    <span>10 000</span>
                    <span>7 500</span>
                    <span>5 000</span>
                    <span>2 500</span>
                    <span>0</span>
                </div>
                <div class="graph-area" id="depositsGraphArea">
                    <svg viewBox="0 0 455 187" class="line-chart" id="depositsSvg">
                        <defs>
                            <linearGradient id="lineGradient1" x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" style="stop-color: #008fcd" />
                                <stop offset="100%" style="stop-color: #008fcd" />
                            </linearGradient>
                        </defs>
                        <polyline id="depositsLine" fill="none" stroke="url(#lineGradient1)" stroke-width="2"
                            points="0,187 50,187 100,187 150,187 200,187 250,187 300,187 350,187 400,187 455,187"
                            data-target-points="0,150 50,120 100,90 150,130 200,70 250,100 300,60 350,110 400,80 455,50" />
                        <g class="graph-points" id="depositsPoints"></g>
                    </svg>
                    <div class="graph-tooltip" id="depositsTooltip"></div>
                </div>
            </div>
        </div>

        <div class="graph-card" data-animate="fade-up" data-delay="800" id="salesByCityGraph">
            <div class="graph-header">
                <span class="graph-title">Сумма продаж по городам</span>
                <div class="graph-legend">
                    <span class="legend-item"><span class="legend-dot purple"></span>Москва</span>
                    <span class="legend-item"><span class="legend-dot red"></span>Саратов</span>
                </div>
                <span class="graph-date">02.12 - 03.12</span>
            </div>
            <div class="graph-content">
                <div class="graph-y-axis">
                    <span>10 000</span>
                    <span>7 500</span>
                    <span>5 000</span>
                    <span>2 500</span>
                    <span>0</span>
                </div>
                <div class="graph-area" id="salesByCityArea">
                    <svg viewBox="0 0 456 187" class="line-chart" id="salesByCitySvg">
                        <defs>
                            <linearGradient id="lineGradient2" x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" style="stop-color: #6155f5" />
                                <stop offset="100%" style="stop-color: #6155f5" />
                            </linearGradient>
                            <linearGradient id="lineGradient3" x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" style="stop-color: #ff383c" />
                                <stop offset="100%" style="stop-color: #ff383c" />
                            </linearGradient>
                        </defs>
                        <polyline id="moscowLine" fill="none" stroke="url(#lineGradient2)" stroke-width="2"
                            points="0,187 50,187 100,187 150,187 200,187 250,187 300,187 350,187 400,187 456,187"
                            data-target-points="0,140 50,100 100,120 150,80 200,110 250,60 300,90 350,70 400,100 456,50" />
                        <polyline id="saratovLine" fill="none" stroke="url(#lineGradient3)" stroke-width="2"
                            points="0,187 50,187 100,187 150,187 200,187 250,187 300,187 350,187 400,187 456,187"
                            data-target-points="0,160 50,140 100,150 150,120 200,140 250,100 300,130 350,110 400,130 456,90" />
                        <g class="graph-points" id="salesByCityPoints"></g>
                    </svg>
                    <div class="graph-tooltip" id="salesByCityTooltip"></div>
                </div>
            </div>
        </div>
    </div>
</div>