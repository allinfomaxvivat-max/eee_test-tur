<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?= $title ?></title>
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <link rel="stylesheet" href="styles/main.css" />
    <link rel="stylesheet" href="styles/css/layout.css" />
    <link rel="stylesheet" href="styles/css/sidebar.css" />

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/simplebar@latest/dist/simplebar.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/simplebar@latest/dist/simplebar.min.js"></script>

    <?php if (!empty($styles)): ?>
        <?php foreach ($styles as $style): ?>
            <link rel="stylesheet" href="<?= htmlspecialchars($style) ?>">
        <?php endforeach; ?>
    <?php endif; ?>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;600;700&display=swap" rel="stylesheet" />
</head>
<!-- <style>
  /* normilized-scrollbar class for scrool containers*/
  .normilized-scrollbar {
    overflow: auto;
    scrollbar-width: thin;
    scrollbar-color: #008fcd #f0f0f0;
  }
  .normilized-scrollbar::-webkit-scrollbar {
    width: 4px;
    height: 4px;
  }

  .normilized-scrollbar::-webkit-scrollbar-track {
    background: #f0f0f0;
    border-radius: 6px;
  }

  .normilized-scrollbar::-webkit-scrollbar-thumb {
    background-color: #008fcd;
    border-radius: 6px;
    border: 3px solid #f0f0f0;
  }

  .normilized-scrollbar::-webkit-scrollbar-thumb:hover {
    background-color: #006fa1;
  }
</style> -->

<body>
    <div class="app">
        <img src="assets/---.png" alt="Background" class="background-image" />
        <aside class="sidebar">
            <a href="/" class="sidebar-logo-link"><img src="assets/turbo-2-1.svg" alt="TURBO" class="sidebar-logo" /></a>
            <div class="menu-items normilized-scrollbar" data-simplebar>
                <a href="/" class="menu-item">
                    <img src="assets/icon-home.png" alt="" class="menu-icon" />
                    <span>Главная страница</span>
                </a>
                <a href="/purchases.php" class="menu-item">
                    <img src="assets/icon-purchases.png" alt="" class="menu-icon" />
                    <span>Покупки</span>
                </a>
                <a href="/deposits.php" class="menu-item">
                    <img src="assets/icon-deposits.png" alt="" class="menu-icon" />
                    <span>Пополнения</span>
                </a>
                <a href="disputes.html" class="menu-item">
                    <img src="assets/icon-disputes.png" alt="" class="menu-icon" />
                    <span>Диспуты</span>
                </a>
                <a href="#" class="menu-item has-submenu">
                    <img src="assets/icon-warehouse.png" alt="" class="menu-icon" />
                    <span>Склад</span>
                    <svg class="dropdown-icon" viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
                        <path d="M7 10l5 5 5-5z" />
                    </svg>
                </a>
                <div class="submenu">
                    <a href="regions.html" class="submenu-item">Регионы</a>
                    <a href="cities.html" class="submenu-item">Города</a>
                    <a href="districts.html" class="submenu-item">Районы</a>
                    <a href="products.html" class="submenu-item">Товары</a>
                    <a href="product-groups.html" class="submenu-item">Группы товаров</a>
                    <a href="couriers.html" class="submenu-item">Курьеры</a>
                    <a href="addresses.html" class="submenu-item">Адреса</a>
                </div>
                <a href="#" class="menu-item has-submenu">
                    <img src="assets/icon-marketing.png" alt="" class="menu-icon" />
                    <span>Маркетинг</span>
                    <svg class="dropdown-icon" viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
                        <path d="M7 10l5 5 5-5z" />
                    </svg>
                </a>
                <div class="submenu">
                    <a href="promocodes.html" class="submenu-item">Промокоды</a>
                    <a href="/promocodes.php" class="submenu-item">Промокоды</a>
                    <a href="promo-actions.html" class="submenu-item">Промо-акции</a>
                    <a href="cumulative-discount.html" class="submenu-item">Накопительная скидка</a>
                    <a href="reviews.html" class="submenu-item">Отзывы</a>
                </div>
                <a href="#" class="menu-item has-submenu">
                    <img src="assets/icon-bots.png" alt="" class="menu-icon" />
                    <span>Боты</span>
                    <svg class="dropdown-icon" viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
                        <path d="M7 10l5 5 5-5z" />
                    </svg>
                </a>
                <div class="submenu">
                    <a href="bots.html" class="submenu-item">Рабочие боты</a>
                    <a href="bot-messages.html" class="submenu-item">Сообщения бота</a>
                </div>
                <a href="#" class="menu-item has-submenu">
                    <img src="assets/icon-mailings.png" alt="" class="menu-icon" />
                    <span>Рассылки/Публикации</span>
                    <svg class="dropdown-icon" viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
                        <path d="M7 10l5 5 5-5z" />
                    </svg>
                </a>
                <div class="submenu">
                    <a href="mailing-channels.html" class="submenu-item">Каналы для рассылки</a>
                    <a href="channel-publications.html" class="submenu-item">Публикации в каналах</a>
                    <a href="bot-mailings.html" class="submenu-item">Рассылки в бот</a>
                    <a href="auto-forwarding.html" class="submenu-item">Автопересылки</a>
                </div>
                <a href="#" class="menu-item has-submenu">
                    <img src="assets/icon-clients.png" alt="" class="menu-icon" />
                    <span>Клиенты</span>
                    <svg class="dropdown-icon" viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
                        <path d="M7 10l5 5 5-5z" />
                    </svg>
                </a>
                <div class="submenu">
                    <a href="clients.html" class="submenu-item">Клиенты</a>
                    <a href="support-messages.html" class="submenu-item">Сообщения в техподдержку</a>
                </div>
                <a href="#" class="menu-item has-submenu">
                    <img src="assets/icon-staff.png" alt="" class="menu-icon" />
                    <span>Сотрудники</span>
                    <svg class="dropdown-icon" viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
                        <path d="M7 10l5 5 5-5z" />
                    </svg>
                </a>
                <div class="submenu">
                    <a href="employees.html" class="submenu-item">Сотрудники</a>
                    <a href="access-levels.html" class="submenu-item">Уровни доступа</a>
                </div>
                <a href="history.html" class="menu-item">
                    <img src="assets/icon-history.png" alt="" class="menu-icon" />
                    <span>История</span>
                </a>
                <a href="#" class="menu-item has-submenu">
                    <img src="assets/icon-stats.png" alt="" class="menu-icon" />
                    <span>Статистика</span>
                    <svg class="dropdown-icon" viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
                        <path d="M7 10l5 5 5-5z" />
                    </svg>
                </a>
                <div class="submenu">
                    <a href="purchases-stock.html" class="submenu-item">Покупки и остатки</a>
                    <a href="deposits-dynamics.html" class="submenu-item">Динамика пополнений</a>
                    <a href="purchases-chart.html" class="submenu-item">Графики покупки</a>
                    <a href="deposits-chart.html" class="submenu-item">Графики пополнения</a>
                    <a href="debit-credit.html" class="submenu-item">Дебет/Кредит</a>
                    <a href="stock-groups.html" class="submenu-item">Склад по группам товаров</a>
                </div>
            </div>
            <!-- <div class="separator"></div>

        <div class="separator" style="margin-top: 60px"></div> -->

            <div class="wallet-section">
                <div class="wallet-item">
                    <img src="assets/btc.svg" alt="BTC" class="wallet-icon" />
                    <div class="wallet-info">
                        <span class="wallet-amount">0.00000000</span>
                        <span class="wallet-currency">BTC</span>
                    </div>
                </div>
                <div class="wallet-item">
                    <img src="assets/ltc.svg" alt="LTC" class="wallet-icon" />
                    <div class="wallet-info">
                        <span class="wallet-amount">234.00000000</span>
                        <span class="wallet-currency">LTC</span>
                    </div>
                </div>
                <div class="wallet-item">
                    <img src="assets/rub.svg" alt="RUB" class="wallet-icon" />
                    <div class="wallet-info">
                        <span class="wallet-amount">2 434.00 ₽</span>
                        <span class="wallet-currency">RUB</span>
                    </div>
                </div>
                <div class="wallet-item">
                    <img src="assets/usdt.svg" alt="USDT" class="wallet-icon" />
                    <div class="wallet-info">
                        <span class="wallet-amount">130.00000000</span>
                        <span class="wallet-currency">USDT</span>
                    </div>
                </div>
            </div>

            <div class="separator"></div>

            <div class="user-section-wrapper">
                <a href="settings.html" class="user-section" style="text-decoration: none; cursor: pointer">
                    <img src="assets/avatar.svg" alt="User" class="user-avatar" />
                    <div class="user-info">
                        <span class="user-shop">Gothem</span>
                        <span class="user-name">TestRUTOR</span>
                    </div>
                </a>

                <div class="notification-wrapper">
                    <button class="notification-btn" id="notificationBtn" data-testid="button-notifications">
                        <img src="assets/message-icon.png" alt="Messages" class="notification-icon" />
                        <span class="notification-badge" id="notificationBadge">3</span>
                    </button>

                    <div class="notification-panel" id="notificationPanel">
                        <div class="notification-panel-header">
                            <span class="notification-panel-title">Сообщение от клиентов</span>
                        </div>
                        <div class="notification-list" id="notificationList">
                            <div class="notification-item" data-testid="notification-item-1">
                                <img src="assets/avatar.svg" alt="User" class="notification-item-avatar" />
                                <div class="notification-item-content">
                                    <span class="notification-item-name">Carpenter Susan</span>
                                    <span class="notification-item-text">Новое сообщение от клиента</span>
                                    <span class="notification-item-time">03.12.2025 22:47:46</span>
                                </div>
                            </div>
                            <div class="notification-item" data-testid="notification-item-2">
                                <img src="assets/avatar.svg" alt="User" class="notification-item-avatar" />
                                <div class="notification-item-content">
                                    <span class="notification-item-name">Carpenter Susan</span>
                                    <span class="notification-item-text">Новое сообщение от клиента</span>
                                    <span class="notification-item-time">03.12.2025 22:47:46</span>
                                </div>
                            </div>
                            <div class="notification-item" data-testid="notification-item-3">
                                <img src="assets/avatar.svg" alt="User" class="notification-item-avatar" />
                                <div class="notification-item-content">
                                    <span class="notification-item-name">Carpenter Susan</span>
                                    <span class="notification-item-text">Новое сообщение от клиента</span>
                                    <span class="notification-item-time">03.12.2025 22:47:46</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </aside>
        <main class="main-content">
            <?= $children ?>
        </main>
    </div>
    <!-- <script src="scripts/sidebar.js"></script> -->
    <script src="scripts/main.js"></script>
</body>

</html>