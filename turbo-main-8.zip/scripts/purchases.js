document.addEventListener('DOMContentLoaded', function() {
  // Initialize filter dropdowns
  initPurchasesFilters();
  
  // Current filters state
  window.purchasesFilters = {
    search: '',
    city: 'all',
    product: 'all',
    courier: 'all',
    status: 'all',
    date: 'week'
  };
  
  const purchasesData = [
    {
      id: "#43063",
      username: "@Endycrown Krown Endy",
      shop: "Gothem",
      invited: 0,
      deposits: 1,
      purchases: 1,
      openDisputes: 0,
      totalDisputes: 0,
      promoCodesGiven: 1,
      balance: 0,
      discount: 0,
      product: "Альфа 1 грамм",
      city: "moscow",
      courier: "courier1",
      location: "Москва, Кузнецкий мост",
      amount: 5000,
      addressId: "#38620",
      status: "Выполнен",
      statusKey: "completed",
      createdAt: "21.12.2025 14:30:22",
      updatedAt: "21.12.2025 14:35:10"
    },
    {
      id: "#43064",
      username: "@TestUser2",
      shop: "Gothem",
      invited: 2,
      deposits: 3,
      purchases: 2,
      openDisputes: 1,
      totalDisputes: 1,
      promoCodesGiven: 0,
      balance: 500,
      discount: 5,
      product: "Hash Amezia",
      city: "saratov",
      courier: "courier2",
      location: "Саратов, Центр",
      amount: 3500,
      addressId: "#38621",
      status: "В ожидании",
      statusKey: "pending",
      createdAt: "20.12.2025 18:15:33",
      updatedAt: "20.12.2025 18:15:33"
    },
    {
      id: "#43065",
      username: "@SaratovBuyer",
      shop: "TopShop",
      invited: 1,
      deposits: 2,
      purchases: 3,
      openDisputes: 0,
      totalDisputes: 0,
      promoCodesGiven: 2,
      balance: 1200,
      discount: 10,
      product: "Альфа 1 грамм",
      city: "saratov",
      courier: "courier1",
      location: "Саратов, Ленинский район",
      amount: 4500,
      addressId: "#38622",
      status: "Выполнен",
      statusKey: "completed",
      createdAt: "19.12.2025 10:22:15",
      updatedAt: "19.12.2025 11:45:30"
    },
    {
      id: "#43066",
      username: "@MoscowClient",
      shop: "Gothem",
      invited: 0,
      deposits: 1,
      purchases: 1,
      openDisputes: 0,
      totalDisputes: 0,
      promoCodesGiven: 1,
      balance: 0,
      discount: 0,
      product: "Hash Amezia",
      city: "moscow",
      courier: "courier2",
      location: "Москва, Арбат",
      amount: 6000,
      addressId: "#38623",
      status: "Отменён",
      statusKey: "cancelled",
      createdAt: "18.12.2025 09:10:45",
      updatedAt: "18.12.2025 09:15:20"
    }
  ];
  
  window.purchasesData = purchasesData;

  function filterPurchases() {
    const filters = window.purchasesFilters;
    return purchasesData.filter(function(item) {
      if (filters.search && !item.id.toLowerCase().includes(filters.search.toLowerCase())) {
        return false;
      }
      if (filters.city !== 'all' && item.city !== filters.city) {
        return false;
      }
      if (filters.product !== 'all') {
        if (filters.product === 'alpha' && !item.product.toLowerCase().includes('альфа')) {
          return false;
        }
        if (filters.product === 'hash' && !item.product.toLowerCase().includes('hash')) {
          return false;
        }
      }
      if (filters.courier !== 'all' && item.courier !== filters.courier) {
        return false;
      }
      if (filters.status !== 'all' && item.statusKey !== filters.status) {
        return false;
      }
      return true;
    });
  }

  function renderPurchases() {
    const tableBody = document.getElementById('purchases-table');
    if (!tableBody) return;
    
    const filteredData = filterPurchases();
    
    if (filteredData.length === 0) {
      tableBody.innerHTML = '<div class="no-results">Нет данных по выбранным фильтрам</div>';
      return;
    }

    tableBody.innerHTML = filteredData.map(item => `
      <div class="table-row">
        <div class="table-cell">
          <span class="cell-id">${item.id}</span>
        </div>
        <div class="table-cell">
          <span class="cell-title">${item.username}</span>
          <span class="cell-text">${item.shop}</span>
          <span class="cell-text">Приглашённых: ${item.invited}</span>
          <span class="cell-text">Пополнений: ${item.deposits}</span>
          <span class="cell-text">Покупок: ${item.purchases}</span>
          <span class="cell-muted">Открытых диспутов: ${item.openDisputes}</span>
          <span class="cell-text">Сколько диспутов открывал: ${item.totalDisputes}</span>
          <span class="cell-text">Выдали промокоды: ${item.promoCodesGiven}</span>
          <span class="cell-muted">Баланс: ${item.balance} / Скидка ${item.discount} %</span>
        </div>
        <div class="table-cell">
          <span class="cell-title">${item.product}</span>
          <span class="cell-text">${item.location}</span>
          <span class="cell-text">Сумма: ${item.amount}</span>
          <span class="cell-text">Показать адрес ${item.addressId}</span>
        </div>
        <div class="table-cell center">
          <span class="status-${item.statusKey}">${item.status}</span>
        </div>
        <div class="table-cell">
          <span class="cell-title">${item.createdAt}</span>
          <span class="cell-title">${item.updatedAt}</span>
        </div>
        <div class="table-cell center">
          <div class="action-icons">
            <img src="assets/comment_fill.png" alt="Comment" class="action-icon comment-icon">
            <svg class="action-icon blue clock-animated" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" fill="#0088FF"/><circle cx="12" cy="12" r="7.5" fill="#33363F"/><line class="clock-hand-hour" x1="12" y1="12" x2="12" y2="6.5" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/><line class="clock-hand-minute" x1="12" y1="12" x2="15.5" y2="12" stroke="#0088FF" stroke-width="1.67" stroke-linecap="round"/></svg>
          </div>
        </div>
      </div>
    `).join('');
  }

  // Make renderPurchases globally available
  window.renderPurchases = renderPurchases;
  
  // Initial render
  renderPurchases();
  
  // Setup filter listeners
  setupFilterListeners();
});

function setupFilterListeners() {
  // Search input
  const searchInput = document.getElementById('purchasesSearch');
  if (searchInput) {
    searchInput.addEventListener('input', function(e) {
      window.purchasesFilters.search = e.target.value;
      window.renderPurchases();
    });
  }
}

function initPurchasesStatsAnimations() {
  // Animate simple number stats
  const animatedStats = document.querySelectorAll('.animated-stat');
  animatedStats.forEach(function(el, index) {
    const target = parseInt(el.dataset.target) || 0;
    const prefix = el.dataset.prefix || '';
    const suffix = el.dataset.suffix || '';
    
    setTimeout(function() {
      animateNumber(el, 0, target, 1200, prefix, suffix);
    }, 100 + index * 150);
  });
  
  // Animate text stats like "1 шт. на сумму 3 000.00 ₽"
  const animatedTexts = document.querySelectorAll('.animated-stat-text');
  animatedTexts.forEach(function(el, index) {
    const count = parseInt(el.dataset.count) || 0;
    const amount = parseInt(el.dataset.amount) || 0;
    
    setTimeout(function() {
      animateTextStat(el, count, amount, 1200);
    }, 200 + index * 150);
  });
  
  // Animate label stats like "Выполненные: 10"
  const animatedLabels = document.querySelectorAll('.animated-stat-label');
  animatedLabels.forEach(function(el, index) {
    const label = el.dataset.label || '';
    const target = parseInt(el.dataset.target) || 0;
    
    setTimeout(function() {
      animateLabelStat(el, label, target, 1200);
    }, 300 + index * 150);
  });
}

function animateNumber(el, start, end, duration, prefix, suffix) {
  const startTime = performance.now();
  
  function easeOutExpo(t) {
    return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
  }
  
  function formatNum(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  }
  
  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const easedProgress = easeOutExpo(progress);
    const current = Math.floor(start + (end - start) * easedProgress);
    el.textContent = prefix + formatNum(current) + suffix;
    
    if (progress < 1) {
      requestAnimationFrame(update);
    } else {
      el.textContent = prefix + formatNum(end) + suffix;
    }
  }
  
  requestAnimationFrame(update);
}

function animateTextStat(el, targetCount, targetAmount, duration) {
  const startTime = performance.now();
  
  function easeOutExpo(t) {
    return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
  }
  
  function formatNum(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  }
  
  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const easedProgress = easeOutExpo(progress);
    const currentCount = Math.floor(targetCount * easedProgress);
    const currentAmount = Math.floor(targetAmount * easedProgress);
    el.textContent = currentCount + ' шт. на сумму ' + formatNum(currentAmount) + '.00 ₽';
    
    if (progress < 1) {
      requestAnimationFrame(update);
    } else {
      el.textContent = targetCount + ' шт. на сумму ' + formatNum(targetAmount) + '.00 ₽';
    }
  }
  
  requestAnimationFrame(update);
}

function animateLabelStat(el, label, target, duration) {
  const startTime = performance.now();
  
  function easeOutExpo(t) {
    return t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
  }
  
  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const easedProgress = easeOutExpo(progress);
    const current = Math.floor(target * easedProgress);
    el.textContent = label + ': ' + current;
    
    if (progress < 1) {
      requestAnimationFrame(update);
    } else {
      el.textContent = label + ': ' + target;
    }
  }
  
  requestAnimationFrame(update);
}

function initPurchasesFilters() {
  // Setup all filter dropdowns
  const filters = [
    { btn: 'cityFilterBtn', menu: 'cityFilterMenu', text: 'cityFilterText', defaultText: 'Город', filterKey: 'city' },
    { btn: 'productFilterBtn', menu: 'productFilterMenu', text: 'productFilterText', defaultText: 'Товар', filterKey: 'product' },
    { btn: 'courierFilterBtn', menu: 'courierFilterMenu', text: 'courierFilterText', defaultText: 'Курьер', filterKey: 'courier' },
    { btn: 'statusFilterBtn', menu: 'statusFilterMenu', text: 'statusFilterText', defaultText: 'Статус', filterKey: 'status' },
    { btn: 'dateFilterBtn', menu: 'dateFilterMenu', text: 'dateFilterText', isDate: true, filterKey: 'date' }
  ];
  
  filters.forEach(function(filter) {
    const btn = document.getElementById(filter.btn);
    const menu = document.getElementById(filter.menu);
    const textEl = document.getElementById(filter.text);
    
    if (!btn || !menu) return;
    
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      // Close other menus
      document.querySelectorAll('.filter-dropdown-menu.show').forEach(function(m) {
        if (m !== menu) m.classList.remove('show');
      });
      document.querySelectorAll('.filter-btn.open').forEach(function(b) {
        if (b !== btn) b.classList.remove('open');
      });
      menu.classList.toggle('show');
      btn.classList.toggle('open');
    });
    
    menu.querySelectorAll('.filter-dropdown-item').forEach(function(item) {
      item.addEventListener('click', function() {
        menu.querySelectorAll('.filter-dropdown-item').forEach(function(i) {
          i.classList.remove('active');
        });
        item.classList.add('active');
        
        if (filter.isDate && item.dataset.label) {
          textEl.textContent = item.dataset.label;
        } else if (item.dataset.value === 'all') {
          textEl.textContent = filter.defaultText;
        } else {
          textEl.textContent = item.textContent;
        }
        
        // Update filter state and re-render
        if (window.purchasesFilters && filter.filterKey) {
          window.purchasesFilters[filter.filterKey] = item.dataset.value || 'all';
          if (window.renderPurchases) {
            window.renderPurchases();
          }
        }
        
        menu.classList.remove('show');
        btn.classList.remove('open');
      });
    });
  });
  
  // Close menus on outside click
  document.addEventListener('click', function() {
    document.querySelectorAll('.filter-dropdown-menu.show').forEach(function(m) {
      m.classList.remove('show');
    });
    document.querySelectorAll('.filter-btn.open').forEach(function(b) {
      b.classList.remove('open');
    });
  });
  
  // Update date filter with dynamic dates
  updatePurchasesDateFilter();
}

function updatePurchasesDateFilter() {
  const today = new Date();
  const todayStr = formatDateISO(today);
  
  const weekAgo = new Date(today);
  weekAgo.setDate(weekAgo.getDate() - 7);
  const weekAgoStr = formatDateISO(weekAgo);
  
  const monthAgo = new Date(today);
  monthAgo.setMonth(monthAgo.getMonth() - 1);
  const monthAgoStr = formatDateISO(monthAgo);
  
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = formatDateISO(yesterday);
  
  const dateFilterText = document.getElementById('dateFilterText');
  if (dateFilterText) {
    dateFilterText.textContent = weekAgoStr + ' - ' + todayStr;
  }
  
  const dateFilterMenu = document.getElementById('dateFilterMenu');
  if (dateFilterMenu) {
    dateFilterMenu.querySelectorAll('.filter-dropdown-item').forEach(function(item) {
      const value = item.dataset.value;
      if (value === 'week') {
        item.dataset.label = weekAgoStr + ' - ' + todayStr;
      } else if (value === 'today') {
        item.dataset.label = todayStr;
      } else if (value === 'yesterday') {
        item.dataset.label = yesterdayStr;
      } else if (value === 'month') {
        item.dataset.label = monthAgoStr + ' - ' + todayStr;
      }
    });
  }
  
  function formatDateISO(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return year + '-' + month + '-' + day;
  }
}
