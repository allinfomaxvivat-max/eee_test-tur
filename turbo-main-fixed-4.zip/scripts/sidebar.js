// Sidebar toggle functionality
console.log(123);
document.addEventListener("DOMContentLoaded", function () {
  // Sidebar navigation - toggle submenu for .nav-item
  document.querySelectorAll(".nav-item").forEach((item) => {
    console.log(item);
    const link = item.querySelector(".nav-link");
    const submenu = item.querySelector(".submenu");

    if (link && submenu) {
      link.addEventListener("click", function (e) {
        e.preventDefault();
        item.classList.toggle("open");
      });
    }
  });

  // Sidebar navigation - toggle submenu for .menu-item.has-submenu
  console.log(document.querySelectorAll(".menu-item.has-submenu"));
  document.querySelectorAll(".menu-item.has-submenu").forEach((menuItem) => {
    menuItem.addEventListener("click", function (e) {
      e.preventDefault();

      const isOpen = this.classList.contains("open");
      const submenu = this.nextElementSibling;

      // Close all other submenus
      document
        .querySelectorAll(".menu-item.has-submenu")
        .forEach((otherItem) => {
          if (otherItem !== this) {
            otherItem.classList.remove("open");
            const otherSubmenu = otherItem.nextElementSibling;
            if (otherSubmenu && otherSubmenu.classList.contains("submenu")) {
              otherSubmenu.style.maxHeight = "0";
            }
          }
        });

      // Toggle current submenu
      if (!isOpen) {
        this.classList.add("open");
        if (submenu && submenu.classList.contains("submenu")) {
          submenu.style.maxHeight = submenu.scrollHeight + "px";
        }
      } else {
        this.classList.remove("open");
        if (submenu && submenu.classList.contains("submenu")) {
          submenu.style.maxHeight = "0";
        }
      }
    });
  });
});

// const currentPath = window.location.pathname;
// const menuItems = document.querySelectorAll(".simplebar-content a");
// menuItems.forEach((item) => {
//   if (item.getAttribute("href") === currentPath) {
//     item.classList.add("active");
//   }
// });
