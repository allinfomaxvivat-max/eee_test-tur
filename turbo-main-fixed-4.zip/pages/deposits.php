<div class="breadcrumb">
    <a href="index.html" class="breadcrumb-item breadcrumb-link" data-testid="link-home-breadcrumb">Главная страница</a>
    <svg class="breadcrumb-separator" viewBox="0 0 24 24" fill="currentColor">
        <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z" />
    </svg>
    <span class="breadcrumb-item active">Пополнения</span>
</div>

<div class="filters-bar" data-animate="fade-up">
    <div class="search-input">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M14.0002 14L11.0095 11.004L14.0002 14ZM12.6668 6.99999C12.6668 8.50289 12.0698 9.94423 11.0071 11.0069C9.9444 12.0696 8.50306 12.6667 7.00016 12.6667C5.49727 12.6667 4.05593 12.0696 2.99322 11.0069C1.93052 9.94423 1.3335 8.50289 1.3335 6.99999C1.3335 5.4971 1.93052 4.05576 2.99322 2.99306C4.05593 1.93035 5.49727 1.33333 7.00016 1.33333C8.50306 1.33333 9.9444 1.93035 11.0071 2.99306C12.0698 4.05576 12.6668 5.4971 12.6668 6.99999V6.99999Z"
                stroke="#969696" stroke-width="1.20137" stroke-linecap="round" />
        </svg>
        <input type="text" id="depositsSearch" placeholder="Поиск по номеру или клиенту"
            data-testid="input-deposits-search">
    </div>

    <div class="filter-buttons">
        <div class="filter-dropdown-wrapper">
            <button class="filter-btn" id="currencyFilterBtn" data-testid="button-currency-filter">
                <span id="currencyFilterText">Валюта</span>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M4 6L8 10L12 6" stroke="#969696" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
</svg>
            </button>
            <div class="filter-dropdown-menu" id="currencyFilterMenu">
                <div class="filter-dropdown-item active" data-value="all">Все валюты</div>
                <div class="filter-dropdown-item" data-value="RUB">RUB (Рубли)</div>
                <div class="filter-dropdown-item" data-value="BTC">BTC (Биткоин)</div>
                <div class="filter-dropdown-item" data-value="USDT">USDT</div>
            </div>
        </div>
        <div class="filter-dropdown-wrapper">
            <button class="filter-btn" id="statusFilterBtn" data-testid="button-status-filter">
                <span id="statusFilterText">Статус</span>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M4 6L8 10L12 6" stroke="#969696" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
</svg>
            </button>
            <div class="filter-dropdown-menu" id="statusFilterMenu">
                <div class="filter-dropdown-item active" data-value="all">Все статусы</div>
                <div class="filter-dropdown-item" data-value="completed">Выполнен</div>
                <div class="filter-dropdown-item" data-value="cancelled">Отменен</div>
                <div class="filter-dropdown-item" data-value="pending">В ожидании</div>
            </div>
        </div>
        <div class="filter-dropdown-wrapper">
            <button class="filter-btn" id="dateFilterBtn" data-testid="button-date-filter">
                <span id="dateFilterText">2025-12-09 - 2025-12-15</span>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M12.6667 2.66666H3.33333C2.59695 2.66666 2 3.26362 2 4V13.3333C2 14.0697 2.59695 14.6667 3.33333 14.6667H12.6667C13.403 14.6667 14 14.0697 14 13.3333V4C14 3.26362 13.403 2.66666 12.6667 2.66666Z" stroke="#969696" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
  <path d="M10.6665 1.33334V4" stroke="#969696" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
  <path d="M5.3335 1.33334V4" stroke="#969696" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
  <path d="M2 6.66666H14" stroke="#969696" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
  <path d="M6 10.6667L7.33333 12L10 9.33334" stroke="#969696" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
</svg>
            </button>
            <div class="filter-dropdown-menu" id="dateFilterMenu">
                <div class="filter-dropdown-item active" data-value="all">Все даты</div>
                <div class="filter-dropdown-item" data-value="today">Сегодня</div>
                <div class="filter-dropdown-item" data-value="yesterday">Вчера</div>
                <div class="filter-dropdown-item" data-value="week">Последние 7 дней</div>
                <div class="filter-dropdown-item" data-value="month">Последний месяц</div>
            </div>
        </div>
    </div>
</div>

<div class="deposits-table">
    <div class="deposits-header">
        <span class="col-id">#</span>
        <span class="col-client">Клиент</span>
        <span class="col-credited">Сумма зачисления</span>
        <span class="col-payment">Сумма и способ оплаты</span>
        <span class="col-status">Статус</span>
        <span class="col-date">Дата</span>
        <span class="col-action">Действие</span>
    </div>

    <div class="deposits-body" id="deposits-table">
        <div class="deposit-row" data-id="43063" data-status="completed" data-currency="RUB" data-amount="15000"
            data-date="2025-12-03" data-testid="deposit-row-43063">
            <div class="deposit-id">#43063</div>
            <div class="deposit-client">
                <span class="client-name">@Endycrown Krown Endy</span>
                <span class="client-detail">Gothem</span>
                <span class="client-detail">Приглашённых: 0</span>
                <span class="client-detail">Пополнений: 1</span>
                <span class="client-detail">Покупок: 1</span>
                <span class="client-detail muted">Открытых диспутов: 0</span>
                <span class="client-detail">Сколько диспутов открывал: 0</span>
                <span class="client-detail">Выдали промокоды: 1</span>
                <span class="client-detail muted">Баланс: 0 / Скидка 0 %</span>
            </div>
            <div class="deposit-credited">15 000.00 ₽</div>
            <div class="deposit-payment">
                <span class="payment-amount">15 000.00 ₽</span>
                <span class="payment-method">(С Альфа-банк на Альфа-Банк)</span>
            </div>
            <div class="deposit-status completed">Выполнен</div>
            <div class="deposit-date">
                <span>03.12.2025 22:47:46</span>
                <span>03.12.2025 22:47:46</span>
            </div>
            <div class="deposit-action">
                <svg class="action-icon blue clock-animated" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" fill="#0088FF" />
                    <circle cx="12" cy="12" r="7.5" fill="#33363F" />
                    <line class="clock-hand-hour" x1="12" y1="12" x2="12" y2="6.5" stroke="#0088FF" stroke-width="1.67"
                        stroke-linecap="round" />
                    <line class="clock-hand-minute" x1="12" y1="12" x2="15.5" y2="12" stroke="#0088FF"
                        stroke-width="1.67" stroke-linecap="round" />
                </svg>
            </div>
        </div>

        <div class="deposit-row" data-id="43062" data-status="cancelled" data-currency="RUB" data-amount="15000"
            data-date="2025-12-02" data-testid="deposit-row-43062">
            <div class="deposit-id">#43062</div>
            <div class="deposit-client">
                <span class="client-name">@CryptoKing Alex</span>
                <span class="client-detail">Gothem</span>
                <span class="client-detail">Приглашённых: 2</span>
                <span class="client-detail">Пополнений: 3</span>
                <span class="client-detail">Покупок: 5</span>
                <span class="client-detail muted">Открытых диспутов: 1</span>
                <span class="client-detail">Сколько диспутов открывал: 1</span>
                <span class="client-detail">Выдали промокоды: 0</span>
                <span class="client-detail muted">Баланс: 500 / Скидка 5 %</span>
            </div>
            <div class="deposit-credited">15 000.00 ₽</div>
            <div class="deposit-payment">
                <span class="payment-amount">15 000.00 ₽</span>
                <span class="payment-method">(С Альфа-банк на Альфа-Банк)</span>
            </div>
            <div class="deposit-status cancelled">Отменен</div>
            <div class="deposit-date">
                <span>02.12.2025 18:32:11</span>
                <span>02.12.2025 18:35:22</span>
            </div>
            <div class="deposit-action">
                <svg class="action-icon blue clock-animated" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" fill="#0088FF" />
                    <circle cx="12" cy="12" r="7.5" fill="#33363F" />
                    <line class="clock-hand-hour" x1="12" y1="12" x2="12" y2="6.5" stroke="#0088FF" stroke-width="1.67"
                        stroke-linecap="round" />
                    <line class="clock-hand-minute" x1="12" y1="12" x2="15.5" y2="12" stroke="#0088FF"
                        stroke-width="1.67" stroke-linecap="round" />
                </svg>
            </div>
        </div>

        <div class="deposit-row" data-id="43061" data-status="completed" data-currency="BTC" data-amount="25000"
            data-date="2025-12-01" data-testid="deposit-row-43061">
            <div class="deposit-id">#43061</div>
            <div class="deposit-client">
                <span class="client-name">@BitMaster Ivan</span>
                <span class="client-detail">Gothem</span>
                <span class="client-detail">Приглашённых: 5</span>
                <span class="client-detail">Пополнений: 10</span>
                <span class="client-detail">Покупок: 15</span>
                <span class="client-detail muted">Открытых диспутов: 0</span>
                <span class="client-detail">Сколько диспутов открывал: 2</span>
                <span class="client-detail">Выдали промокоды: 3</span>
                <span class="client-detail muted">Баланс: 1200 / Скидка 10 %</span>
            </div>
            <div class="deposit-credited">0.0025 BTC</div>
            <div class="deposit-payment">
                <span class="payment-amount">0.0025 BTC</span>
                <span class="payment-method">(Bitcoin)</span>
            </div>
            <div class="deposit-status completed">Выполнен</div>
            <div class="deposit-date">
                <span>01.12.2025 14:22:33</span>
                <span>01.12.2025 14:25:41</span>
            </div>
            <div class="deposit-action">
                <svg class="action-icon blue clock-animated" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" fill="#0088FF" />
                    <circle cx="12" cy="12" r="7.5" fill="#33363F" />
                    <line class="clock-hand-hour" x1="12" y1="12" x2="12" y2="6.5" stroke="#0088FF" stroke-width="1.67"
                        stroke-linecap="round" />
                    <line class="clock-hand-minute" x1="12" y1="12" x2="15.5" y2="12" stroke="#0088FF"
                        stroke-width="1.67" stroke-linecap="round" />
                </svg>
            </div>
        </div>

        <div class="deposit-row" data-id="43060" data-status="completed" data-currency="USDT" data-amount="5000"
            data-date="2025-11-30" data-testid="deposit-row-43060">
            <div class="deposit-id">#43060</div>
            <div class="deposit-client">
                <span class="client-name">@TetherPro Maria</span>
                <span class="client-detail">Gothem</span>
                <span class="client-detail">Приглашённых: 1</span>
                <span class="client-detail">Пополнений: 2</span>
                <span class="client-detail">Покупок: 3</span>
                <span class="client-detail muted">Открытых диспутов: 0</span>
                <span class="client-detail">Сколько диспутов открывал: 0</span>
                <span class="client-detail">Выдали промокоды: 1</span>
                <span class="client-detail muted">Баланс: 200 / Скидка 2 %</span>
            </div>
            <div class="deposit-credited">50.00 USDT</div>
            <div class="deposit-payment">
                <span class="payment-amount">50.00 USDT</span>
                <span class="payment-method">(Tether TRC20)</span>
            </div>
            <div class="deposit-status completed">Выполнен</div>
            <div class="deposit-date">
                <span>30.11.2025 09:15:22</span>
                <span>30.11.2025 09:18:44</span>
            </div>
            <div class="deposit-action">
                <svg class="action-icon blue clock-animated" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" fill="#0088FF" />
                    <circle cx="12" cy="12" r="7.5" fill="#33363F" />
                    <line class="clock-hand-hour" x1="12" y1="12" x2="12" y2="6.5" stroke="#0088FF" stroke-width="1.67"
                        stroke-linecap="round" />
                    <line class="clock-hand-minute" x1="12" y1="12" x2="15.5" y2="12" stroke="#0088FF"
                        stroke-width="1.67" stroke-linecap="round" />
                </svg>
            </div>
        </div>

        <div class="deposit-row" data-id="43059" data-status="pending" data-currency="RUB" data-amount="8500"
            data-date="2025-12-03" data-testid="deposit-row-43059">
            <div class="deposit-id">#43059</div>
            <div class="deposit-client">
                <span class="client-name">@NewUser Test</span>
                <span class="client-detail">Gothem</span>
                <span class="client-detail">Приглашённых: 0</span>
                <span class="client-detail">Пополнений: 1</span>
                <span class="client-detail">Покупок: 0</span>
                <span class="client-detail muted">Открытых диспутов: 0</span>
                <span class="client-detail">Сколько диспутов открывал: 0</span>
                <span class="client-detail">Выдали промокоды: 0</span>
                <span class="client-detail muted">Баланс: 0 / Скидка 0 %</span>
            </div>
            <div class="deposit-credited">8 500.00 ₽</div>
            <div class="deposit-payment">
                <span class="payment-amount">8 500.00 ₽</span>
                <span class="payment-method">(СБП)</span>
            </div>
            <div class="deposit-status pending">В ожидании</div>
            <div class="deposit-date">
                <span>03.12.2025 23:55:00</span>
                <span>--</span>
            </div>
            <div class="deposit-action">
                <svg class="action-icon blue clock-animated" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="10" fill="#0088FF" />
                    <circle cx="12" cy="12" r="7.5" fill="#33363F" />
                    <line class="clock-hand-hour" x1="12" y1="12" x2="12" y2="6.5" stroke="#0088FF" stroke-width="1.67"
                        stroke-linecap="round" />
                    <line class="clock-hand-minute" x1="12" y1="12" x2="15.5" y2="12" stroke="#0088FF"
                        stroke-width="1.67" stroke-linecap="round" />
                </svg>
            </div>
        </div>
    </div>

    <div class="no-results-message" id="noResultsMessage" style="display: none;">
        <span>Ничего не найдено</span>
    </div>
</div>